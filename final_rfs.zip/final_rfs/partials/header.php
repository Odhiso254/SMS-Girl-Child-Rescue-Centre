<?php
require_login();

$nav = [
    'admin' => [
        ['Dashboard','index.php','dashboard','⌂'],['Rescued People','students.php','students','♙'],
        ['Rescue Incidents','rescue_incidents.php','rescue_incidents','⚕'],['Emergency Types','emergency_types.php','emergency_types','⚠'],
        ['Traditions / Communities','traditions.php','traditions','◈'],['Donors','donors.php','donors','♧'],['Donor Support','support.php','support','♡'],
        ['School Admissions','admissions.php','admissions','▣'],['School Fees','fees.php','fees','KSh'],['Hospital Visits','hospital_visits.php','hospital_visits','▤'],
        ['Treatments','treatments.php','treatments','✚'],['Farm Records','farm.php','farm','⌁'],['Hospitals','hospitals.php','hospitals','▣'],['Reports','reports.php','reports','▥'],
        ['Audit Logs','audit.php','audit','◉'],['Petty Cash','petty_cash.php','petty_cash','KSh'],['User Manager','users.php','users','♙'],
        ['Backups','backup.php','backup','⤓'],['Restore Database','restore.php','backup','↥'],['Settings','settings.php','settings','⚙'],['System Health','system_health.php','system_health','✓'],
        ['System Unlock','unlock.php','system_unlock','🔓'],
    ],
    'staff' => [
        ['Dashboard','index.php','dashboard','⌂'],['Rescued People','students.php','students','♙'],
        ['Rescue Incidents','rescue_incidents.php','rescue_incidents','⚕'],['Emergency Types','emergency_types.php','emergency_types','⚠'],
        ['Traditions / Communities','traditions.php','traditions','◈'],['School Admissions','admissions.php','admissions','▣'],
        ['School Fees','fees.php','fees','KSh'],['Hospital Visits','hospital_visits.php','hospital_visits','▤'],['Treatments','treatments.php','treatments','✚'],
        ['Farm Records','farm.php','farm','⌁'],['Reports','reports.php','reports','▥'],
    ],
    'farmer' => [['Farm Dashboard','index.php','dashboard','⌂'],['Farm Records','farm.php','farm','⌁']],
    'doctor' => [['Health Dashboard','index.php','dashboard','⌂'],['Hospital Visits','hospital_visits.php','hospital_visits','▤'],['Treatments','treatments.php','treatments','✚']],
    'student' => [['School Dashboard','index.php','dashboard','⌂'],['School Admissions','admissions.php','admissions','▣'],['School Fees','fees.php','fees','KSh']],
    'donor' => [['Donor Dashboard','index.php','dashboard','⌂'],['My Donor Profile','donors.php','donors','♧'],['My Support','support.php','support','♡']],
    'manager' => [['Dashboard','index.php','dashboard','⌂'],['Rescued People','students.php','students','♙'],['School Admissions','admissions.php','admissions','▣'],['School Fees','fees.php','fees','KSh'],['Farm Records','farm.php','farm','⌁'],['Hospital Visits','hospital_visits.php','hospital_visits','▤'],['Reports','reports.php','reports','▥']],
    'coordinator' => [['Dashboard','index.php','dashboard','⌂'],['Rescued People','students.php','students','♙'],['School Admissions','admissions.php','admissions','▣'],['School Fees','fees.php','fees','KSh'],['Farm Records','farm.php','farm','⌁'],['Hospital Visits','hospital_visits.php','hospital_visits','▤'],['Treatments','treatments.php','treatments','✚'],['Reports','reports.php','reports','▥']],
];
$nav['director'] = array_values(array_filter($nav['admin'], static fn($it) => $it[1] !== 'unlock.php'));
$nav['staff'][]=['Hospitals','hospitals.php','hospitals','▣'];
$nav['manager'][]=['Hospitals','hospitals.php','hospitals','▣'];
$nav['coordinator'][]=['Hospitals','hospitals.php','hospitals','▣'];
$nav['doctor'][]=['Hospitals','hospitals.php','hospitals','▣'];
$items = $nav[role()] ?? [['Dashboard','index.php','dashboard','⌂']];

$roleNames = ['admin'=>'Super Admin','staff'=>'Staff','manager'=>'Manager','director'=>'Director','coordinator'=>'Coordinator','farmer'=>'Farmer','doctor'=>'Doctor','student'=>'Student','donor'=>'Donor'];
$roleLabel = $roleNames[role()] ?? ucfirst(role());
$initials = strtoupper(substr((string)(user()['full_name'] ?? 'User'),0,1));
$profilePhoto = (string)(user()['profile_photo'] ?? '');
$notificationCount = unread_notifications($pdo);
$pendingUsers = 0;
if(in_array(role(),['admin','director'],true)){ try{$pendingSql="SELECT COUNT(*) FROM users WHERE role<>'admin' AND approval_status='pending'"; if(role()==='director') $pendingSql.=" AND role<>'manager'"; $pendingUsers=(int)$pdo->query($pendingSql)->fetchColumn();}catch(Throwable $e){} }
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0d6b4a">
<meta name="description" content="SUGUTA · SMI Girl Child Rescue Centre — Integrated Management System">
<title><?=e($title??APP_NAME)?> · <?=e(APP_NAME)?></title>
<link rel="stylesheet" href="assets/style.css">

</head>
<body>
<div class="app">
<aside class="sidebar" id="sidebar" aria-label="Primary navigation">
    <div class="brand">
        <div class="brandmark">B</div>
        <div class="brandcopy"><b>SUGUTA · SMI GIRL CHILD RESCUE CENTRE</b><small><?=e($roleLabel)?> Workspace</small></div>
    </div>

    <div class="profile-mini">
        <div class="avatar"><?php if($profilePhoto): ?><img src="<?=e($profilePhoto)?>" alt="Profile photo"><?php else: ?><?=e($initials)?><?php endif; ?></div>
        <div><strong><?=e(user()['full_name'] ?? 'User')?></strong><span><?=e($roleLabel)?></span></div>
    </div>

    <div class="nav-section-title">MAIN MENU</div>
    <nav>
    <?php foreach($items as $it): ?>
        <a href="<?=e($it[1])?>" class="nav-3d-tab <?=($page??'')===$it[2]?'active':''?>">
            <span class="navicon" aria-hidden="true"><?=e($it[3])?></span><span><?=e($it[0])?><?php if($it[1]==='users.php' && $pendingUsers>0):?><em class="nav-count"><?=$pendingUsers>99?'99+':$pendingUsers?></em><?php endif;?></span>
        </a>
    <?php endforeach; ?>
    </nav>

    <div class="nav-section-title">ACCOUNT</div>
    <nav class="account-nav">
        <a href="change_password.php" class="nav-3d-tab <?=($page??'')==='change_password'?'active':''?>"><span class="navicon">⌁</span><span>Change Password</span></a>
        <a href="2fa_setup.php" class="nav-3d-tab <?=($page??'')==='2fa_setup'?'active':''?>"><span class="navicon">🔐</span><span>2FA Security</span></a>
        <form method="post" action="logout.php" class="logout-form"><?=csrf_field()?>
            <button type="submit" class="nav-3d-tab"><span class="navicon">↪</span><span>Logout</span></button>
        </form>
    </nav>

    <div class="sidefoot">
        <strong>Secure workspace</strong>
        <span>PHP 8+ · MySQL · v<?=e(APP_VERSION)?></span>
    </div>
</aside>

<main class="main">
    <header class="topbar">
        <button class="menu" type="button" aria-label="Open navigation" aria-controls="sidebar" aria-expanded="false" onclick="toggleSidebar(this)">☰</button>
        <div class="topbar-title"><span class="eyebrow"><?=e($roleLabel)?></span><b><?=e($title??APP_NAME)?></b><small>Manage your workspace securely and efficiently</small></div>
        <div class="topright">
            <a class="notification-bell" href="notifications.php" aria-label="Notifications" title="Notifications">🔔<?php if($notificationCount>0):?><span><?=$notificationCount>99?'99+':$notificationCount?></span><?php endif;?></a>
            <button class="btn small secondary top-print" onclick="window.print()">Print</button>
            <div class="date"><?=date('D, d M Y')?></div>
            <div class="top-user"><span class="avatar small"><?php if($profilePhoto): ?><img src="<?=e($profilePhoto)?>" alt="Profile photo"><?php else: ?><?=e($initials)?><?php endif; ?></span><span class="username"><?=e(user()['full_name'] ?? 'User')?></span></div>
        </div>
    </header>

    <section class="content">
    <?php foreach(flashes() as $f): ?>
        <div class="flash <?=$f['type']?>" role="alert"><?=e($f['message'])?></div>
    <?php endforeach; ?>
