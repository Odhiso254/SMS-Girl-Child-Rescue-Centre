    </section>
    <footer>© <?=date('Y')?> SUGUTA · SMI Girl Child Rescue Centre · Developed by Evlyne Owino</footer>
</main>
</div>
<script>
function toggleSidebar(button){
    const sidebar=document.getElementById('sidebar');
    const open=sidebar.classList.toggle('open');
    if(button) button.setAttribute('aria-expanded', open ? 'true' : 'false');
}
document.querySelectorAll('[data-confirm]').forEach(x=>x.addEventListener('click',e=>{
    if(!confirm(x.dataset.confirm)) e.preventDefault();
}));
document.addEventListener('click',e=>{
    const s=document.getElementById('sidebar');
    if(s && s.classList.contains('open') && !s.contains(e.target) && !e.target.closest('.menu')) {
        s.classList.remove('open');
        const m=document.querySelector('.menu'); if(m) m.setAttribute('aria-expanded','false');
    }
});
</script>
</body>
</html>
