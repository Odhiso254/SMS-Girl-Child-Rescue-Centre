<?php
require __DIR__.'/config/config.php';
if(logged_in()) redirect('index.php');
verify_csrf();
$error=''; $success='';
$allowed=['coordinator'=>'Coordinator','manager'=>'Manager','staff'=>'Staff','farmer'=>'Farmer','doctor'=>'Doctor','student'=>'Student','donor'=>'Donor'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    $name=trim((string)($_POST['full_name']??'')); $username=trim((string)($_POST['username']??''));
    $email=trim((string)($_POST['email']??'')); $phone=trim((string)($_POST['phone']??''));
    $idNumber=trim((string)($_POST['id_number']??''));
    $password=(string)($_POST['password']??''); $confirm=(string)($_POST['confirm_password']??'');
    $role=(string)($_POST['role']??''); $robot=!empty($_POST['not_robot']);
    $photoPath=null;
    if(!empty($_POST['website'])) $error='Unable to create account.';
    elseif(!$robot) $error='Please confirm that you are not a robot.';
    elseif(!$name||!$username||!$idNumber||!$password||!$confirm||!isset($allowed[$role])) $error='Please complete all required fields.';
    elseif(strlen($password)<8) $error='Password must be at least 8 characters.';
    elseif($password!==$confirm) $error='Passwords do not match.';
    elseif($email && !filter_var($email,FILTER_VALIDATE_EMAIL)) $error='Please enter a valid email address.';
    elseif(isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] !== UPLOAD_ERR_NO_FILE && $_FILES['profile_photo']['error'] !== UPLOAD_ERR_OK) $error='Profile photo upload failed. Please choose another image.';
    elseif(isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK && (int)$_FILES['profile_photo']['size'] > 3*1024*1024) $error='Profile photo must be 3 MB or smaller.';
    else {
        try {
            $q=$pdo->prepare('SELECT id FROM users WHERE username=? AND role=?'); $q->execute([$username,$role]);
            $usernameExists=(bool)$q->fetch();
            $q=$pdo->prepare('SELECT id FROM users WHERE id_number=? LIMIT 1'); $q->execute([$idNumber]);
            $idExists=(bool)$q->fetch();
            if($usernameExists) $error='That username is already registered for this role.';
            elseif($idExists) $error='That ID number is already registered.';
            else {
                if(isset($_FILES['profile_photo']) && $_FILES['profile_photo']['error'] === UPLOAD_ERR_OK){
                    $tmp=$_FILES['profile_photo']['tmp_name'];
                    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp);
                    $allowedMimes=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
                    if(!isset($allowedMimes[$mime])) throw new RuntimeException('Please upload a JPG, PNG or WebP image.');
                    $dims=@getimagesize($tmp);
                    if(!$dims || $dims[0]<80 || $dims[1]<80 || $dims[0]>5000 || $dims[1]>5000) throw new RuntimeException('Profile photo dimensions are not supported.');
                    $dir=__DIR__.'/uploads/profile';
                    if(!is_dir($dir) && !mkdir($dir,0755,true)) throw new RuntimeException('Could not prepare profile photo storage.');
                    $photoPath='uploads/profile/'.bin2hex(random_bytes(16)).'.'.$allowedMimes[$mime];
                    if(!move_uploaded_file($tmp,__DIR__.'/'.$photoPath)) throw new RuntimeException('Could not save the profile photo.');
                }
                $q=$pdo->prepare('INSERT INTO users(username,full_name,id_number,email,phone,password_hash,role,approval_status,is_verified,is_active,profile_photo) VALUES(?,?,?,?,?,?,?, ?,0,0,?)');
                $q->execute([$username,$name,$idNumber,$email?:null,$phone?:null,password_hash($password,PASSWORD_DEFAULT),$role,'pending',$photoPath]);
                $newId=(int)$pdo->lastInsertId();
                audit($pdo,'Account registration','users',$newId,'Awaiting administrator approval');
                // Manager registrations are intentionally routed only to the administrator.
                notify($pdo,null,'New account awaiting approval',"{$name} ({$username}) requested a {$allowed[$role]} account.",'admin','users.php');
                if($role!=='manager'){
                    notify($pdo,null,'New account awaiting approval',"{$name} ({$username}) requested a {$allowed[$role]} account.",'director','users.php');
                }
                $success='Account submitted successfully. Please wait for an administrator to approve or reject your account.';
            }
        } catch(Throwable $e){
            if(!empty($photoPath)){ $saved=__DIR__.'/'.$photoPath; if(is_file($saved)) @unlink($saved); }
            $error=$e instanceof RuntimeException ? $e->getMessage() : 'Could not create the account. Please try again.';
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Create Account • <?=e(APP_NAME)?></title><link rel="stylesheet" href="assets/style.css"></head>
<body class="loginpage"><div class="loginbox">
<div class="brand"><div class="brandmark">S</div><div><b>SUGUTA · SMI GIRL CHILD RESCUE CENTRE</b><small>Account Registration</small></div></div>
<h1>Create account</h1><div class="pending-banner"><span class="pending-dot"></span><div><strong>Approval required</strong><small>Your account will remain pending until the administrator reviews it.</small></div></div>
<?php if($error):?><div class="flash error"><?=e($error)?></div><?php endif;?><?php if($success):?><div class="flash success"><?=e($success)?></div><?php endif;?>
<form method="post" autocomplete="off" enctype="multipart/form-data"><?=csrf_field()?>
<div class="field"><label>Full name</label><input name="full_name" required></div>
<div class="field"><label>Username</label><input name="username" required maxlength="100"></div>
<div class="field"><label>ID number</label><input name="id_number" required maxlength="50" autocomplete="off"></div>
<div class="field"><label>Role</label><select name="role" required><option value="">Select role</option><?php foreach($allowed as $k=>$v):?><option value="<?=$k?>"><?=e($v)?></option><?php endforeach;?></select></div>
<div class="field"><label>Email (optional)</label><input type="email" name="email"></div>
<div class="field"><label>Phone (optional)</label><input name="phone"></div>
<div class="field"><label>Profile photo (optional)</label><input type="file" name="profile_photo" accept="image/jpeg,image/png,image/webp"><small class="muted">JPG, PNG or WebP · maximum 3 MB</small></div>
<div class="field"><label>Password</label><input type="password" name="password" minlength="8" required></div>
<div class="field"><label>Confirm password</label><input type="password" name="confirm_password" minlength="8" required></div>
<div class="field robot-check"><label><input type="checkbox" name="not_robot" value="1"> I’m not a robot</label></div>
<div style="position:absolute;left:-9999px"><input name="website" tabindex="-1" autocomplete="off"></div>
<button class="btn" type="submit" id="createAccountBtn">Create account</button>
<div id="waitNotice" class="wait-notice" hidden><span class="spinner"></span><div><strong>Please wait…</strong><small>Your registration is being submitted securely for administrator approval.</small></div></div>
</form>
<div class="note"><a href="login.php">Already have an account? Sign in</a></div>
</div><script>
document.querySelector('form').addEventListener('submit',function(){
 const b=document.getElementById('createAccountBtn'); b.disabled=true; b.textContent='Submitting…';
 document.getElementById('waitNotice').hidden=false;
});
</script></body></html>