<?php
require __DIR__.'/config/config.php'; require_login();
if(!in_array(role(),['admin','director'],true)){http_response_code(403);exit('403 Forbidden');}
$tables=$pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
$backupDir=__DIR__.'/storage/backups';
$autoBackups=glob($backupDir.'/farm_auto_*.sql') ?: [];
usort($autoBackups, static fn($a,$b)=>filemtime($b)<=>filemtime($a));
$lastAuto=$pdo->query("SELECT setting_value FROM system_settings WHERE setting_key='last_auto_backup_at' LIMIT 1")->fetchColumn();
if(isset($_GET['auto_download'])){
  $name=basename((string)$_GET['auto_download']); $path=$backupDir.'/'.$name;
  if(!preg_match('/^farm_auto_[0-9_-]+\\.sql$/',$name) || !is_file($path)){http_response_code(404);exit('Backup not found.');}
  header('Content-Type: application/sql; charset=utf-8'); header('Content-Disposition: attachment; filename="'.$name.'"'); readfile($path); exit;
}
if(isset($_GET['download'])){
  $file='smi_girl_child_rescue_backup_'.date('Y-m-d_H-i-s').'.sql';
  header('Content-Type: application/sql; charset=utf-8');header('Content-Disposition: attachment; filename="'.$file.'"');
  echo "-- SMI Girl Child Rescue Centre backup\n-- Generated ".date('c')."\nCREATE DATABASE IF NOT EXISTS `farm` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\nUSE `farm`;\nSET FOREIGN_KEY_CHECKS=0;\n";
  foreach($tables as $t){
    $q=$pdo->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_NUM);
    echo "\nDROP TABLE IF EXISTS `$t`;\n".$q[1].";\n";
    $rows=$pdo->query("SELECT * FROM `$t`")->fetchAll(PDO::FETCH_ASSOC);
    foreach($rows as $r){
      $vals=[]; foreach($r as $v){ $vals[] = $v===null ? 'NULL' : $pdo->quote((string)$v); }
      echo "INSERT INTO `$t` (`".implode("`,`",array_keys($r))."`) VALUES (".implode(',',$vals).");\n";
    }
  }
  echo "SET FOREIGN_KEY_CHECKS=1;\n";exit;
}
$title='Backups & Recovery';$page='backup';require __DIR__.'/partials/header.php';?>
<div class="hero"><div><h1>Backups & Recovery</h1><p>The system keeps automatic daily SQL snapshots while retaining the existing manual backup operation.</p></div><a class="btn" href="backup.php?download=1">⤓ Download manual backup</a></div>
<div class="card"><h3>Automatic backups</h3><p class="hint">Automatic backup runs at most once every 24 hours when the application is accessed. The most recent 14 automatic backups are retained.</p><p><b>Last automatic backup:</b> <?=e($lastAuto ?: 'Not created yet')?></p><div class="tablewrap"><table class="table"><thead><tr><th>Backup file</th><th>Created</th><th>Size</th><th>Action</th></tr></thead><tbody><?php if(!$autoBackups):?><tr><td colspan="4">No automatic backup files yet.</td></tr><?php else: foreach($autoBackups as $bf):?><tr><td><?=e(basename($bf))?></td><td><?=e(date('Y-m-d H:i:s',filemtime($bf)))?></td><td><?=e(number_format(filesize($bf)/1024,1))?> KB</td><td><a class="btn small" href="?auto_download=<?=rawurlencode(basename($bf))?>">Download</a></td></tr><?php endforeach; endif;?></tbody></table></div></div>
<div class="card"><h3>Recovery plan</h3><ol><li>Keep automatic backups on the server and periodically copy a backup to another disk/USB/cloud storage.</li><li>If the server crashes, reinstall XAMPP/MySQL and create/import the <b>farm</b> database.</li><li>For controlled restoration, Admin or Director can use the Restore page.</li></ol><div class="form-actions"><a class="btn secondary" href="restore.php">Restore database</a><button class="btn secondary" onclick="window.print()">Print information</button></div></div>
<?php require __DIR__.'/partials/footer.php'; ?>