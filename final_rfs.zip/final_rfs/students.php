<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='Rescued People'; $page='students'; $action=$_GET['action']??'list';
$traditions=$pdo->query('SELECT id,name FROM traditions ORDER BY name')->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST'){
 $name=trim((string)($_POST['full_name']??'')); $gender=(string)($_POST['gender']??''); $dob=$_POST['dob']?:null; $rescue=$_POST['rescue_date']?:null;
 $trad=(int)($_POST['tradition_id']??0)?:null; $guardian=trim((string)($_POST['guardian_name']??'')); $phone=trim((string)($_POST['guardian_phone']??''));
 $edu=(string)($_POST['education_status']??'Not in School'); $school=trim((string)($_POST['current_school_name']??''))?:null; $status=(string)($_POST['status']??'Active'); $notes=trim((string)($_POST['notes']??''));
 if(!$name){flash('error','Full name is required.');redirect('students.php?action=add');}
 if($edu==='Not in School') $school=null;
 $s=$pdo->prepare('INSERT INTO rescued_students(full_name,gender,dob,rescue_date,guardian_name,guardian_phone,tradition_id,education_status,current_school_name,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
 $s->execute([$name,$gender,$dob,$rescue,$guardian,$phone,$trad,$edu,$school,$status,$notes]);
 $id=(int)$pdo->lastInsertId(); audit($pdo,'Registered rescued person','rescued_students',$id); flash('success','Rescued person registered.'); redirect('students.php');
}
$rows=$pdo->query("SELECT s.*,t.name tradition_name,(SELECT COUNT(*) FROM rescue_incidents ri WHERE ri.student_id=s.id) emergency_count,(SELECT COUNT(*) FROM hospital_visits hv WHERE hv.student_id=s.id) hospital_count FROM rescued_students s LEFT JOIN traditions t ON t.id=s.tradition_id ORDER BY s.id DESC")->fetchAll();
require __DIR__.'/partials/header.php';
?>
<div class="hero"><div><h1>Rescued People</h1><p>Record rescue, education level, community and care status in one connected profile.</p></div><a class="btn" href="?action=add">+ Register rescued person</a></div>
<?php if($action==='add'): ?>
<div class="card"><h3>Register rescued person</h3><p class="muted">A person can be <b>Primary, Secondary, College, University, or Not in School</b>. Those marked Not in School can later be given a school admission.</p>
<form method="post"><?=csrf_field()?><div class="formgrid">
<div class="field"><label>Full name</label><input name="full_name" required></div><div class="field"><label>Gender</label><select name="gender"><option>Female</option><option>Male</option><option>Other</option></select></div>
<div class="field"><label>Date of birth</label><input type="date" name="dob"></div><div class="field"><label>Rescue date</label><input type="date" name="rescue_date" value="<?=date('Y-m-d')?>"></div>
<div class="field"><label>Tradition / Community</label><select name="tradition_id"><option value="">Not specified</option><?php foreach($traditions as $t):?><option value="<?=$t['id']?>"><?=e($t['name'])?></option><?php endforeach;?></select></div>
<div class="field"><label>Current school level</label><select name="education_status"><option>Not in School</option><option>Primary</option><option>Secondary</option><option>College</option><option>University</option></select></div>
<div class="field"><label>Current school / institution</label><input name="current_school_name" placeholder="Leave blank if not in school"></div>
<div class="field"><label>Guardian / responsible person</label><input name="guardian_name"></div><div class="field"><label>Guardian phone</label><input name="guardian_phone"></div>
<div class="field"><label>Rescue status</label><select name="status"><option>Active</option><option>Graduated</option><option>Transferred</option><option>Inactive</option></select></div>
<div class="field full"><label>Notes</label><textarea name="notes"></textarea></div></div><div class="form-actions"><button class="btn">Save profile</button><a class="btn secondary" href="students.php">Cancel</a></div></form></div>
<?php else: ?>
<div class="card"><div class="searchbar"><input id="search" placeholder="Search rescued people..."></div><div class="tablewrap"><table class="table" id="data"><thead><tr><th>Name</th><th>Education</th><th>Institution</th><th>Community</th><th>Emergencies</th><th>Hospital visits</th><th>Status</th><th>Actions</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr><td><?=e($r['full_name'])?></td><td><?=e($r['education_status'])?></td><td><?=e($r['current_school_name']??'Not in school')?></td><td><?=e($r['tradition_name']??'')?></td><td><?=e((string)$r['emergency_count'])?></td><td><?=e((string)$r['hospital_count'])?></td><td><?=e($r['status'])?></td><td><?php if(can_manage_records()):?><a class="btn small" href="record_manager.php?entity=students&id=<?=$r['id']?>">Edit / Update</a> <form class="inline-form" method="post" action="record_manager.php?entity=students&amp;id=<?=$r['id']?>"><?=csrf_field()?><input type="hidden" name="op" value="delete"><button class="btn small danger" type="submit" data-confirm="Delete this rescued-person record and its linked history? This cannot be undone.">Delete</button></form><?php endif;?> <button class="btn small secondary" onclick="window.print()">Print</button></td></tr><?php endforeach;?></tbody></table></div></div>
<script>document.getElementById('search').addEventListener('input',e=>{const q=e.target.value.toLowerCase();document.querySelectorAll('#data tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')});</script>
<?php endif; require __DIR__.'/partials/footer.php'; ?>
