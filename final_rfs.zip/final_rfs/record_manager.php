<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
if(!can_manage_records()){http_response_code(403);exit('403 Forbidden — only Admin or Director can edit or delete shared records.');}
$entity=(string)($_GET['entity']??''); $id=(int)($_GET['id']??0);
$defs=[
'students'=>['table'=>'rescued_students','title'=>'Rescued Person','fields'=>[
 'full_name'=>['Full name','text'],'gender'=>['Gender','select:Female|Male|Other'],'dob'=>['Date of birth','date'],'rescue_date'=>['Rescue date','date'],'guardian_name'=>['Guardian name','text'],'guardian_phone'=>['Guardian phone','text'],'tradition_id'=>['Community','tradition'],'education_status'=>['Education status','select:Primary|Secondary|College|University|Not in School'],'current_school_name'=>['Current school','text'],'status'=>['Status','select:Active|Graduated|Transferred|Inactive'],'notes'=>['Notes','textarea']]],
'incidents'=>['table'=>'rescue_incidents','title'=>'Rescue Incident','fields'=>['student_id'=>['Rescued person','student'],'emergency_type_id'=>['Emergency type','emergency'],'incident_date'=>['Incident date','date'],'location'=>['Location','text'],'severity'=>['Severity','select:Low|Moderate|High|Critical'],'description'=>['Description','textarea']]],
'emergency_types'=>['table'=>'emergency_types','title'=>'Emergency Type','fields'=>['name'=>['Name','text'],'description'=>['Description','textarea'],'active'=>['Status','select:1|0']]],
'traditions'=>['table'=>'traditions','title'=>'Tradition / Community','fields'=>['name'=>['Name','text'],'location'=>['Location','text'],'contact_person'=>['Contact person','text'],'notes'=>['Notes','textarea']]],
'donors'=>['table'=>'donors','title'=>'Donor','fields'=>['name'=>['Name','text'],'organization'=>['Organization','text'],'phone'=>['Phone','text'],'email'=>['Email','email'],'visit_frequency'=>['Visit frequency','text'],'last_visit'=>['Last visit','date'],'notes'=>['Notes','textarea']]],
'hospitals'=>['table'=>'hospitals','title'=>'Hospital / Facility','fields'=>['name'=>['Hospital / facility','text'],'location'=>['Location','text'],'phone'=>['Phone','text'],'contact_person'=>['Contact person','text'],'emergency_services'=>['Emergency services','select:1|0'],'active'=>['Status','select:1|0'],'notes'=>['Notes','textarea']]],
'admissions'=>['table'=>'school_admissions','title'=>'School Admission','fields'=>['student_id'=>['Student','student'],'level'=>['Level','select:Primary|Secondary|College|University'],'institution'=>['Institution','text'],'course_or_class'=>['Class / Course','text'],'admission_date'=>['Admission date','date'],'status'=>['Status','select:Applied|Admitted|Enrolled|Completed|Declined'],'fees'=>['Fees','number'],'notes'=>['Notes','textarea']]],
'visits'=>['table'=>'hospital_visits','title'=>'Hospital Visit','fields'=>['student_id'=>['Student','student'],'hospital_id'=>['Hospital','hospital'],'rescue_incident_id'=>['Incident','incident_optional'],'visit_date'=>['Visit date','date'],'visit_type'=>['Visit type','select:Outpatient|Inpatient|Emergency|Referral|Follow-up'],'diagnosis'=>['Diagnosis','text'],'doctor'=>['Doctor / clinician','text'],'admission_date'=>['Admission date','date'],'discharge_date'=>['Discharge date','date'],'status'=>['Status','select:Open|Treated|Referred|Discharged'],'notes'=>['Notes','textarea']]],
'treatments'=>['table'=>'health_treatments','title'=>'Treatment','fields'=>['visit_id'=>['Hospital visit','visit'],'treatment_date'=>['Treatment date','date'],'treatment'=>['Treatment / medicine / procedure','text'],'provider'=>['Provider','text'],'amount'=>['Cost','number'],'payment_status'=>['Payment status','select:Unpaid|Paid|Sponsored|Waived'],'notes'=>['Notes','textarea']]],
'farm'=>['table'=>'farm_records','title'=>'Farm Record','fields'=>['farmer_user_id'=>['Farmer user ID','number'],'category'=>['Category','select:Poultry|Dairy|Crop'],'item'=>['Item / produce','text'],'quantity'=>['Quantity','number'],'unit'=>['Unit','text'],'amount'=>['Amount','number'],'financial_type'=>['Financial classification','select:None|Sale|Expense'],'record_date'=>['Date','date'],'buyer_or_supplier'=>['Buyer / Supplier','text'],'notes'=>['Notes','textarea']]],
'support'=>['table'=>'donor_supports','title'=>'Donor Support','fields'=>['donor_id'=>['Donor','donor'],'student_id'=>['Student','student_optional'],'support_category'=>['Category','select:Centre Support|Food Support|Other Income'],'amount'=>['Amount','number'],'support_date'=>['Date','date'],'description'=>['Description','text'],'reference_no'=>['Reference','text']]],
'fees'=>['table'=>'school_fee_payments','title'=>'School Fee Payment','fields'=>['admission_id'=>['Admission ID','number'],'student_id'=>['Student','student'],'amount'=>['Amount','number'],'payment_date'=>['Payment date','date'],'reference_no'=>['Reference','text'],'description'=>['Description','text']]],
'petty_cash'=>['table'=>'petty_cash','title'=>'Petty Cash','fields'=>['transaction_type'=>['Type','select:Income|Expense'],'category'=>['Category','text'],'amount'=>['Amount','number'],'transaction_date'=>['Date','date'],'paid_to_from'=>['Paid to / received from','text'],'reference_no'=>['Reference','text'],'description'=>['Description','text']]],
];
if(!isset($defs[$entity])||$id<1){http_response_code(404);exit('Record not found.');}
$d=$defs[$entity]; $table=$d['table'];
$returnPages=['students'=>'students.php','incidents'=>'rescue_incidents.php','emergency_types'=>'emergency_types.php','traditions'=>'traditions.php','donors'=>'donors.php','hospitals'=>'hospitals.php','admissions'=>'admissions.php','visits'=>'hospital_visits.php','treatments'=>'treatments.php','farm'=>'farm.php','support'=>'support.php','fees'=>'fees.php','petty_cash'=>'petty_cash.php'];
$returnPage=$returnPages[$entity] ?? 'index.php';

function manager_options(PDO $pdo,string $kind): array {
    return match($kind){
        'student','student_optional'=> $pdo->query("SELECT id,full_name label FROM rescued_students ORDER BY full_name")->fetchAll(),
        'tradition'=> $pdo->query("SELECT id,name label FROM traditions ORDER BY name")->fetchAll(),
        'emergency'=> $pdo->query("SELECT id,name label FROM emergency_types ORDER BY name")->fetchAll(),
        'hospital'=> $pdo->query("SELECT id,name label FROM hospitals ORDER BY name")->fetchAll(),
        'incident_optional'=> $pdo->query("SELECT id,CONCAT(DATE_FORMAT(incident_date,'%Y-%m-%d'),' — ',location) label FROM rescue_incidents ORDER BY incident_date DESC,id DESC")->fetchAll(),
        'visit'=> $pdo->query("SELECT v.id,CONCAT(DATE_FORMAT(v.visit_date,'%Y-%m-%d'),' — ',s.full_name) label FROM hospital_visits v JOIN rescued_students s ON s.id=v.student_id ORDER BY v.visit_date DESC,v.id DESC")->fetchAll(),
        'donor'=> $pdo->query("SELECT id,name label FROM donors ORDER BY name")->fetchAll(),
        default=>[]
    };
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    $op=(string)($_POST['op']??'');
    try{
        if($op==='delete'){
            $pdo->beginTransaction();
            foreach([['fees','fee_payment_id'],['support','support_id'],['treatments','treatment_id'],['farm','farm_record_id']] as [$kind,$col]) if($entity===$kind) $pdo->prepare("DELETE FROM financial_transactions WHERE {$col}=?")->execute([$id]);
            $stmt=$pdo->prepare("DELETE FROM `$table` WHERE id=?"); $stmt->execute([$id]);
            if($stmt->rowCount()!==1) throw new RuntimeException('The record no longer exists.');
            audit($pdo,'Deleted record',$table,$id); $pdo->commit(); flash('success','Record deleted successfully.'); redirect($returnPage);
        }
        if($op==='update'){
            $sets=[];$vals=[];
            foreach($d['fields'] as $key=>$spec){
                $v=$_POST[$key]??null;
                if($spec[1]==='number' && $v!=='') $v=(float)$v;
                if(str_starts_with($spec[1],'select:') && in_array($key,['active','emergency_services'],true)) $v=(int)$v;
                if($v==='') $v=null;
                $sets[]="`$key`=?"; $vals[]=$v;
            }
            if(!$sets) throw new RuntimeException('Nothing to update.');
            $vals[]=$id; $pdo->beginTransaction();
            $stmt=$pdo->prepare("UPDATE `$table` SET ".implode(',',$sets)." WHERE id=?"); $stmt->execute($vals);
            if($stmt->rowCount()<0) throw new RuntimeException('Update failed.');
            if($entity==='fees') $pdo->prepare('UPDATE financial_transactions SET amount=?,transaction_date=?,reference_no=?,description=? WHERE fee_payment_id=?')->execute([(float)($_POST['amount']??0),$_POST['payment_date']??date('Y-m-d'),($_POST['reference_no']??null)?:null,$_POST['description']??'',$id]);
            if($entity==='support') $pdo->prepare('UPDATE financial_transactions SET amount=?,transaction_date=?,reference_no=?,description=?,category=? WHERE support_id=?')->execute([(float)($_POST['amount']??0),$_POST['support_date']??date('Y-m-d'),($_POST['reference_no']??null)?:null,$_POST['description']??'',$_POST['support_category']??'Other Income',$id]);
            if($entity==='treatments') $pdo->prepare('UPDATE financial_transactions SET amount=?,transaction_date=?,description=? WHERE treatment_id=?')->execute([(float)($_POST['amount']??0),$_POST['treatment_date']??date('Y-m-d'),'Hospital treatment: '.($_POST['treatment']??''),$id]);
            if($entity==='farm'){
                $amount=(float)($_POST['amount']??0); $ft=(string)($_POST['financial_type']??'None'); $date=$_POST['record_date']??date('Y-m-d'); $item=(string)($_POST['item']??'');
                $pdo->prepare('DELETE FROM financial_transactions WHERE farm_record_id=?')->execute([$id]);
                if($amount>0 && in_array($ft,['Sale','Expense'],true)){
                    $pdo->prepare("INSERT INTO financial_transactions(transaction_type,category,amount,transaction_date,farm_record_id,description,created_by) VALUES(?,?,?,?,?,?,?)")
                        ->execute([$ft==='Sale'?'Income':'Expense',$ft==='Sale'?'Farm Sales':'Farm Expense',$amount,$date,$id,'Farm '.$ft.': '.$item,user()['id']]);
                }
            }
            audit($pdo,'Updated record',$table,$id); $pdo->commit(); flash('success','Record updated successfully.'); redirect($returnPage);
        }
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack(); flash('error',$e instanceof RuntimeException?$e->getMessage():'Could not update or delete this record. Check linked records and try again.'); redirect('record_manager.php?entity='.rawurlencode($entity).'&id='.$id);}
}
$q=$pdo->prepare("SELECT * FROM `$table` WHERE id=?"); $q->execute([$id]); $row=$q->fetch(); if(!$row){http_response_code(404);exit('Record not found.');}
require __DIR__.'/partials/header.php'; ?>
<div class="hero"><div><h1>Edit / Update <?=e($d['title'])?></h1><p>Admin and Director controls are protected by CSRF validation and audited for accountability.</p></div></div>
<div class="card"><form method="post"><?=csrf_field()?><input type="hidden" name="op" value="update"><div class="formgrid">
<?php foreach($d['fields'] as $key=>$spec): $type=$spec[1]; ?><div class="field <?=$type==='textarea'?'full':''?>"><label><?=e($spec[0])?></label>
<?php if(str_starts_with($type,'select:')):$opts=explode('|',substr($type,7));?><select name="<?=e($key)?>" required><?php foreach($opts as $o):?><option value="<?=e($o)?>" <?=((string)$row[$key]===(string)$o)?'selected':''?>><?=e($o==='1'?'Active':($o==='0'?'Inactive':$o))?></option><?php endforeach;?></select>
<?php elseif(in_array($type,['student','student_optional','tradition','emergency','hospital','incident_optional','visit','donor'],true)):$opts=manager_options($pdo,$type);?><select name="<?=e($key)?>" <?=$type!=='student_optional'&&$type!=='incident_optional'&&$type!=='student_optional'?'required':''?>><option value="">— Select —</option><?php foreach($opts as $o):?><option value="<?=$o['id']?>" <?=((string)$row[$key]===(string)$o['id'])?'selected':''?>><?=e($o['label'])?></option><?php endforeach;?></select>
<?php elseif($type==='textarea'):?><textarea name="<?=e($key)?>"><?=e((string)($row[$key]??''))?></textarea>
<?php else:?><input type="<?=e($type)?>" name="<?=e($key)?>" value="<?=e((string)($row[$key]??''))?>" <?=in_array($key,['amount','quantity','fees'],true)?'min="0" step="0.01"':''?>><?php endif;?></div><?php endforeach;?></div>
<div class="form-actions"><button class="btn" type="submit">Save changes</button><button type="button" class="btn danger" onclick="document.getElementById('deleteForm').requestSubmit()">Delete record</button><a class="btn secondary" href="javascript:history.back()">Cancel</a></div></form>
<form id="deleteForm" method="post" onsubmit="return confirm('Delete this record? Linked records may also be affected. This cannot be undone.')"><?=csrf_field()?><input type="hidden" name="op" value="delete"></form></div>
<?php require __DIR__.'/partials/footer.php'; ?>
