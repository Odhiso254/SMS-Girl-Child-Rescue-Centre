<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='Emergency Types'; $page='emergency_types'; $action=$_GET['action']??'list'; $id=(int)($_GET['id']??0);
if($_SERVER['REQUEST_METHOD']==='POST'){
 $op=(string)($_POST['op']??''); $id=(int)($_POST['id']??0);
 try{
  if($op==='save'){
   $name=trim((string)($_POST['name']??''));$desc=trim((string)($_POST['description']??''));$active=(int)($_POST['active']??1);
   if(!$name) throw new RuntimeException('Emergency type name is required.');
   if($id){$s=$pdo->prepare('UPDATE emergency_types SET name=?,description=?,active=? WHERE id=?');$s->execute([$name,$desc,$active,$id]);audit($pdo,'Updated emergency type','emergency_types',$id);flash('success','Emergency type updated.');}
   else{$s=$pdo->prepare('INSERT INTO emergency_types(name,description,active) VALUES(?,?,?)');$s->execute([$name,$desc,$active]);$id=(int)$pdo->lastInsertId();audit($pdo,'Created emergency type','emergency_types',$id);flash('success','Emergency type added.');}
  } elseif($op==='delete'){
   $q=$pdo->prepare('SELECT COUNT(*) n FROM rescue_incidents WHERE emergency_type_id=?');$q->execute([$id]);$used=(int)$q->fetch()['n'];
   if($used>0){$s=$pdo->prepare('UPDATE emergency_types SET active=0 WHERE id=?');$s->execute([$id]);flash('success','This type has rescue history, so it was deactivated instead of deleted. History remains safe.');}
   else{$s=$pdo->prepare('DELETE FROM emergency_types WHERE id=?');$s->execute([$id]);flash('success','Emergency type deleted.');}
   audit($pdo,'Deleted/deactivated emergency type','emergency_types',$id);
  }
 }catch(Throwable $e){flash('error',$e instanceof RuntimeException?$e->getMessage():'Could not save that emergency type.');}
 redirect('emergency_types.php');
}
$edit=null;if($action==='edit'&&$id){$s=$pdo->prepare('SELECT * FROM emergency_types WHERE id=?');$s->execute([$id]);$edit=$s->fetch();}
$rows=$pdo->query('SELECT e.*, (SELECT COUNT(*) FROM rescue_incidents r WHERE r.emergency_type_id=e.id) incidents FROM emergency_types e ORDER BY e.name')->fetchAll();
require __DIR__.'/partials/header.php';
?><div class="hero"><div><h1>Emergency Types</h1><p>Add, change, activate/deactivate or delete emergency types. Types already used in rescue history are protected from destructive deletion.</p></div><a class="btn" href="?action=add">+ Add emergency type</a></div>
<?php if($action==='add'||$edit): ?><div class="card"><h3><?=$edit?'Change emergency type':'Add emergency type'?></h3><form method="post"><?=csrf_field()?><input type="hidden" name="op" value="save"><input type="hidden" name="id" value="<?=$edit?(int)$edit['id']:0?>"><div class="formgrid"><div class="field"><label>Emergency type</label><input name="name" required value="<?=e($edit['name']??'')?>" placeholder="Flood, Landslide, Drought..."></div><div class="field"><label>Status</label><select name="active"><option value="1" <?=(!$edit||$edit['active'])?'selected':''?>>Active</option><option value="0" <?=($edit&&!(int)$edit['active'])?'selected':''?>>Inactive</option></select></div><div class="field full"><label>Description</label><textarea name="description"><?=e($edit['description']??'')?></textarea></div></div><div class="form-actions"><button class="btn">Save</button><a class="btn secondary" href="emergency_types.php">Cancel</a></div></form></div><?php endif; ?>
<div class="card"><div class="tablewrap"><table class="table"><tr><th>Emergency type</th><th>Description</th><th>Rescue records</th><th>Status</th><th>Action</th><th>Actions</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['name'])?></td><td><?=e($r['description']??'')?></td><td><?=e((string)$r['incidents'])?></td><td><?=((int)$r['active'])?'Active':'Inactive'?></td><td><a class="btn small" href="?action=edit&id=<?=$r['id']?>">Change</a> <form style="display:inline" method="post"><?=csrf_field()?><input type="hidden" name="op" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn small danger" data-confirm="Delete this emergency type? If it has history, it will be deactivated instead.">Delete</button></form></td></tr><?php endforeach;?></table></div></div>
<?php require __DIR__.'/partials/footer.php'; ?>
