<?php
require __DIR__.'/config/config.php'; require_login();
if(role()!=='admin'){http_response_code(403);exit('403 Forbidden');}
$title='System Health'; $page='system_health';
$checks=[];
$files=['index.php','students.php','rescue_incidents.php','emergency_types.php','traditions.php','donors.php','support.php','admissions.php','fees.php','hospitals.php','hospital_visits.php','treatments.php','farm.php','reports.php','audit.php','petty_cash.php','users.php','backup.php','restore.php','settings.php','unlock.php','notifications.php','change_password.php','2fa_setup.php'];
foreach($files as $f)$checks[]=['File: '.$f,is_file(__DIR__.'/'.$f)];
try{$tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);$required=['users','roles','notifications','system_settings','rescued_students','rescue_incidents','emergency_types','school_admissions','school_fee_payments','hospitals','hospital_visits','health_treatments','farm_records','donors','donor_supports','financial_transactions','petty_cash','petty_cash_months','audit_logs'];foreach($required as $t)$checks[]=['Table: '.$t,in_array($t,$tables,true)];}catch(Throwable $e){$checks[]=['Database schema query',false];}
require __DIR__.'/partials/header.php';
?><div class="hero"><div><h1>System Health</h1><p>Administrator-only diagnostic for core navigation files and database tables.</p></div><button class="btn secondary" onclick="window.print()">Print</button></div><div class="card"><div class="tablewrap"><table class="table"><tr><th>Check</th><th>Status</th></tr><?php foreach($checks as $c):?><tr><td><?=e($c[0])?></td><td><span class="badge <?= $c[1]?'':'rejected' ?>"><?= $c[1]?'OK':'ERROR' ?></span></td></tr><?php endforeach;?></table></div></div><?php require __DIR__.'/partials/footer.php';
