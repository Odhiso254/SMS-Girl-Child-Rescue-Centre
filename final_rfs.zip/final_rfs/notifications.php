<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='Notifications'; $page='notifications';
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op']??'')==='read'){
    $id=(int)($_POST['id']??0);
    $s=$pdo->prepare('UPDATE notifications SET is_read=1 WHERE id=? AND (user_id=? OR (user_id IS NULL AND recipient_role=?))');
    $s->execute([$id,user()['id'],role()]);
    redirect('notifications.php');
}
$s=$pdo->prepare('SELECT * FROM notifications WHERE user_id=? OR (user_id IS NULL AND recipient_role=?) ORDER BY created_at DESC LIMIT 100');
$s->execute([user()['id'],role()]); $rows=$s->fetchAll();
require __DIR__.'/partials/header.php'; ?>
<div class="hero"><div><h1>Notifications</h1><p>Stay informed about account approvals, registrations and important system activity.</p></div></div>
<div class="notification-list">
<?php if(!$rows):?><div class="card empty-state"><strong>No notifications yet.</strong><span>You're all caught up.</span></div><?php endif;?>
<?php foreach($rows as $n):?><div class="card notification-card <?=$n['is_read']?'read':'unread'?>">
 <div class="notification-icon"><?=($n['is_read']?'✓':'!')?></div><div class="notification-body"><strong><?=e($n['title'])?></strong><p><?=e($n['message'])?></p><small><?=e($n['created_at'])?></small></div>
 <?php if(!$n['is_read']):?><form method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=$n['id']?>"><button class="btn small secondary" name="op" value="read">Mark read</button></form><?php endif;?>
</div><?php endforeach;?>
</div>
<?php require __DIR__.'/partials/footer.php'; ?>