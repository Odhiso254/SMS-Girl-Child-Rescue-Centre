<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='School Fees'; $page='fees'; $action=$_GET['action']??'list';
if(role()==='student'){
 $q=$pdo->prepare("SELECT a.id,a.student_id,a.level,a.institution,a.course_or_class,s.full_name FROM school_admissions a JOIN rescued_students s ON s.id=a.student_id WHERE s.user_id=? AND a.status IN ('Admitted','Enrolled') ORDER BY s.full_name,a.institution");
 $q->execute([user()['id']]);$admissions=$q->fetchAll();
} else $admissions=$pdo->query("SELECT a.id,a.student_id,a.level,a.institution,a.course_or_class,s.full_name FROM school_admissions a JOIN rescued_students s ON s.id=a.student_id WHERE a.status IN ('Admitted','Enrolled') ORDER BY s.full_name,a.institution")->fetchAll();
if(role()==='student' && $_SERVER['REQUEST_METHOD']==='POST'){
 flash('error','Student accounts are view-only for school records. Contact staff for changes.');
 redirect('fees.php');
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $aid=(int)($_POST['admission_id']??0); $amount=(float)($_POST['amount']??0); $date=(string)($_POST['payment_date']??''); $ref=trim((string)($_POST['reference_no']??''))?:null; $desc=trim((string)($_POST['description']??''));
 $q=$pdo->prepare("SELECT student_id,level,institution,course_or_class FROM school_admissions WHERE id=?"); $q->execute([$aid]); $a=$q->fetch();
 if(!$a || $amount<=0 || !$date || !$desc){flash('error','Select a valid enrolled admission and provide amount, date and description.');redirect('fees.php?action=add');}
 $pdo->beginTransaction();
 try{
  $s=$pdo->prepare("INSERT INTO school_fee_payments(admission_id,student_id,amount,payment_date,reference_no,description,created_by) VALUES(?,?,?,?,?,?,?)");$s->execute([$aid,$a['student_id'],$amount,$date,$ref,$desc,user()['id']]);$fid=(int)$pdo->lastInsertId();
  $t=$pdo->prepare("INSERT INTO financial_transactions(transaction_type,category,amount,transaction_date,student_id,fee_payment_id,description,reference_no,created_by) VALUES('Income','School Fees',?,?,?,?,?,?,?)");$t->execute([$amount,$date,$a['student_id'],$fid,$desc,$ref,user()['id']]);
  audit($pdo,'Recorded School Fee Payment','school_fee_payments',$fid);$pdo->commit();flash('success','School fee payment and financial income recorded together.');redirect('fees.php');
 }catch(Throwable $e){$pdo->rollBack();flash('error','Could not save payment.');redirect('fees.php?action=add');}
}
if(role()==='student'){
 $q=$pdo->prepare("SELECT f.*,s.full_name,a.level,a.institution FROM school_fee_payments f JOIN rescued_students s ON s.id=f.student_id JOIN school_admissions a ON a.id=f.admission_id WHERE s.user_id=? ORDER BY f.id DESC");
 $q->execute([user()['id']]);$rows=$q->fetchAll();
} else $rows=$pdo->query("SELECT f.*,s.full_name,a.level,a.institution FROM school_fee_payments f JOIN rescued_students s ON s.id=f.student_id JOIN school_admissions a ON a.id=f.admission_id ORDER BY f.id DESC")->fetchAll();
require __DIR__.'/partials/header.php';
?><div class="hero"><div><h1>School Fees</h1><p>Payments are tied to a rescued student and a specific school admission.</p></div><a class="btn" href="?action=add">+ Record payment</a></div>
<?php if($action==='add'): ?><div class="card"><h3>Record school fee payment</h3><form method="post"><?=csrf_field()?><div class="formgrid"><div class="field full"><label>Admission / student</label><select name="admission_id" required><option value="">Select admission</option><?php foreach($admissions as $a):?><option value="<?=$a['id']?>"><?=e($a['full_name'])?> — <?=e($a['level'])?> — <?=e($a['institution'])?><?= $a['course_or_class']?' — '.e($a['course_or_class']):''?></option><?php endforeach;?></select></div><div class="field"><label>Amount (KSh)</label><input type="number" name="amount" step="0.01" min="0.01" required></div><div class="field"><label>Payment date</label><input type="date" name="payment_date" value="<?=date('Y-m-d')?>" required></div><div class="field"><label>Reference</label><input type="text" name="reference_no"></div><div class="field full"><label>Description</label><input type="text" name="description" required></div></div><div class="form-actions"><button class="btn">Save payment</button><a class="btn secondary" href="fees.php">Cancel</a></div></form></div>
<?php else:?><div class="card"><div class="tablewrap"><table class="table"><tr><th>Date</th><th>Student</th><th>Level</th><th>Institution</th><th>Amount</th><th>Reference</th><th>Actions</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['payment_date'])?></td><td><?=e($r['full_name'])?></td><td><?=e($r['level'])?></td><td><?=e($r['institution'])?></td><td><?=money((float)$r['amount'])?></td><td><?=e($r['reference_no']??'')?></td><td><?php if(can_manage_records()):?><a class="btn small" href="record_manager.php?entity=fees&id=<?=$r['id']?>">Edit / Update</a><form class="inline-form" method="post" action="record_manager.php?entity=fees&amp;id=<?=$r['id']?>"><?=csrf_field()?><input type="hidden" name="op" value="delete"><button class="btn small danger" type="submit" data-confirm="Delete this fee record?">Delete</button></form><?php endif;?> <button class="btn small secondary" onclick="window.print()">Print</button></td></tr><?php endforeach;?></table></div></div><?php endif;require __DIR__.'/partials/footer.php';?>
