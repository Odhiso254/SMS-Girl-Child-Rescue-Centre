@echo off
setlocal
cd /d C:\xampp\htdocs\final_rfs
C:\xampp\php\php.exe cron\auto_backup.php
