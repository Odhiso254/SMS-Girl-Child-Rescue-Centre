<?php
// Run this file once daily from Windows Task Scheduler or Linux cron.
require __DIR__.'/../config/config.php';
if(system_is_locked($pdo)){exit("System locked; petty cash reminders stopped.\n");}
create_daily_petty_cash_reminders($pdo);
echo "Daily petty cash reminders checked.\n";
