@echo off
echo Checking PHP...
php -v
echo.
echo Checking MySQL...
mysql --version
echo.
echo Open the application at:
echo http://localhost/final_rfs/
