@echo off
setlocal
set "BACKUP_DIR=%~dp0backups"
if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"
for /f "tokens=1-3 delims=/ " %%a in ("%date%") do set "D=%%c%%b%%a"
for /f "tokens=1-2 delims=: " %%a in ("%time%") do set "T=%%a%%b"
set "OUT=%BACKUP_DIR%\smi_girl_child_rescue_%D%_%T%.sql"
echo Creating database backup...
mysqldump -h 127.0.0.1 -u root farm > "%OUT%"
if errorlevel 1 (
  echo Backup failed. Check MySQL credentials and PATH.
  exit /b 1
)
echo Backup created: %OUT%
