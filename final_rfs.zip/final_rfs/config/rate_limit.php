<?php
function login_rate_limited(PDO $pdo, string $username, string $ip): bool {
    $s = $pdo->prepare(
        "SELECT COUNT(*) AS n FROM login_activity
         WHERE username = ? AND ip_address = ? AND success = 0
         AND created_at >= (NOW() - INTERVAL 15 MINUTE)"
    );
    $s->execute([$username, $ip]);
    return (int)$s->fetch()['n'] >= 7;
}
function record_login_attempt(PDO $pdo, ?int $userId, string $username, string $role, bool $success, string $ip): void {
    $s = $pdo->prepare(
        "INSERT INTO login_activity(user_id,username,role,success,ip_address) VALUES(?,?,?,?,?)"
    );
    $s->execute([$userId, $username, $role, $success ? 1 : 0, $ip]);
}
