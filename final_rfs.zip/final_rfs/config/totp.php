<?php
function base32_decode_custom(string $input): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $input = strtoupper(preg_replace('/[^A-Z2-7]/', '', $input));
    $bits = '';
    for ($i=0; $i<strlen($input); $i++) {
        $v = strpos($alphabet, $input[$i]);
        if ($v === false) continue;
        $bits .= str_pad(decbin($v), 5, '0', STR_PAD_LEFT);
    }
    $out = '';
    for ($i=0; $i+7 < strlen($bits); $i += 8) {
        $out .= chr(bindec(substr($bits, $i, 8)));
    }
    return $out;
}
function base32_encode_custom(string $input): string {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    for ($i=0; $i<strlen($input); $i++) $bits .= str_pad(decbin(ord($input[$i])), 8, '0', STR_PAD_LEFT);
    $out = '';
    for ($i=0; $i<strlen($bits); $i+=5) {
        $chunk = substr($bits, $i, 5);
        if (strlen($chunk)<5) $chunk = str_pad($chunk,5,'0');
        $out .= $alphabet[bindec($chunk)];
    }
    return $out;
}
function totp_secret(): string {
    return base32_encode_custom(random_bytes(20));
}
function totp_code(string $secret, ?int $time=null): string {
    $time ??= time();
    $counter = intdiv($time, 30);
    $bin = pack('N2', ($counter >> 32) & 0xffffffff, $counter & 0xffffffff);
    $hash = hash_hmac('sha1', $bin, base32_decode_custom($secret), true);
    $offset = ord($hash[19]) & 0x0f;
    $num = ((ord($hash[$offset]) & 0x7f) << 24) |
           ((ord($hash[$offset+1]) & 0xff) << 16) |
           ((ord($hash[$offset+2]) & 0xff) << 8) |
           (ord($hash[$offset+3]) & 0xff);
    return str_pad((string)($num % 1000000), 6, '0', STR_PAD_LEFT);
}
function totp_verify(string $secret, string $code): bool {
    $code = preg_replace('/\D/', '', $code);
    if (strlen($code) !== 6) return false;
    for ($offset=-1; $offset<=1; $offset++) {
        if (hash_equals(totp_code($secret, time()+($offset*30)), $code)) return true;
    }
    return false;
}
function generate_backup_codes(PDO $pdo, int $userId): array {
    $pdo->prepare("DELETE FROM user_backup_codes WHERE user_id=?")->execute([$userId]);
    $stmt = $pdo->prepare("INSERT INTO user_backup_codes(user_id,code_hash) VALUES(?,?)");
    $codes = [];
    for ($i=0; $i<8; $i++) {
        $code = strtoupper(bin2hex(random_bytes(4)));
        $codes[] = $code;
        $stmt->execute([$userId, password_hash($code, PASSWORD_DEFAULT)]);
    }
    return $codes;
}
