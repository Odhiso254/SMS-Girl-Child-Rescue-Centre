<?php
declare(strict_types=1);
ini_set('display_errors','0');
ini_set('log_errors','1');
ini_set('error_log', __DIR__ . '/../storage/php-error.log');
if (!is_dir(__DIR__ . '/../storage')) { @mkdir(__DIR__ . '/../storage', 0775, true); }
set_exception_handler(function (Throwable $e): void {
    error_log($e->__toString());
    if (!headers_sent()) { http_response_code(500); }
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>System Error</title><link rel="stylesheet" href="assets/style.css"></head><body><main class="content"><div class="card"><h1>Something went wrong</h1><p>The requested operation could not be completed. Your data was not intentionally exposed. Check the PHP error log for the administrator.</p><div class="form-actions"><a class="btn" href="index.php">Return to dashboard</a></div></div></main></body></html>';
    exit;
});

/*
 * SMI Girl Child Rescue Centre / Integrated Management System
 * XAMPP-ready secure configuration.
 */
$isHttps = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

ini_set('session.use_only_cookies', '1');
ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Strict');
if ($isHttps) ini_set('session.cookie_secure', '1');
ini_set('session.cookie_lifetime', '0');

session_name('SMISESSID');
session_start();
if (!isset($_SESSION['initiated'])) { session_regenerate_id(true); $_SESSION['initiated'] = time(); }

define('APP_NAME', 'SUGUTA · SMI Girl Child Rescue Centre');
define('APP_VERSION', '8.0.0');
// Configure this server email address if PHP mail() is enabled.
define('MAIL_FROM', 'no-reply@smirescuecentre.local');
define('BASE_URL', '');
// Director messaging (Twilio). Leave blank to disable external sending safely.
define('DIRECTOR_NAME', 'Sister Suguta');
define('DIRECTOR_PHONE', '+254724870350');
define('TWILIO_ACCOUNT_SID', getenv('TWILIO_ACCOUNT_SID') ?: '');
define('TWILIO_AUTH_TOKEN', getenv('TWILIO_AUTH_TOKEN') ?: '');
define('TWILIO_SMS_FROM', getenv('TWILIO_SMS_FROM') ?: '');
define('TWILIO_WHATSAPP_FROM', getenv('TWILIO_WHATSAPP_FROM') ?: '');


$dbHost = '127.0.0.1';
$dbName = 'farm';
$dbUser = 'root';
$dbPass = '';

try {
    $pdo = new PDO(
        "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4",
        $dbUser,
        $dbPass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Import database/farm.sql and verify config/config.php.');
}


// Repair incomplete/legacy databases before any module queries run.
// This is idempotent and never drops tables or deletes existing records.
require_once __DIR__ . '/schema_repair.php';
try { repair_database_schema($pdo); } catch (Throwable $e) { error_log('Schema repair bootstrap: '.$e->getMessage()); }

/* Automatic rolling SQL backup. */
function run_database_backup(PDO $pdo): ?string {
    $backupDir = __DIR__ . '/../storage/backups';
    if (!is_dir($backupDir) && !@mkdir($backupDir, 0775, true)) return null;
    $lockPath = $backupDir . '/.backup.lock';
    $lock = @fopen($lockPath, 'c');
    if (!$lock || !@flock($lock, LOCK_EX | LOCK_NB)) { if ($lock) @fclose($lock); return null; }
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (setting_key VARCHAR(80) PRIMARY KEY, setting_value TEXT NULL, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $last = $pdo->query("SELECT setting_value FROM system_settings WHERE setting_key='last_auto_backup_at' LIMIT 1")->fetchColumn();
        if ($last) { $ts=strtotime((string)$last); if ($ts !== false && $ts > time()-86400) return null; }
        $filename='farm_auto_'.date('Y-m-d_H-i-s').'.sql'; $path=$backupDir.'/'.$filename;
        $fh=@fopen($path,'wb'); if(!$fh) return null;
        fwrite($fh,"-- SUGUTA automatic database backup\n-- Generated ".date('c')."\nCREATE DATABASE IF NOT EXISTS `farm` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\nUSE `farm`;\nSET FOREIGN_KEY_CHECKS=0;\n");
        $tables=$pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach($tables as $table){
            if(!preg_match('/^[A-Za-z0-9_]+$/',(string)$table)) continue;
            $create=$pdo->query("SHOW CREATE TABLE `{$table}`")->fetch(PDO::FETCH_NUM); if(!$create) continue;
            fwrite($fh,"\nDROP TABLE IF EXISTS `{$table}`;\n".$create[1].";\n");
            $stmt=$pdo->query("SELECT * FROM `{$table}`");
            while($row=$stmt->fetch(PDO::FETCH_ASSOC)){
                $vals=[]; foreach($row as $v) $vals[]=$v===null?'NULL':$pdo->quote((string)$v);
                fwrite($fh,"INSERT INTO `{$table}` (`".implode('`,`',array_keys($row))."`) VALUES (".implode(',',$vals).");\n");
            }
        }
        fwrite($fh,"\nSET FOREIGN_KEY_CHECKS=1;\n"); fclose($fh);
        $pdo->prepare("INSERT INTO system_settings(setting_key,setting_value) VALUES('last_auto_backup_at',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")->execute([date('Y-m-d H:i:s')]);
        $files=glob($backupDir.'/farm_auto_*.sql')?:[]; usort($files,static fn($a,$b)=>filemtime($b)<=>filemtime($a));
        foreach(array_slice($files,14) as $old) @unlink($old);
        return $path;
    } catch(Throwable $e){ if(isset($fh)&&is_resource($fh))@fclose($fh); if(isset($path)&&is_file($path))@unlink($path); error_log('Automatic backup failed: '.$e->getMessage()); return null; }
    finally { @flock($lock,LOCK_UN); @fclose($lock); }
}
function automatic_backup_if_due(PDO $pdo): void { try{run_database_backup($pdo);}catch(Throwable $e){error_log('Automatic backup bootstrap: '.$e->getMessage());} }


/*
 * Local installation license.
 * The unlock secret is stored only as a one-way SHA-256 digest; the literal
 * unlock code is intentionally not stored in the application files.
 */
define('LICENSE_DAYS', 30);
define('LICENSE_EXPIRES_AT', '2026-10-18 13:22:19');
define('LICENSE_UNLOCK_DIGEST', 'ad2d8e819ecd14c51d76d1d7a7aa47f0c17ef04d7766b730f41fb34e7adb05ff');

function ensure_system_settings(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
        setting_key VARCHAR(80) PRIMARY KEY,
        setting_value TEXT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $q=$pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key='install_started_at' LIMIT 1");
    $q->execute();
    if (!$q->fetchColumn()) {
        $now=date('Y-m-d H:i:s');
        $pdo->prepare("INSERT INTO system_settings(setting_key,setting_value) VALUES('install_started_at',?)")->execute([$now]);
    }
}

function license_status(PDO $pdo): array {
    ensure_system_settings($pdo);
    $q=$pdo->prepare("SELECT setting_key,setting_value FROM system_settings WHERE setting_key IN ('install_started_at','unlocked_at','last_seen_at')");
    $q->execute();
    $settings=[];
    foreach($q->fetchAll() as $row) $settings[$row['setting_key']]=$row['setting_value'];
    if (!empty($settings['unlocked_at'])) {
        return ['locked'=>false,'permanent'=>true,'install_at'=>$settings['install_started_at']??null,'expires_at'=>null,'clock_tampered'=>false];
    }
    $install=$settings['install_started_at']??date('Y-m-d H:i:s');
    $now=new DateTimeImmutable('now');
    $expires=new DateTimeImmutable(LICENSE_EXPIRES_AT);
    $clockTampered=!empty($settings['last_seen_at']) && $now < new DateTimeImmutable($settings['last_seen_at']);
    if (!$clockTampered) {
        $pdo->prepare("INSERT INTO system_settings(setting_key,setting_value) VALUES('last_seen_at',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")
            ->execute([$now->format('Y-m-d H:i:s')]);
    }
    return ['locked'=>($clockTampered || $now >= $expires),'permanent'=>false,'clock_tampered'=>$clockTampered,
            'install_at'=>$install,'expires_at'=>$expires->format('Y-m-d H:i:s')];
}

function system_is_locked(PDO $pdo): bool {
    return (bool)license_status($pdo)['locked'];
}

function unlock_system(PDO $pdo, string $code): bool {
    if (!hash_equals(LICENSE_UNLOCK_DIGEST, hash('sha256', trim($code)))) return false;
    $pdo->prepare("INSERT INTO system_settings(setting_key,setting_value) VALUES('unlocked_at',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)")
        ->execute([date('Y-m-d H:i:s')]);
    audit($pdo,'System permanently unlocked','system_settings',null,'Administrator supplied the valid unlock credential.');
    return true;
}

function locked_page(PDO $pdo): never {
    $status=license_status($pdo);
    http_response_code(423);
    $message=$status['clock_tampered']
        ? 'The system detected an invalid server clock change and has been locked.'
        : 'The 30-day installation period has ended. An administrator must unlock the system.';
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>System Locked</title><style>body{font-family:Arial,sans-serif;background:#f4f7f6;margin:0;display:grid;place-items:center;min-height:100vh}.box{background:#fff;max-width:560px;padding:32px;border-radius:16px;box-shadow:0 12px 40px #0001;text-align:center}h1{margin-top:0}a{display:inline-block;padding:12px 18px;border-radius:8px;text-decoration:none;background:#0d6b4a;color:#fff;font-weight:700}</style></head><body><div class="box"><h1>System Locked</h1><p>'.e($message).'</p><p>Only the administrator can restore permanent access.</p><a href="index.php">Administrator Dashboard</a></div></body></html>';
    exit;
}

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = (string)($_POST['csrf'] ?? '');
        if (!hash_equals($_SESSION['csrf'] ?? '', $token)) {
            http_response_code(419);
            exit('Invalid security token. Refresh the page and try again.');
        }
    }
}
function flash(string $type, string $message): void {
    $_SESSION['flash'][] = ['type'=>$type, 'message'=>$message];
}
function flashes(): array {
    $x = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $x;
}
function logged_in(): bool {
    return isset($_SESSION['user']['id']);
}
function user(): array {
    return $_SESSION['user'] ?? [];
}

/* Route-level RBAC: direct URL access is protected as well as navigation. */
function role(): string {
    return (string)(user()['role'] ?? '');
}
function allowed_roles(string ...$roles): bool {
    return in_array(role(), $roles, true);
}
function require_login(): void {
    /*
     * The PDO connection is created in the global scope of this file, so it
     * must be imported here before the licence lock check uses it.
     */
    global $pdo;

    if (!logged_in()) redirect('login.php');

    $page = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $r = role();

    /*
     * Strict route-level RBAC.
     * Hiding a navigation link is NOT treated as security by itself:
     * direct URL access is blocked here as well.
     */
    $permissions = [
        'index.php'             => ['admin','staff','manager','director','coordinator','farmer','doctor','student','donor'],
        'students.php'          => ['admin','staff','manager','director','coordinator'],
        'rescue_incidents.php'  => ['admin','staff','manager','director','coordinator'],
        'emergency_types.php'   => ['admin','staff','manager','director','coordinator'],
        'traditions.php'        => ['admin','staff','manager','director','coordinator'],
        'donors.php'            => ['admin','director','donor'],
        'support.php'           => ['admin','director','donor'],
        'admissions.php'        => ['admin','staff','manager','director','coordinator','student'],
        'fees.php'              => ['admin','staff','manager','director','coordinator','student'],
        'hospitals.php'         => ['admin','staff','manager','director','coordinator','doctor'],
        'hospital_visits.php'   => ['admin','staff','manager','director','coordinator','doctor'],
        'treatments.php'        => ['admin','staff','manager','director','coordinator','doctor'],
        'farm.php'              => ['admin','staff','manager','director','coordinator','farmer'],
        'reports.php'           => ['admin','staff','manager','director','coordinator'],
        'audit.php'             => ['admin','director'],
        'settings.php'          => ['admin','director'],
        'system_health.php'     => ['admin'],
        'users.php'             => ['admin','director'],
        'petty_cash.php'        => ['admin','director'],
        'backup.php'            => ['admin','director'],
        'restore.php'           => ['admin','director'],
        'unlock.php'            => ['admin'],
        'record_manager.php'    => ['admin','director'],
        'notifications.php'     => ['admin','staff','manager','director','coordinator','farmer','doctor','student','donor'],
        '2fa_setup.php'         => ['admin','staff','manager','director','coordinator','farmer','doctor','student','donor'],
        'change_password.php'   => ['admin','staff','manager','director','coordinator','farmer','doctor','student','donor'],
        'forgot_password.php'   => ['admin','staff','manager','director','coordinator','farmer','doctor','student','donor'],
    ];

    if (!isset($permissions[$page]) || !in_array($r, $permissions[$page], true)) {
        http_response_code(403);
        exit('403 Forbidden — this module is outside your assigned field.');
    }

    // The dashboard remains available so an administrator can unlock the
    // installation. Every other protected program stops when locked.
    if ($pdo instanceof PDO && !in_array($page, ['index.php','unlock.php'], true) && system_is_locked($pdo)) {
        locked_page($pdo);
    }
}


function can_manage_records(): bool { return in_array(role(), ['admin','director'], true); }
function can_use_petty_cash(): bool { return in_array(role(), ['admin','director'], true); }
function require_approved(): void {
    if (!logged_in()) redirect('login.php');
    if (empty($_SESSION['user']['is_active'])) {
        session_unset(); session_destroy(); redirect('login.php?pending=1');
    }
}
function money(float $n): string {
    return 'KSh ' . number_format($n, 2);
}
function audit(PDO $pdo, string $action, string $entity='', ?int $entityId=null, string $details=''): void {
    try {
        $s = $pdo->prepare(
            'INSERT INTO audit_logs(user_id,action,details,entity,entity_id,ip_address)
             VALUES(?,?,?,?,?,?)'
        );
        $s->execute([
            user()['id'] ?? null, $action, $details, $entity, $entityId,
            $_SERVER['REMOTE_ADDR'] ?? 'CLI'
        ]);
    } catch (Throwable $e) {
        // Do not expose audit/database errors to visitors.
    }
}

function notify(PDO $pdo, ?int $userId, string $title, string $message, ?string $recipientRole=null, ?string $link=null): void {
    try {
        $s=$pdo->prepare('INSERT INTO notifications(user_id,recipient_role,title,message,link) VALUES(?,?,?,?,?)');
        $s->execute([$userId,$recipientRole,$title,$message,$link]);
    } catch(Throwable $e) { /* Notifications must never break the main workflow. */ }
}

function send_user_email(?string $email, string $subject, string $message): bool {
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) return false;
    $headers = 'From: ' . MAIL_FROM . "\r\n" . 'Content-Type: text/plain; charset=UTF-8';
    try { return @mail($email, $subject, $message, $headers); } catch (Throwable $e) { return false; }
}


function twilio_send_message(string $to, string $body, bool $whatsapp=false): array {
    if (TWILIO_ACCOUNT_SID === '' || TWILIO_AUTH_TOKEN === '') return ['status'=>'skipped','id'=>null,'response'=>'Twilio credentials are not configured.'];
    $from = $whatsapp ? TWILIO_WHATSAPP_FROM : TWILIO_SMS_FROM;
    if ($from === '') return ['status'=>'skipped','id'=>null,'response'=>'Twilio sender is not configured.'];
    $toValue = $whatsapp ? 'whatsapp:'.$to : $to;
    $fromValue = $whatsapp ? (str_starts_with($from,'whatsapp:')?$from:'whatsapp:'.$from) : $from;
    $ch = curl_init('https://api.twilio.com/2010-04-01/Accounts/'.rawurlencode(TWILIO_ACCOUNT_SID).'/Messages.json');
    curl_setopt_array($ch, [
        CURLOPT_POST=>true, CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>12,
        CURLOPT_USERPWD=>TWILIO_ACCOUNT_SID.':'.TWILIO_AUTH_TOKEN,
        CURLOPT_POSTFIELDS=>http_build_query(['To'=>$toValue,'From'=>$fromValue,'Body'=>$body]),
    ]);
    $raw=curl_exec($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch);
    if($raw===false) return ['status'=>'failed','id'=>null,'response'=>$err?:'Network error'];
    $data=json_decode($raw,true) ?: [];
    if($http>=200 && $http<300) return ['status'=>'sent','id'=>$data['sid']??null,'response'=>$raw];
    return ['status'=>'failed','id'=>$data['sid']??null,'response'=>$raw];
}
function send_director_periodic_messages(PDO $pdo, string $period): array {
    $period = in_array($period,['morning','evening'],true) ? $period : 'morning';
    $date=date('Y-m-d');
    $incidentCount=(int)$pdo->query("SELECT COUNT(*) FROM rescue_incidents WHERE incident_date=CURDATE()")->fetchColumn();
    $rescueCount=(int)$pdo->query("SELECT COUNT(*) FROM rescued_students WHERE rescue_date=CURDATE()")->fetchColumn();
    $visits=(int)$pdo->query("SELECT COUNT(*) FROM hospital_visits WHERE visit_date=CURDATE()")->fetchColumn();
    $petty=(float)$pdo->query("SELECT COALESCE(SUM(CASE WHEN transaction_type='Income' THEN amount ELSE -amount END),0) FROM petty_cash")->fetchColumn();
    $greeting=$period==='morning' ? 'Good morning' : 'Good evening';
    $body=$greeting.' '.DIRECTOR_NAME.'. SUGUTA system update: '.date('d M Y').'. Rescue incidents today: '.$incidentCount.'. New rescue profiles today: '.$rescueCount.'. Hospital visits today: '.$visits.'. Petty cash balance: '.money($petty).'. Please review the SUGUTA management system for full details.';
    $results=[];
    foreach([false,true] as $wa){
        $channel=$wa?'whatsapp':'sms';
        try {
            $q=$pdo->prepare('SELECT id,status FROM director_message_logs WHERE message_date=? AND period=? AND channel=? LIMIT 1');
            $q->execute([$date,$period,$channel]); $existing=$q->fetch();
            if($existing && $existing['status']==='sent'){ $results[$channel]='already_sent'; continue; }
            $r=twilio_send_message(DIRECTOR_PHONE,$body,$wa);
            $ins=$pdo->prepare('INSERT INTO director_message_logs(message_date,period,channel,recipient,status,provider_message_id,response_text) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status),provider_message_id=VALUES(provider_message_id),response_text=VALUES(response_text)');
            $ins->execute([$date,$period,$channel,DIRECTOR_PHONE,$r['status'],$r['id'],$r['response']]);
            $results[$channel]=$r['status'];
        } catch(Throwable $e){ $results[$channel]='failed'; }
    }
    return $results;
}

function create_daily_petty_cash_reminders(PDO $pdo): void {
    // A daily notification is created the first time the system is opened each day.
    try {
        $today = date('Y-m-d');
        $check = $pdo->prepare("SELECT id FROM notifications WHERE recipient_role='director' AND title='Daily petty cash reminder' AND DATE(created_at)=? LIMIT 1");
        $check->execute([$today]);
        if ($check->fetch()) return;
        notify($pdo, null, 'Daily petty cash reminder', 'Director: please review and record today’s petty cash activity. The recorded information is automatically available to the administrator for oversight.', 'director', 'petty_cash.php');
        notify($pdo, null, 'Daily petty cash information', 'A daily petty cash review reminder has been issued to the Director. Please review petty cash records and follow up as necessary.', 'admin', 'petty_cash.php');
    } catch (Throwable $e) { }
}

function unread_notifications(PDO $pdo): int {
    try {
        $s=$pdo->prepare('SELECT COUNT(*) FROM notifications WHERE is_read=0 AND (user_id=? OR (user_id IS NULL AND recipient_role=?))');
        $s->execute([user()['id']??0, role()]);
        return (int)$s->fetchColumn();
    } catch(Throwable $e) { return 0; }
}

function security_headers(): void {
    header('X-Frame-Options: SAMEORIGIN');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'");
}
security_headers();
if (!system_is_locked($pdo)) { automatic_backup_if_due($pdo); create_daily_petty_cash_reminders($pdo); }
