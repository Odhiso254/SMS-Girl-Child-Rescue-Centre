<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
if(!can_use_petty_cash()){http_response_code(403);exit('403 Forbidden — Petty Cash is available only to Admin and Director.');}
$title='Petty Cash'; $page='petty_cash'; $action=$_GET['action']??'list'; $id=(int)($_GET['id']??0);

function valid_date_value(string $d): bool {
    $x=DateTimeImmutable::createFromFormat('Y-m-d',$d);
    return $x && $x->format('Y-m-d')===$d;
}
function month_start(string $d): string {
    if (preg_match('/^\d{4}-\d{2}$/',$d)) $d.='-01';
    return (new DateTimeImmutable($d))->modify('first day of this month')->format('Y-m-d');
}
function previous_month(string $month): string {
    return (new DateTimeImmutable($month))->modify('-1 month')->format('Y-m-d');
}
function petty_month(PDO $pdo,string $month): ?array {
    $q=$pdo->prepare('SELECT * FROM petty_cash_months WHERE month_start=? LIMIT 1');
    $q->execute([$month]); return $q->fetch() ?: null;
}
function petty_opening_debt(PDO $pdo,string $month): float {
    $prev=petty_month($pdo,previous_month($month));
    return (float)($prev['carried_forward_debt']??0);
}
function petty_month_net(PDO $pdo,string $month): float {
    $q=$pdo->prepare("SELECT COALESCE(SUM(CASE WHEN transaction_type='Income' THEN amount ELSE -amount END),0) FROM petty_cash WHERE transaction_date>=? AND transaction_date<DATE_ADD(?,INTERVAL 1 MONTH)");
    $q->execute([$month,$month]); return (float)$q->fetchColumn();
}

if($_SERVER['REQUEST_METHOD']==='POST'){
 $op=(string)($_POST['op']??'save'); $id=(int)($_POST['id']??0);
 try{
  if($op==='save_monthly_record'){
      if(role()!=='admin') throw new RuntimeException('Only the administrator can record monthly petty cash.');
      $month=month_start((string)($_POST['monthly_month']??date('Y-m-d')));
      $amount=(float)($_POST['monthly_amount']??0); $notes=trim((string)($_POST['monthly_notes']??''));
      if($amount<0) throw new RuntimeException('Monthly petty cash amount cannot be negative.');
      $q=$pdo->prepare("INSERT INTO petty_cash_monthly_records(month_start,amount,notes,recorded_by) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE amount=VALUES(amount),notes=VALUES(notes),recorded_by=VALUES(recorded_by)");
      $q->execute([$month,$amount,$notes?:null,user()['id']]);
      audit($pdo,'Recorded monthly petty cash','petty_cash_monthly_records',null,'Month '.$month.'; amount '.money($amount).'.');
      flash('success','Monthly petty cash recorded for '.date('F Y',strtotime($month)).'.');
  } elseif($op==='delete'){
      $pdo->prepare('DELETE FROM petty_cash WHERE id=?')->execute([$id]);
      audit($pdo,'Deleted petty cash record','petty_cash',$id); flash('success','Petty cash record deleted.');
  } elseif($op==='save_month'){
      $month=month_start((string)($_POST['month_start']??date('Y-m-d')));
      $opening=petty_opening_debt($pdo,$month);
      $net=petty_month_net($pdo,$month);
      $settled=max(0,(float)($_POST['debt_settled']??0));
      $settled=min($settled,$opening,max(0,$net));
      $carry=!empty($_POST['carry_forward']);
      $deficit=max(0,-$net);
      if(!$carry && ($opening-$settled)>0.009) throw new RuntimeException('An unpaid previous-month debt must be carried forward or fully settled first.');
      $carried=max(0,$opening-$settled)+($carry?$deficit:0);
      $notes=trim((string)($_POST['month_notes']??''));
      $q=$pdo->prepare("INSERT INTO petty_cash_months(month_start,debt_settled,carried_forward_debt,notes,updated_by) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE debt_settled=VALUES(debt_settled),carried_forward_debt=VALUES(carried_forward_debt),notes=VALUES(notes),updated_by=VALUES(updated_by)");
      $q->execute([$month,$settled,$carried,$notes?:null,user()['id']]);
      audit($pdo,'Updated petty cash monthly debt','petty_cash_months',null,'Month '.$month.'; opening debt '.money($opening).'; settled '.money($settled).'; carried '.money($carried).'.');
      flash('success','Petty cash month updated. Debt carry-forward is now '.$carried.' KSh.');
  } else {
   $type=($_POST['transaction_type']??'Expense')==='Income'?'Income':'Expense';
   $cat=trim((string)($_POST['category']??'')); $amount=(float)($_POST['amount']??0);
   $date=(string)($_POST['transaction_date']??''); $pf=trim((string)($_POST['paid_to_from']??''));
   $ref=trim((string)($_POST['reference_no']??'')); $desc=trim((string)($_POST['description']??''));
   if(!$cat||$amount<=0||!valid_date_value($date)||!$desc) throw new RuntimeException('Category, positive amount, valid date and description are required.');
   if($id){
      $pdo->prepare('UPDATE petty_cash SET transaction_type=?,category=?,amount=?,transaction_date=?,paid_to_from=?,reference_no=?,description=? WHERE id=?')->execute([$type,$cat,$amount,$date,$pf?:null,$ref?:null,$desc,$id]);
      audit($pdo,'Updated petty cash record','petty_cash',$id);
      if(role()==='director') notify($pdo,null,'Director petty cash update',user()['full_name'].' updated petty cash record #'.$id.' ('.money($amount).') on '.$date.'.','admin','petty_cash.php');
      flash('success','Petty cash updated.');
   } else {
      $pdo->prepare('INSERT INTO petty_cash(transaction_type,category,amount,transaction_date,paid_to_from,reference_no,description,created_by) VALUES(?,?,?,?,?,?,?,?)')->execute([$type,$cat,$amount,$date,$pf?:null,$ref?:null,$desc,user()['id']]);
      $newPettyId=(int)$pdo->lastInsertId();
      audit($pdo,'Created petty cash record','petty_cash',$newPettyId);
      if(role()==='director') notify($pdo,null,'Director petty cash information',user()['full_name'].' recorded '.$type.' petty cash of '.money($amount).' for '.$date.'. The information is now available to the administrator.','admin','petty_cash.php');
      flash('success','Petty cash recorded. Automatic record number: PC-'.str_pad((string)$newPettyId,6,'0',STR_PAD_LEFT).'.');
   }
  }
 }catch(Throwable $e){flash('error',$e instanceof RuntimeException?$e->getMessage():'Could not complete the petty cash operation.');}
 redirect('petty_cash.php');
}

$edit=null;
if($action==='edit'&&$id){$q=$pdo->prepare('SELECT * FROM petty_cash WHERE id=?');$q->execute([$id]);$edit=$q->fetch();}

$from=trim((string)($_GET['from']??'')); $to=trim((string)($_GET['to']??'')); $search=trim((string)($_GET['q']??''));
$where=[];$params=[];
if($from!==''){if(valid_date_value($from)){$where[]='transaction_date>=?';$params[]=$from;}else{$from='';}}
if($to!==''){if(valid_date_value($to)){$where[]='transaction_date<=?';$params[]=$to;}else{$to='';}}
if($search!==''){
  $where[]='(category LIKE ? OR paid_to_from LIKE ? OR reference_no LIKE ? OR description LIKE ? OR CAST(id AS CHAR) LIKE ?)';
  foreach(array_fill(0,5,'%'.$search.'%') as $v)$params[]=$v;
}
$sql='SELECT * FROM petty_cash'.($where?' WHERE '.implode(' AND ',$where):'').' ORDER BY transaction_date DESC,id DESC';
$q=$pdo->prepare($sql);$q->execute($params);$rows=$q->fetchAll();

$income=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM petty_cash WHERE transaction_type='Income'")->fetchColumn();
$expense=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM petty_cash WHERE transaction_type='Expense'")->fetchColumn();
$balance=$income-$expense;

$selectedMonth=month_start((string)($_GET['month']??date('Y-m-d')));
$openingDebt=petty_opening_debt($pdo,$selectedMonth);
$monthNet=petty_month_net($pdo,$selectedMonth);
$monthRow=petty_month($pdo,$selectedMonth);
$settled=(float)($monthRow['debt_settled']??0);
$carried=(float)($monthRow['carried_forward_debt']??0);
$defaultCarry=($openingDebt>0.009 || $monthNet< -0.009);
$monthHistory=$pdo->query('SELECT * FROM petty_cash_months ORDER BY month_start DESC LIMIT 24')->fetchAll();
$monthlyRecords=$pdo->query('SELECT * FROM petty_cash_monthly_records ORDER BY month_start DESC LIMIT 24')->fetchAll();
$selectedMonthly=$pdo->prepare('SELECT * FROM petty_cash_monthly_records WHERE month_start=? LIMIT 1');
$selectedMonthly->execute([$selectedMonth]);
$selectedMonthlyRecord=$selectedMonthly->fetch() ?: null;

require __DIR__.'/partials/header.php';?>
<div class="hero">
 <div><h1>Petty Cash</h1><p>Admin and Director financial control, monthly debt carry-forward and searchable cash reporting.</p></div>
 <div class="hero-actions"><a class="btn" href="?action=add">+ Add petty cash</a><button class="btn secondary" onclick="window.print()">Print current report</button></div>
</div>
<div class="cards">
 <div class="card metric"><div class="label">CASH IN</div><div class="value"><?=money($income)?></div></div>
 <div class="card metric"><div class="label">CASH OUT</div><div class="value"><?=money($expense)?></div></div>
 <div class="card metric"><div class="label">BALANCE</div><div class="value"><?=money($balance)?></div></div>
 <div class="card metric"><div class="label">CARRIED DEBT</div><div class="value"><?=money($carried)?></div><div class="hint"><?=e($selectedMonth)?></div></div>
</div>

<?php if($action==='add'||$edit):?>
<div class="card" style="margin-top:16px"><h3><?=$edit?'Edit petty cash':'Add petty cash'?></h3>
<form method="post"><?=csrf_field()?><input type="hidden" name="op" value="save"><input type="hidden" name="id" value="<?=$edit?(int)$edit['id']:0?>">
<div class="formgrid">
<div class="field"><label>Type</label><select name="transaction_type"><option <?=$edit&&$edit['transaction_type']==='Income'?'selected':''?>>Income</option><option <?=$edit&&$edit['transaction_type']==='Expense'?'selected':''?>>Expense</option></select></div>
<div class="field"><label>Category</label><input name="category" required value="<?=e($edit['category']??'')?>" placeholder="Transport, food, stationery..."></div>
<div class="field"><label>Amount (KSh)</label><input type="number" step="0.01" min="0.01" name="amount" required value="<?=e((string)($edit['amount']??''))?>"></div>
<div class="field"><label>Date</label><input type="date" name="transaction_date" required value="<?=e($edit['transaction_date']??date('Y-m-d'))?>"></div>
<div class="field"><label>Paid to / received from</label><input name="paid_to_from" value="<?=e($edit['paid_to_from']??'')?>"></div>
<div class="field"><label>Reference</label><input name="reference_no" value="<?=e($edit['reference_no']??'')?>"></div>
<div class="field full"><label>Description</label><input name="description" required value="<?=e($edit['description']??'')?>"></div>
</div><div class="form-actions"><button class="btn"><?=$edit?'Update':'Save'?></button><a class="btn secondary" href="petty_cash.php">Cancel</a></div>
</form></div>
<?php endif;?>

<?php if(role()==='admin'): ?>
<div class="card" style="margin-top:16px">
<h3>Record monthly petty cash</h3>
<p class="hint">Enter the petty cash amount allocated/recorded for a month. This monthly record is kept separately from individual petty-cash transactions and does not change the existing transaction balance automatically.</p>
<form method="post"><?=csrf_field()?><input type="hidden" name="op" value="save_monthly_record">
<div class="formgrid">
<div class="field"><label>Month</label><input type="month" name="monthly_month" value="<?=e(substr($selectedMonth,0,7))?>" required></div>
<div class="field"><label>Monthly petty cash (KSh)</label><input type="number" step="0.01" min="0" name="monthly_amount" value="<?=e(number_format((float)($selectedMonthlyRecord['amount']??0),2,'.',''))?>" required></div>
<div class="field full"><label>Notes</label><input name="monthly_notes" value="<?=e($selectedMonthlyRecord['notes']??'')?>" placeholder="Purpose, allocation or monthly remarks"></div>
</div><div class="form-actions"><button class="btn">Save monthly petty cash</button></div>
</form>
<div class="tablewrap" style="margin-top:16px"><table class="table"><thead><tr><th>Month</th><th>Amount</th><th>Notes</th><th>Recorded</th></tr></thead><tbody>
<?php if(!$monthlyRecords):?><tr><td colspan="4">No monthly petty cash records yet.</td></tr><?php else: foreach($monthlyRecords as $mr):?><tr><td><?=e($mr['month_start'])?></td><td><?=money((float)$mr['amount'])?></td><td><?=e($mr['notes']??'')?></td><td><?=e($mr['updated_at']??$mr['created_at']??'')?></td></tr><?php endforeach; endif;?></tbody></table></div>
</div>
<?php endif; ?>

<div class="card" style="margin-top:16px">
<h3>Monthly debt management</h3>
<p class="hint">A negative monthly petty-cash balance is a debt. If carried forward, the next month starts with that debt. A positive next-month balance can be used to settle the previous debt.</p>
<form method="post"><?=csrf_field()?><input type="hidden" name="op" value="save_month">
<div class="formgrid">
<div class="field"><label>Month</label><input type="month" id="monthPicker" name="month_start" value="<?=e(substr($selectedMonth,0,7))?>" required></div>
<div class="field"><label>Opening debt from previous month</label><input value="<?=e(number_format($openingDebt,2))?>" disabled></div>
<div class="field"><label>Selected month net balance</label><input value="<?=e(number_format($monthNet,2))?>" disabled></div>
<div class="field"><label>Debt to settle this month (KSh)</label><input type="number" step="0.01" min="0" max="<?=e(number_format(min($openingDebt,max(0,$monthNet)),2,'.',''))?>" name="debt_settled" value="<?=e(number_format($settled,2,'.',''))?>"></div>
<div class="field full"><label><input type="checkbox" name="carry_forward" value="1" <?=$defaultCarry||$carried>0?'checked':''?>> Carry any remaining previous debt and/or this month's deficit to the next month</label></div>
<div class="field full"><label>Monthly notes</label><input name="month_notes" value="<?=e($monthRow['notes']??'')?>" placeholder="Reason for carry-forward or settlement"></div>
</div>
<div class="form-actions"><button class="btn">Save monthly debt decision</button></div>
</form>
<div class="tablewrap" style="margin-top:16px"><table class="table"><thead><tr><th>Month</th><th>Opening Debt</th><th>Settled</th><th>Carried to Next Month</th><th>Notes</th></tr></thead><tbody>
<?php if(!$monthHistory):?><tr><td colspan="5">No monthly debt decisions recorded.</td></tr><?php else: foreach($monthHistory as $m):?><tr><td><?=e($m['month_start'])?></td><td><?=money(petty_opening_debt($pdo,$m['month_start']))?></td><td><?=money((float)$m['debt_settled'])?></td><td><?=money((float)$m['carried_forward_debt'])?></td><td><?=e($m['notes']??'')?></td></tr><?php endforeach; endif;?>
</tbody></table></div>
</div>

<div class="card" style="margin-top:16px">
<h3>Search petty cash report</h3>
<form method="get" class="searchbar">
<input type="date" name="from" value="<?=e($from)?>" title="From date">
<input type="date" name="to" value="<?=e($to)?>" title="To date">
<input name="q" value="<?=e($search)?>" placeholder="Search category, reference, description or record number">
<button class="btn" type="submit">Search</button>
<a class="btn secondary" href="petty_cash.php">Clear</a>
<button class="btn secondary" type="button" onclick="window.print()">Print report</button>
</form>
<div class="tablewrap"><table class="table" id="pettyData"><thead><tr><th>Record No.</th><th>Date</th><th>Type</th><th>Category</th><th>Amount</th><th>Paid to/from</th><th>Reference</th><th>Description</th><th>Actions</th></tr></thead><tbody>
<?php if(!$rows):?><tr><td colspan="9">No petty cash records match the selected report filter.</td></tr><?php else: foreach($rows as $r):?>
<tr><td>PC-<?=str_pad((string)$r['id'],6,'0',STR_PAD_LEFT)?></td><td><?=e($r['transaction_date'])?></td><td><?=e($r['transaction_type'])?></td><td><?=e($r['category'])?></td><td><?=money((float)$r['amount'])?></td><td><?=e($r['paid_to_from']??'')?></td><td><?=e($r['reference_no']??'')?></td><td><?=e($r['description'])?></td><td><a class="btn small" href="?action=edit&id=<?=$r['id']?>">Edit</a> <form class="inline-form" method="post"><?=csrf_field()?><input type="hidden" name="op" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn small danger" data-confirm="Delete this petty cash record?">Delete</button></form> <button class="btn small secondary" onclick="window.print()">Print</button></td></tr>
<?php endforeach; endif;?></tbody></table></div>
</div>
<?php require __DIR__.'/partials/footer.php'; ?>