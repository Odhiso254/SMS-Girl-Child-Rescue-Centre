# SUGUTA · SMI Girl Child Rescue Centre — Secure XAMPP Edition — V8 Repaired

A single integrated PHP/MySQL system for:

- Rescue / rescued people
- Rescue incidents and emergency types
- Traditions / communities
- Donors and donor support
- School admissions and school fees
- Hospitals, visits and treatments
- Farm records
- Central financial transactions
- Reports and audit logs
- Administrator 2FA with recovery codes
- Password change and login rate limiting

## XAMPP installation

1. Install XAMPP with Apache, MySQL and PHP.
2. Extract the `final_rfs` folder into:
   `C:\xampp\htdocs\`
3. Start **Apache** and **MySQL** from the XAMPP Control Panel.
4. Open phpMyAdmin:
   `http://localhost/phpmyadmin/`
5. Create/import the database by importing:
   `database/farm.sql`
   The script creates and uses the database **farm**.
6. Confirm `config/config.php` contains:
   - DB host: `127.0.0.1`
   - DB name: `farm`
   - DB user: `root`
   - DB password: blank for a default XAMPP install
7. Open:
   `http://localhost/final_rfs/`
8. Login:
   - Username: `admin`
   - Password: `admin123`
   - Role: `Super Admin`
9. Immediately go to **Change Password** and set a strong password.
10. Then, for the administrator, open **2FA Security** and enable an authenticator app.

## Role-based access

- **Super Admin:** all modules + Settings, Audit Logs and 2FA.
- **Staff:** operational modules and reports, but no Settings, Audit Logs or 2FA administration.
- **Farmer:** only Farm Dashboard and Farm Records.
- **Doctor:** only Health Dashboard, Hospitals, Hospital Visits and Treatments.
- **Student:** only School Dashboard, School Admissions and School Fees.
- **Donor:** only Donor Dashboard, My Donor Profile and My Support.

Both the navigation and server-side route protection enforce these boundaries. A user
cannot bypass the navigation by typing another module's URL directly.

## Default credentials
- Super Admin: `admin` / `admin1234`
- Standard User: `user` / `user1234` (Staff role)
- New users: select **Other User** on login and complete registration; accounts remain pending until approved by Super Admin.

## Security included

- PDO prepared statements
- CSRF protection on POST forms
- Session ID regeneration after authentication
- HttpOnly + SameSite session cookies
- Optional Secure cookies when HTTPS is enabled
- Content Security Policy and browser security headers
- Output escaping against XSS
- Role-based access control, including direct-URL checks
- Login failure rate limiting
- Audit logging
- Password hashing with PHP `password_hash`
- TOTP 2FA without Composer
- One-time hashed backup codes
- Directory listing disabled
- Sensitive file types blocked by `.htaccess`

## Important XAMPP security note

For a local computer, the default XAMPP MySQL root account may have a blank password.
For any network/public deployment, create a dedicated MySQL user with a strong password,
then update `config/config.php`. Do not expose phpMyAdmin or the application directly to
the public internet without HTTPS, firewall rules and a properly secured MySQL account.

## Windows backup

Use `server_config\backup_farm.bat` from a Command Prompt after configuring the MySQL
client path if required. Backups should be stored outside the web root.

## Main URL

http://localhost/final_rfs/

## Developer

Evlyne Owino


## Security/data-integrity hardening in v2.3.0
- Added TOTP columns required by the 2FA module and rate-limited 2FA verification.
- Logout is POST + CSRF protected.
- Student records are linked directly to the student user account; students cannot read other students' records by changing IDs.
- Farm records are linked to the owning farmer account; farmers only see their own farm records.
- Removed unused duplicate legacy domain tables from the fresh-install schema to avoid conflicting sources of truth.
- Financial transactions remain a central ledger and are uniquely linked to source transactions to prevent duplicate ledger entries.


## Admin Navigation Update
- Added a dedicated responsive Admin Panel navigation tab bar.
- Tabs are shown only to the `admin` role.
- Active page is highlighted automatically.
- Navigation is horizontally scrollable on smaller screens.
- Existing server-side RBAC remains in force; the tabs do not replace access controls.


## Default login accounts
- **Super Admin:** `admin` / `admin1234` — select **Super Admin**.
- **Other roles:** `user` / `user1234` — select the assigned role (Staff, Farmer, Doctor, Student, or Donor).

## UI / navigation improvements
- One authoritative role-based sidebar is used throughout the application; duplicate administrator and quick-navigation tab bars have been removed.
- Navigation buttons use a consistent 3D rectangular design, with responsive mobile drawer behavior.
- Shared header, cards, forms, tables, alerts and login/splash screens have been visually refreshed for consistency and accessibility.
- All PHP files were syntax-checked with PHP CLI after the changes.

## SMI Girl Child Rescue Centre — Updated configuration

- System title: **SUGUTA · SMI Girl Child Rescue Centre**
- Developer: **Evlyne Owino**
- Database: **MySQL / database `farm`**
- The **Hospitals** navigation tab has been removed; Hospital Visits remains available.
- The old Farm Records **Record type** field/database column has been removed.
- Record lists provide Print and, for Super Admin, Edit/Update/Delete controls. Direct record management is protected by server-side RBAC.
- Petty Cash is available only to **Admin and Director**. Manager has no Petty Cash access.
- Public accounts can register as Staff, Farmer, Doctor, Student or Donor. They are inactive and unverified until a Super Admin approves them in **User Manager**.
- Registration includes an **I’m not a robot** checkbox and a hidden honeypot field.
- Login pages do not display default usernames or passwords.

### Initial privileged accounts

| Role | Username | Password |
|---|---|---|
| Super Admin | `admin` | `admin123` |
| Manager | `sr_Teresa` | `sr_Teresa` |
| Director | `direct` | `direct1234` |
| Coordinator | `mastermind` | `mastermind` |

Change privileged passwords after installation.

### Backup and recovery

1. Use **Backups** in the system to download a complete `.sql` backup to the computer disk.
2. Admin or Director can use **Restore Database** to restore an SQL backup after a failure.
3. On Windows/XAMPP, `server_config/backup_farm.bat` can create a local MySQL dump in a backup folder.
4. Keep at least one backup on a separate USB drive or other storage, not only on the same computer.


### Manager registration and approval

- **Manager** is now available on the public **Create Account** form.
- A Manager who creates an account is initially **Pending** (`is_active=0`, `is_verified=0`).
- The Manager cannot log in or operate the system until a **Super Admin** approves the account from **User Manager**.
- Super Admin approval changes the account to active and verified.
- Existing seeded Manager accounts remain subject to the same server-side approval status rules.

## Profile photos
New users may upload an optional JPG, PNG or WebP profile photo up to 3 MB during signup. Uploaded files are stored outside executable PHP paths and protected by Apache rules.

### Existing installation upgrade
If you already imported an earlier version of the database, import `database/upgrade_v4.sql` once before using the new profile-photo and account-management features.


## SUGUTA v6 role and messaging controls
- Director account: **direct / direct1234**, display name **Sister Suguta**.
- Director has the same management navigation and shared-record controls as Admin, with the primary Admin account remaining protected.
- Petty Cash: **Admin and Director only**. Coordinator and Staff cannot access it by navigation or direct URL.
- Donor information: **Admin, Director and the individual donor account only**. Staff, Coordinator and Manager cannot open donor pages or donor-support details.
- Other roles receive only the workspace modules assigned to their role and cannot browse the user-account directory.
- Rescue Incidents are included in Reports.
- System branding uses **SUGUTA · SMI Girl Child Rescue Centre**.
- Automated Director SMS + WhatsApp notifications are prepared through `cron/director_notifications.php`; configure Twilio credentials in `config/config.php` and schedule morning/evening runs. Messages are logged to prevent duplicate sends.


## SUGUTA v7 changes
- Petty Cash is restricted to Admin and Director and now has automatic record numbers, date/date-range search, printing, and monthly debt carry-forward.
- A carried petty-cash debt can be partially or fully settled from the following month's positive balance; remaining debt can continue forward.
- Admin and Director dashboards consolidate financial activity by subsystem and provide a general financial total. Farm records can be classified as Sale or Expense so their amounts feed the central ledger.
- Manager account registration is pending by default; only the Super Admin receives the new Manager approval notification and can approve/reject that Manager registration. Directors cannot approve Manager registrations.
- Every database record continues to use an automatic primary key; user-facing record numbers are generated from those IDs.
- New installations have a 30-day local trial. After expiry, protected modules stop and only the administrator dashboard/unlock screen remains available. The administrator can permanently unlock before or after expiry; the unlock credential is stored only as a one-way digest and is never displayed in the application.
- For an existing database, import `database/upgrade_v7.sql` once before using the new v7 features.


## V8 repair checks
- Removed the duplicate `system_settings` entry from the clean-install DROP TABLE statement that caused MySQL error #1066.
- Removed accidental text corruption from the shared page header.
- Converted several delete actions from GET links to CSRF-protected POST forms.
- PHP syntax check completed with no parse errors.
- ZIP integrity check completed successfully.
- The application license remains permanently unlockable by the administrator before or after the 30-day period.


## v8.1 Petty Cash & Automatic Backup Upgrade
- Admin can record one monthly petty-cash amount and notes per month from Petty Cash.
- Existing daily/transaction petty-cash operations are unchanged.
- Automatic SQL backups are stored in `storage/backups`, with up to 14 recent automatic copies retained.
- `cron/auto_backup.php` can be scheduled with Windows Task Scheduler or Linux cron.
- System expiry remains `2026-10-18 13:22:19`.
