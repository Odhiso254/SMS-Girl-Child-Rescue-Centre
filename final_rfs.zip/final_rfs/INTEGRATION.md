# Database Unification

This build removes the separate `busia_portal_mysql` application and unifies its database model with the rescue/farming system.

The shared database is `farm`. Existing PHP modules continue to use their rescue/farming tables, while the SMI Girl Child Rescue Centre tables for role-based users, farming, health, academic management, donors, notifications and settings are in the same schema.

The `users`, `donors` and `audit_logs` tables were reconciled so both systems can use them without duplicate table names.
