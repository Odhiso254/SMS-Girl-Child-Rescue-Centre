<?php
require __DIR__.'/config/config.php';
if (!logged_in()) { redirect('splash.php'); }
require_login();
$title='System Unlock';
$page='system_unlock';
$license=license_status($pdo);
$unlockError='';
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op']??'')==='unlock_system') {
    verify_csrf();
    if (unlock_system($pdo, (string)($_POST['unlock_code']??''))) {
        flash('success','System permanently unlocked.');
        redirect('unlock.php?unlocked=1');
    }
    $unlockError='Invalid unlock credential.';
    $license=license_status($pdo);
}
?>
<?php require __DIR__.'/partials/header.php'; ?>
<div class="page-head">
  <div><span class="eyebrow">ADMINISTRATION</span><h1>System Unlock</h1><p class="hint">Manage the installation access period.</p></div>
</div>
<div class="card" style="max-width:720px;margin-top:16px">
  <h2>Permanent system access</h2>
  <?php if ($license['permanent']): ?>
    <div class="flash success">The system is permanently unlocked and will not lock after the installation period.</div>
    <p class="hint">No further action is required.</p>
  <?php else: ?>
    <?php if ($license['locked']): ?>
      <div class="flash error">The installation period has ended. Enter the administrator unlock credential to restore access permanently.</div>
    <?php else: ?>
      <p>The system is currently active. The administrator may permanently unlock it before the 30-day installation period ends.</p>
      <p class="hint">Installation started: <?=e($license['install_at']??'')?> · Access until: <?=e($license['expires_at']??'')?></p>
    <?php endif; ?>
    <?php if ($unlockError): ?><div class="flash error"><?=e($unlockError)?></div><?php endif; ?>
    <form method="post" class="searchbar" style="margin-top:16px">
      <?=csrf_field()?>
      <input type="hidden" name="op" value="unlock_system">
      <input type="password" name="unlock_code" placeholder="Enter unlock code" autocomplete="off" required aria-label="Unlock code">
      <button class="btn" type="submit">Unlock Permanently</button>
    </form>
  <?php endif; ?>
</div>
<?php require __DIR__.'/partials/footer.php'; ?>
