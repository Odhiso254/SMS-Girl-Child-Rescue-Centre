<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='Donors'; $page='donors'; $action=$_GET['action']??'list';
if(!in_array(role(),['admin','director','donor'],true)){http_response_code(403);exit('403 Forbidden — donor information is restricted to Admin, Director and the donor account owner.');}
if(role()==='donor' && $_SERVER['REQUEST_METHOD']==='POST'){
 flash('error','Donor accounts can view their own donor profile but cannot administer donor records.');
 redirect('donors.php');
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!can_manage_records()){ flash('error','Only Admin or Director can create or modify donor records.'); redirect('donors.php'); }
 $data["name"]=trim((string)($_POST["name"]??""));$data["organization"]=trim((string)($_POST["organization"]??""));$data["phone"]=trim((string)($_POST["phone"]??""));$data["email"]=trim((string)($_POST["email"]??""));$data["visit_frequency"]=trim((string)($_POST["visit_frequency"]??""));$data["last_visit"]=trim((string)($_POST["last_visit"]??""));$data["notes"]=trim((string)($_POST["notes"]??""));
 $s=$pdo->prepare("INSERT INTO donors (name,organization,phone,email,visit_frequency,last_visit,notes) VALUES (?,?,?,?,?,?,?)");
 $s->execute([$data["name"],$data["organization"],$data["phone"],$data["email"],$data["visit_frequency"],$data["last_visit"],$data["notes"]]);
 audit($pdo,'Created Donors','donors',(int)$pdo->lastInsertId());
 flash('success','Record created successfully.'); redirect('donors.php');
}
$rows = role()==='donor' ? (function() use ($pdo){$q=$pdo->prepare('SELECT * FROM donors WHERE user_id=? ORDER BY id DESC');$q->execute([user()['id']]);return $q->fetchAll();})() : $pdo->query('SELECT * FROM donors ORDER BY id DESC')->fetchAll();
require __DIR__.'/partials/header.php';
?>
<div class="hero"><div><h1>Donors</h1><p>Maintain donor profiles, relationships and visit information securely.</p></div><?php if(can_manage_records()): ?><a class="btn" href="?action=add">+ Add donor</a><?php endif; ?></div>
<?php if($action==='add'):?>
<div class="card"><h3>Add record</h3><form method="post"><?=csrf_field()?><div class="formgrid"><div class="field"><label>Donor name</label><input type="text" name="name" required></div><div class="field"><label>Organization</label><input type="text" name="organization" ></div><div class="field"><label>Phone</label><input type="text" name="phone" ></div><div class="field"><label>Email</label><input type="email" name="email" ></div><div class="field"><label>Visit frequency</label><input type="text" name="visit_frequency" ></div><div class="field"><label>Last visit</label><input type="date" name="last_visit" ></div><div class="field full"><label>Notes</label><textarea name="notes"></textarea></div></div><div class="form-actions"><button class="btn">Save record</button><a class="btn secondary" href="donors.php">Cancel</a></div></form></div>
<?php else:?>
<div class="card"><div class="searchbar"><input id="search" placeholder="Search this table..."></div><div class="tablewrap"><table class="table" id="data"><thead><tr><th>Name</th><th>Organization</th><th>Phone</th><th>Last Visit</th><th>Actions</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e((string)$r["name"])?></td><td><?=e((string)$r["organization"])?></td><td><?=e((string)$r["phone"])?></td><td><?=e((string)$r["last_visit"])?></td><td><?php if(can_manage_records()):?><a class="btn small" href="record_manager.php?entity=donors&amp;id=<?=$r['id']?>">Edit / Update</a><form class="inline-form" method="post" action="record_manager.php?entity=donors&amp;id=<?=$r['id']?>"><?=csrf_field()?><input type="hidden" name="op" value="delete"><button class="btn small danger" type="submit" data-confirm="Delete this donor record? Linked support records may prevent deletion.">Delete</button></form><?php endif;?></td></tr><?php endforeach;?></tbody></table></div></div>
<script>document.getElementById('search').addEventListener('input',e=>{let q=e.target.value.toLowerCase();document.querySelectorAll('#data tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')})</script>
<?php endif; require __DIR__.'/partials/footer.php'; ?>