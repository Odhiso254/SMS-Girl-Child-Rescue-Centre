<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='Farm Records'; $page='farm'; $action=$_GET['action']??'list'; $id=(int)($_GET['id']??0);
if($_SERVER['REQUEST_METHOD']==='POST'){
 $op=(string)($_POST['op']??'save');
 if($op==='delete'){
  if(!can_manage_records()){http_response_code(403);exit('403 Forbidden');}
  $fid=(int)$_POST['id'];
  $pdo->beginTransaction();
  $pdo->prepare('DELETE FROM financial_transactions WHERE farm_record_id=?')->execute([$fid]);
  $pdo->prepare('DELETE FROM farm_records WHERE id=?')->execute([$fid]);
  $pdo->commit();
  audit($pdo,'Deleted Farm Record','farm_records',$fid);flash('success','Farm record deleted.');redirect('farm.php');
 }
 $data=["category"=>trim((string)($_POST["category"]??"")),"item"=>trim((string)($_POST["item"]??"")),"quantity"=>(float)($_POST["quantity"]??0),"unit"=>trim((string)($_POST["unit"]??"")),"amount"=>(float)($_POST["amount"]??0),"financial_type"=>in_array($_POST["financial_type"]??'None',['None','Sale','Expense'],true)?(string)$_POST["financial_type"]:'None',"record_date"=>trim((string)($_POST["record_date"]??"")),"buyer_or_supplier"=>trim((string)($_POST["buyer_or_supplier"]??"")),"notes"=>trim((string)($_POST["notes"]??""))];
 if(!$data["item"]||!$data["record_date"]||$data["quantity"]<0||$data["amount"]<0){flash('error','Please provide valid farm record details.');redirect('farm.php?action=add');}
 if($op==='update'){
  if(!can_manage_records()){http_response_code(403);exit('403 Forbidden');}
  $fid=(int)$_POST['id'];
  $pdo->beginTransaction();
  $s=$pdo->prepare('UPDATE farm_records SET category=?,item=?,quantity=?,unit=?,amount=?,financial_type=?,record_date=?,buyer_or_supplier=?,notes=? WHERE id=?');
  $s->execute([$data["category"],$data["item"],$data["quantity"],$data["unit"],$data["amount"],$data["financial_type"],$data["record_date"],$data["buyer_or_supplier"],$data["notes"],$fid]);
  $pdo->prepare('DELETE FROM financial_transactions WHERE farm_record_id=?')->execute([$fid]);
  if($data["amount"]>0 && $data["financial_type"]!=='None'){
      $ft=$pdo->prepare("INSERT INTO financial_transactions(transaction_type,category,amount,transaction_date,farm_record_id,description,created_by) VALUES(?,?,?,?,?,?,?)");
      $ft->execute([$data["financial_type"]==='Sale'?'Income':'Expense',$data["financial_type"]==='Sale'?'Farm Sales':'Farm Expense',$data["amount"],$data["record_date"],$fid,'Farm '.$data["financial_type"].': '.$data["item"],user()['id']]);
  }
  $pdo->commit();
  audit($pdo,'Updated Farm Record','farm_records',$fid);flash('success','Farm record updated.');redirect('farm.php');
 }
 $pdo->beginTransaction();
 $s=$pdo->prepare("INSERT INTO farm_records (farmer_user_id,category,item,quantity,unit,amount,financial_type,record_date,buyer_or_supplier,notes) VALUES (?,?,?,?,?,?,?,?,?,?)");
 $s->execute([user()['id'],$data["category"],$data["item"],$data["quantity"],$data["unit"],$data["amount"],$data["financial_type"],$data["record_date"],$data["buyer_or_supplier"],$data["notes"]]);
 $newId=(int)$pdo->lastInsertId();
 if($data["amount"]>0 && $data["financial_type"]!=='None'){
     $ft=$pdo->prepare("INSERT INTO financial_transactions(transaction_type,category,amount,transaction_date,farm_record_id,description,created_by) VALUES(?,?,?,?,?,?,?)");
     $ft->execute([$data["financial_type"]==='Sale'?'Income':'Expense',$data["financial_type"]==='Sale'?'Farm Sales':'Farm Expense',$data["amount"],$data["record_date"],$newId,'Farm '.$data["financial_type"].': '.$data["item"],user()['id']]);
 }
 $pdo->commit();
 audit($pdo,'Created Farm Record','farm_records',$newId);flash('success','Farm record saved. Automatic record number: FR-'.str_pad((string)$newId,6,'0',STR_PAD_LEFT).'.');redirect('farm.php');
}
$edit=null;if($action==='edit'&&$id){$q=$pdo->prepare('SELECT * FROM farm_records WHERE id=?');$q->execute([$id]);$edit=$q->fetch();}
$rows=role()==='farmer' ? (function() use ($pdo){$q=$pdo->prepare("SELECT * FROM farm_records WHERE farmer_user_id=? ORDER BY id DESC");$q->execute([user()['id']]);return $q->fetchAll();})() : $pdo->query("SELECT * FROM farm_records ORDER BY id DESC")->fetchAll();
require __DIR__.'/partials/header.php';?>
<div class="hero"><div><h1>Farm Records</h1><p>Record crops, poultry, dairy, quantities, costs, buyers/suppliers and farming notes. The old “Record type” field has been removed.</p></div><div class="hero-actions"><a class="btn" href="?action=add">+ Add record</a><button class="btn secondary" onclick="window.print()">Print information</button></div></div>
<?php if($action==='add'||$edit):?><div class="card"><h3><?=$edit?'Edit / Update record':'Add record'?></h3><form method="post"><?=csrf_field()?><input type="hidden" name="op" value="<?=$edit?'update':'save'?>"><input type="hidden" name="id" value="<?=$edit?(int)$edit['id']:0?>"><div class="formgrid"><div class="field"><label>Category</label><select name="category"><option>Poultry</option><option>Dairy</option><option>Crop</option></select></div><div class="field"><label>Item / produce</label><input name="item" required value="<?=e($edit['item']??'')?>"></div><div class="field"><label>Quantity</label><input type="number" step="0.01" min="0" name="quantity" value="<?=e((string)($edit['quantity']??''))?>"></div><div class="field"><label>Unit</label><input name="unit" value="<?=e($edit['unit']??'')?>"></div><div class="field"><label>Amount (KSh)</label><input type="number" step="0.01" min="0" name="amount" value="<?=e((string)($edit['amount']??''))?>"></div><div class="field"><label>Financial classification</label><select name="financial_type"><option value="None" <?=(!$edit||($edit['financial_type']??'None')==='None')?'selected':''?>>None</option><option value="Sale" <?=$edit&&($edit['financial_type']??'')==='Sale'?'selected':''?>>Sale (income)</option><option value="Expense" <?=$edit&&($edit['financial_type']??'')==='Expense'?'selected':''?>>Expense</option></select></div><div class="field"><label>Date</label><input type="date" name="record_date" required value="<?=e($edit['record_date']??date('Y-m-d'))?>"></div><div class="field"><label>Buyer / Supplier</label><input name="buyer_or_supplier" value="<?=e($edit['buyer_or_supplier']??'')?>"></div><div class="field full"><label>Notes</label><textarea name="notes"><?=e($edit['notes']??'')?></textarea></div></div><div class="form-actions"><button class="btn"><?=$edit?'Update':'Save record'?></button><a class="btn secondary" href="farm.php">Cancel</a></div></form></div>
<?php else:?><div class="card"><div class="searchbar"><input id="search" placeholder="Search this table..."><button class="btn secondary" onclick="window.print()">Print</button></div><div class="tablewrap"><table class="table" id="data"><thead><tr><th>Record No.</th><th>Date</th><th>Category</th><th>Item</th><th>Qty</th><th>Unit</th><th>Amount</th><th>Financial</th><th>Actions</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td>FR-<?=str_pad((string)$r['id'],6,'0',STR_PAD_LEFT)?></td><td><?=e($r["record_date"])?></td><td><?=e($r["category"])?></td><td><?=e($r["item"])?></td><td><?=e((string)$r["quantity"])?></td><td><?=e($r["unit"]??'')?></td><td><?=money((float)$r["amount"])?></td><td><?=e($r["financial_type"]??'None')?></td><td><?php if(can_manage_records()):?><a class="btn small" href="?action=edit&id=<?=$r['id']?>">Edit / Update</a><form class="inline-form" method="post"><?=csrf_field()?><input type="hidden" name="op" value="delete"><input type="hidden" name="id" value="<?=$r['id']?>"><button class="btn small danger" data-confirm="Delete this farm record?">Delete</button></form><?php endif;?><button class="btn small secondary" onclick="window.print()">Print</button></td></tr><?php endforeach;?></tbody></table></div></div>
<script>document.getElementById('search').addEventListener('input',e=>{let q=e.target.value.toLowerCase();document.querySelectorAll('#data tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')})</script><?php endif;require __DIR__.'/partials/footer.php';?>