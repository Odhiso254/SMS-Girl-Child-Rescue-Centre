<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='Change Password'; $page='change_password'; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $current=(string)($_POST['current_password']??'');
    $new=(string)($_POST['new_password']??'');
    $confirm=(string)($_POST['confirm_password']??'');
    $s=$pdo->prepare("SELECT password_hash FROM users WHERE id=?");$s->execute([user()['id']]);$u=$s->fetch();
    if(!$u || !password_verify($current,$u['password_hash'])) $error='Current password is incorrect.';
    elseif(strlen($new)<10 || !preg_match('/[A-Z]/',$new) || !preg_match('/[a-z]/',$new) || !preg_match('/\d/',$new)) $error='Use at least 10 characters with uppercase, lowercase and a number.';
    elseif($new!==$confirm) $error='New passwords do not match.';
    else{
        $p=$pdo->prepare("UPDATE users SET password_hash=? WHERE id=?");$p->execute([password_hash($new,PASSWORD_DEFAULT),user()['id']]);
        audit($pdo,'PASSWORD_CHANGED','users',(int)user()['id']);flash('success','Password changed successfully.');redirect('change_password.php');
    }
}
require __DIR__.'/partials/header.php';
?>
<div class="hero"><div><h1>Change Password</h1><p>Use a strong unique password for your account.</p></div></div>
<div class="card" style="max-width:620px"><?php if($error):?><div class="flash error"><?=e($error)?></div><?php endif;?>
<form method="post"><?=csrf_field()?>
<div class="field"><label>Current password</label><input type="password" name="current_password" required></div>
<div class="field" style="margin-top:14px"><label>New password</label><input type="password" name="new_password" minlength="10" required></div>
<div class="field" style="margin-top:14px"><label>Confirm new password</label><input type="password" name="confirm_password" minlength="10" required></div>
<button class="btn" style="margin-top:16px">Change Password</button>
</form></div>
<?php require __DIR__.'/partials/footer.php'; ?>
