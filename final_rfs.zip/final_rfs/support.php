<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='Donor Support'; $page='support';
if(!in_array(role(),['admin','director','donor'],true)){http_response_code(403);exit('403 Forbidden — donor support information is restricted to Admin, Director and the donor account owner.');} $action=$_GET['action']??'list';
if(role()==='donor'){
 $q=$pdo->prepare("SELECT id,name,organization FROM donors WHERE user_id=?");$q->execute([user()['id']]);$donors=$q->fetchAll();
} else $donors=$pdo->query("SELECT id,name,organization FROM donors ORDER BY name")->fetchAll();
$students=$pdo->query("SELECT id,full_name FROM rescued_students WHERE status <> 'Inactive' ORDER BY full_name")->fetchAll();
if(role()==='donor' && $_SERVER['REQUEST_METHOD']==='POST'){
 flash('error','Donor accounts are view-only for support records. Contact staff to record a new support transaction.');
 redirect('support.php');
}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $donor=(int)($_POST['donor_id']??0); $student=(int)($_POST['student_id']??0) ?: null;
 $cat=(string)($_POST['support_category']??''); $amount=(float)($_POST['amount']??0); $date=(string)($_POST['support_date']??'');
 $desc=trim((string)($_POST['description']??'')); $ref=trim((string)($_POST['reference_no']??'')) ?: null;
 if(!$donor || $amount<=0 || !$date || !$desc) { flash('error','Donor, amount, date and description are required.'); redirect('support.php?action=add'); }
 $pdo->beginTransaction();
 try {
  $s=$pdo->prepare("INSERT INTO donor_supports(donor_id,student_id,support_category,amount,support_date,description,reference_no,created_by) VALUES(?,?,?,?,?,?,?,?)");
  $s->execute([$donor,$student,$cat,$amount,$date,$desc,$ref,user()['id']]); $sid=(int)$pdo->lastInsertId();
  $t=$pdo->prepare("INSERT INTO financial_transactions(transaction_type,category,amount,transaction_date,donor_id,student_id,support_id,description,reference_no,created_by) VALUES('Income',?,?,?,?,?,?,?,?)");
  $t->execute([$cat,$amount,$date,$donor,$student,$sid,$desc,$ref,user()['id']]);
  audit($pdo,'Created Donor Support','donor_supports',$sid); $pdo->commit(); flash('success','Donor support and financial income recorded together.'); redirect('support.php');
 } catch(Throwable $e){$pdo->rollBack(); flash('error','Could not save the support record.'); redirect('support.php?action=add');}
}
if(role()==='donor'){
 $q=$pdo->prepare("SELECT ds.*,d.name donor_name,s.full_name student_name FROM donor_supports ds JOIN donors d ON d.id=ds.donor_id LEFT JOIN rescued_students s ON s.id=ds.student_id WHERE d.user_id=? ORDER BY ds.id DESC");
 $q->execute([user()['id']]);$rows=$q->fetchAll();
} else $rows=$pdo->query("SELECT ds.*,d.name donor_name,s.full_name student_name FROM donor_supports ds JOIN donors d ON d.id=ds.donor_id LEFT JOIN rescued_students s ON s.id=ds.student_id ORDER BY ds.id DESC")->fetchAll();
require __DIR__.'/partials/header.php';
?>
<div class="hero"><div><h1>Donor Support</h1><p>Donor assistance is linked to beneficiaries and the central financial ledger.</p></div><a class="btn" href="?action=add">+ Record support</a></div>
<?php if($action==='add'): ?><div class="card"><h3>Record donor support</h3><form method="post"><?=csrf_field()?><div class="formgrid">
<div class="field"><label>Donor</label><select name="donor_id" required><option value="">Select donor</option><?php foreach($donors as $d):?><option value="<?=$d['id']?>"><?=e($d['name'])?><?= $d['organization']?' — '.e($d['organization']):''?></option><?php endforeach;?></select></div>
<div class="field"><label>Beneficiary student (optional)</label><select name="student_id"><option value="">Centre / general support</option><?php foreach($students as $s):?><option value="<?=$s['id']?>"><?=e($s['full_name'])?></option><?php endforeach;?></select></div>
<div class="field"><label>Category</label><select name="support_category"><option>Centre Support</option><option>Food Support</option><option>Other Income</option></select></div>
<div class="field"><label>Amount (KSh)</label><input type="number" name="amount" step="0.01" min="0.01" required></div>
<div class="field"><label>Date</label><input type="date" name="support_date" value="<?=date('Y-m-d')?>" required></div>
<div class="field"><label>Reference</label><input type="text" name="reference_no"></div>
<div class="field full"><label>Description</label><input type="text" name="description" required></div></div><div class="form-actions"><button class="btn">Save support</button><a class="btn secondary" href="support.php">Cancel</a></div></form></div>
<?php else: ?><div class="card"><div class="tablewrap"><table class="table"><tr><th>Date</th><th>Donor</th><th>Beneficiary</th><th>Category</th><th>Amount</th><th>Description</th><th>Actions</th></tr><?php foreach($rows as $r):?><tr><td><?=e($r['support_date'])?></td><td><?=e($r['donor_name'])?></td><td><?=e($r['student_name']??'Centre / General')?></td><td><?=e($r['support_category'])?></td><td><?=money((float)$r['amount'])?></td><td><?=e($r['description'])?></td><td><?php if(can_manage_records()):?><a class="btn small" href="record_manager.php?entity=support&id=<?=$r['id']?>">Edit / Update</a><form class="inline-form" method="post" action="record_manager.php?entity=support&amp;id=<?=$r['id']?>"><?=csrf_field()?><input type="hidden" name="op" value="delete"><button class="btn small danger" type="submit" data-confirm="Delete this support record?">Delete</button></form><?php endif;?> <button class="btn small secondary" onclick="window.print()">Print</button></td></tr><?php endforeach;?></table></div></div><?php endif; require __DIR__.'/partials/footer.php'; ?>
