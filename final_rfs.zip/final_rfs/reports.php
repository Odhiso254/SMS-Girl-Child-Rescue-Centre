<?php
require __DIR__.'/config/config.php';require_login();
$title='Reports';$page='reports';
$students=(int)$pdo->query("SELECT COUNT(*) FROM rescued_students")->fetchColumn();
$inSchool=(int)$pdo->query("SELECT COUNT(*) FROM rescued_students WHERE education_status<>'Not in School'")->fetchColumn();
$notSchool=(int)$pdo->query("SELECT COUNT(*) FROM rescued_students WHERE education_status='Not in School'")->fetchColumn();
$incidents=(int)$pdo->query("SELECT COUNT(*) FROM rescue_incidents")->fetchColumn();
$visits=(int)$pdo->query("SELECT COUNT(*) FROM hospital_visits")->fetchColumn();
$treatments=(int)$pdo->query("SELECT COUNT(*) FROM health_treatments")->fetchColumn();
$farm=(int)$pdo->query("SELECT COUNT(*) FROM farm_records")->fetchColumn();
$centralIncome=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM financial_transactions WHERE transaction_type='Income'")->fetchColumn();
$centralExpense=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM financial_transactions WHERE transaction_type='Expense'")->fetchColumn();
$pettyIncome=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM petty_cash WHERE transaction_type='Income'")->fetchColumn();
$pettyExpense=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM petty_cash WHERE transaction_type='Expense'")->fetchColumn();
$financial=$pdo->query("SELECT category,transaction_type,COALESCE(SUM(amount),0) total FROM financial_transactions GROUP BY category,transaction_type ORDER BY category,transaction_type")->fetchAll();
$recentIncidents=$pdo->query("SELECT ri.incident_date,ri.location,ri.severity,ri.description,s.full_name,et.name emergency_type FROM rescue_incidents ri JOIN rescued_students s ON s.id=ri.student_id JOIN emergency_types et ON et.id=ri.emergency_type_id ORDER BY ri.incident_date DESC,ri.id DESC LIMIT 12")->fetchAll();
require __DIR__.'/partials/header.php';?>
<div class="hero"><div><h1>Reports</h1><p>Operational and consolidated financial reporting across the connected subsystems.</p></div><button class="btn secondary" onclick="window.print()">Print report</button></div>
<div class="cards">
<div class="card metric"><div class="label">Rescued People</div><div class="value"><?=$students?></div></div>
<div class="card metric"><div class="label">In School</div><div class="value"><?=$inSchool?></div></div>
<div class="card metric"><div class="label">Not in School</div><div class="value"><?=$notSchool?></div></div>
<div class="card metric"><div class="label">Emergency Incidents</div><div class="value"><?=$incidents?></div></div>
<div class="card metric"><div class="label">Hospital Visits</div><div class="value"><?=$visits?></div></div>
<div class="card metric"><div class="label">Treatments</div><div class="value"><?=$treatments?></div></div>
<div class="card metric"><div class="label">Farm Records</div><div class="value"><?=$farm?></div></div>
</div>
<div class="cards" style="margin-top:16px">
<div class="card metric"><div class="label">GENERAL INCOME</div><div class="value"><?=money($centralIncome+$pettyIncome)?></div><div class="hint">Central ledger + petty cash</div></div>
<div class="card metric"><div class="label">GENERAL EXPENSES</div><div class="value"><?=money($centralExpense+$pettyExpense)?></div><div class="hint">Central ledger + petty cash</div></div>
<div class="card metric"><div class="label">PETTY CASH BALANCE</div><div class="value"><?=money($pettyIncome-$pettyExpense)?></div></div>
</div>
<div class="card" style="margin-top:16px"><div class="section-head"><div><h3>Financial report by subsystem</h3><p class="hint">Central financial transactions plus petty cash activity.</p></div></div>
<div class="tablewrap"><table class="table"><thead><tr><th>Subsystem / Category</th><th>Income</th><th>Expense</th><th>Net</th></tr></thead><tbody>
<?php $cats=[];foreach($financial as $f){$cats[$f['category']][$f['transaction_type']]=(float)$f['total'];}
foreach($cats as $name=>$f):$inc=$f['Income']??0;$exp=$f['Expense']??0;?>
<tr><td><?=e($name)?></td><td><?=money($inc)?></td><td><?=money($exp)?></td><td><?=money($inc-$exp)?></td></tr>
<?php endforeach;?>
<tr><td><strong>Petty Cash</strong></td><td><strong><?=money($pettyIncome)?></strong></td><td><strong><?=money($pettyExpense)?></strong></td><td><strong><?=money($pettyIncome-$pettyExpense)?></strong></td></tr>
<tr><td><strong>GENERAL TOTAL</strong></td><td><strong><?=money($centralIncome+$pettyIncome)?></strong></td><td><strong><?=money($centralExpense+$pettyExpense)?></strong></td><td><strong><?=money(($centralIncome+$pettyIncome)-($centralExpense+$pettyExpense))?></strong></td></tr>
</tbody></table></div></div>
<div class="card" style="margin-top:16px"><div class="section-head"><div><h3>Recent Rescue Incidents</h3></div></div>
<div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Person</th><th>Emergency</th><th>Severity</th><th>Location</th><th>Description</th></tr></thead><tbody>
<?php foreach($recentIncidents as $ri):?><tr><td><?=e($ri['incident_date'])?></td><td><?=e($ri['full_name'])?></td><td><?=e($ri['emergency_type'])?></td><td><?=e($ri['severity'])?></td><td><?=e($ri['location']??'')?></td><td><?=e($ri['description']??'')?></td></tr><?php endforeach;?>
<?php if(!$recentIncidents):?><tr><td colspan="6">No rescue incidents have been recorded.</td></tr><?php endif;?></tbody></table></div></div>
<?php require __DIR__.'/partials/footer.php';