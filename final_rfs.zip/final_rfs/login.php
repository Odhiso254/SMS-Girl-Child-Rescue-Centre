<?php
require __DIR__.'/config/config.php';
require __DIR__.'/config/rate_limit.php';
require __DIR__.'/config/totp.php';

if (logged_in()) redirect('index.php');
$error = '';
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $role = trim((string)($_POST['role'] ?? ''));

    if ($username === '' || $password === '' || $role === '') {
        $error = 'Please enter all login details.';
    } elseif (login_rate_limited($pdo, $username, $ip)) {
        $error = 'Too many failed attempts. Please wait 15 minutes before trying again.';
    } else {
        $s = $pdo->prepare("SELECT * FROM users WHERE username=? AND role=? LIMIT 1");
        $s->execute([$username, $role]);
        $u = $s->fetch();
        $ok = $u && password_verify($password, $u['password_hash']);

        record_login_attempt($pdo, $u['id'] ?? null, $username, $role, (bool)$ok && (int)($u['is_active']??0)===1 && (int)($u['is_verified']??0)===1, $ip);

        if ($ok) {
            if (($u['approval_status']??'approved')==='rejected') { $error='Your account was rejected by the administrator. Please contact the centre administrator.'; } elseif (!(int)$u['is_active'] || !(int)$u['is_verified']) { $error='Please wait — your account is pending administrator approval.'; record_login_attempt($pdo,(int)$u['id'],$username,$role,false,$ip); } else {
            session_regenerate_id(true);
            if (!empty($u['totp_enabled']) && !empty($u['totp_secret'])) {
                $_SESSION['2fa_pending_user_id'] = (int)$u['id'];
                $_SESSION['2fa_pending_username'] = $u['username'];
                $_SESSION['2fa_pending_role'] = $u['role'];
                $_SESSION['2fa_pending_full_name'] = $u['full_name'];
                redirect('2fa_verify.php');
            }
            $_SESSION['user'] = [
                'id'=>(int)$u['id'], 'username'=>$u['username'], 'full_name'=>$u['full_name'],
                'role'=>$u['role'], 'email'=>$u['email'], 'phone'=>$u['phone'], 'profile_photo'=>$u['profile_photo'] ?? null, 'is_active'=>(int)$u['is_active'], 'is_verified'=>(int)$u['is_verified']
            ];
            audit($pdo, 'LOGIN_SUCCESS', 'users', (int)$u['id'], 'Password authentication successful');
            redirect('index.php');
            }
        }
        if (!$ok) { $error = 'Invalid username, role or password.'; }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Secure Login • <?=e(APP_NAME)?></title><link rel="stylesheet" href="assets/style.css"></head>
<body class="loginpage">
<div class="loginbox">
<div class="brand"><div class="brandmark">B</div><div><b>SUGUTA · SMI GIRL CHILD RESCUE CENTRE</b><small>Secure Integrated Management</small></div></div>
<h1>Welcome back</h1><p>Rescue • Education • Health • Donors • Farming • Finance • Petty Cash</p><div class="login-welcome" role="note"><strong>Welcome to SUGUTA · SMI Girl Child Rescue Centre</strong><span>Sign in to continue to your role-based home page.</span></div>
<?php if($error):?><div class="flash error"><?=e($error)?></div><?php endif;?>
<form method="post" autocomplete="off"><?=csrf_field()?>
<div class="field"><label>Role</label><select name="role" required>
<option value="">Select role</option><option value="admin">Super Admin</option><option value="director">Director</option><option value="coordinator">Coordinator</option><option value="manager">Manager</option><option value="staff">Staff</option><option value="farmer">Farmer</option><option value="doctor">Doctor</option><option value="student">Student</option><option value="donor">Donor</option>
</select></div>
<div class="field"><label>Username</label><input name="username" autocomplete="username" maxlength="100" required></div>
<div class="field"><label>Password</label><input type="password" name="password" autocomplete="current-password" minlength="8" required></div>
<button class="btn" type="submit">Sign in securely</button>
</form>
<div class="account-choice"><strong>Need an account?</strong><span>Director, Coordinator, Manager, Staff, Farmer, Doctor, Student and Donor accounts must be registered and approved by the administrator before access is granted.</span><a class="btn secondary" href="signup.php">Create an account</a><a class="btn secondary" href="forgot_password.php">Forgot password?</a></div>
</div></body></html>
