<?php
require __DIR__.'/config/config.php';
if (logged_in()) redirect('index.php');
verify_csrf();
$error=''; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $username=trim((string)($_POST['username']??''));
    $idNumber=trim((string)($_POST['id_number']??''));
    if($username===''||$idNumber==='') $error='Enter both your username and ID number.';
    else {
        $s=$pdo->prepare("SELECT * FROM users WHERE username=? AND id_number=? AND role<>'admin' LIMIT 1");
        $s->execute([$username,$idNumber]); $u=$s->fetch();
        if(!$u) $error='The username and ID number do not match our records. Recovery request declined.';
        else {
            $p=$pdo->prepare("SELECT id FROM password_recovery_requests WHERE user_id=? AND status='pending' LIMIT 1");
            $p->execute([(int)$u['id']]);
            if($p->fetch()) $success='A recovery request is already waiting for administrator approval.';
            else {
                $p=$pdo->prepare('INSERT INTO password_recovery_requests(user_id,username,id_number,status) VALUES(?,?,?,\'pending\')');
                $p->execute([(int)$u['id'],$username,$idNumber]);
                notify($pdo,null,'Password recovery approval required',"{$u['full_name']} ({$username}) requested password recovery. Verify the ID number and approve or decline the request.",'admin','users.php');
                audit($pdo,'Password recovery requested','users',(int)$u['id'],'Recovery request sent for administrator approval');
                $success='Your recovery request has been sent to the administrator. Wait for approval before using a new password.';
            }
        }
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Account Recovery • <?=e(APP_NAME)?></title><link rel="stylesheet" href="assets/style.css"></head>
<body class="loginpage"><div class="loginbox"><div class="brand"><div class="brandmark">S</div><div><b>SUGUTA · SMI GIRL CHILD RESCUE CENTRE</b><small>Secure account recovery</small></div></div>
<h1>Forgot password?</h1><p>Admin accounts do not use this recovery process.</p>
<?php if($error):?><div class="flash error"><?=e($error)?></div><?php endif;?><?php if($success):?><div class="flash success"><?=e($success)?></div><?php endif;?>
<form method="post" autocomplete="off"><?=csrf_field()?><div class="field"><label>Username</label><input name="username" maxlength="100" required></div><div class="field"><label>ID number</label><input name="id_number" maxlength="50" required></div><button class="btn" type="submit">Request admin approval</button></form>
<div class="note"><a href="login.php">Back to login</a> · <a href="signup.php">Create account</a></div></div></body></html>
