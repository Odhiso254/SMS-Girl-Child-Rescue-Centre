# Security, Conflict and Data-Integrity Audit — v2.2.0

## Findings fixed
1. **2FA schema conflict:** the PHP 2FA code referenced `users.totp_secret` and `users.totp_enabled`, but the previous schema did not define them. v2.2.0 adds both columns.
2. **Student authorization leak:** the old `students` table was not linked to `rescued_students`; student queries could therefore expose unrelated rescued people. v2.2.0 uses `rescued_students.user_id` and scopes student admissions/fees/dashboard data to the logged-in account.
3. **Farmer cross-account exposure:** `farm_records` had no owner. v2.2.0 adds `farmer_user_id` and scopes farmer dashboards/records to the owning farmer.
4. **Logout CSRF/state change:** logout previously worked through GET. It is now POST + CSRF protected.
5. **2FA brute-force protection:** verification now locks the pending session for 5 minutes after repeated failures. Recovery-code consumption is atomic (`used_at IS NULL`).
6. **Session hardening:** strict session cookies, HttpOnly/SameSite settings, session ID regeneration, and error-display suppression are enabled.
7. **RBAC fail-open risk:** unknown authenticated routes are now denied instead of being implicitly allowed.
8. **SQL injection review:** application SQL uses prepared statements for user-controlled values; no dangerous dynamic execution functions were found.
9. **Output encoding review:** displayed user-controlled values use the `e()` HTML escaping helper; no direct request-variable output was found.
10. **Financial duplication control:** operational money records write one corresponding row to `financial_transactions`; source-to-ledger foreign keys are unique, preventing multiple ledger rows for the same source record.
11. **Legacy schema duplication:** unused parallel farm/medical/education/donation table families were removed from the clean-install schema. The active system now has one source of truth for each domain.

## Remaining design choice
`financial_transactions` intentionally duplicates the monetary amount/date as a central accounting ledger. This is not accidental duplication: it provides a single reporting source while the source tables retain operational details.

## Clean-install note
`database/farm.sql` is a **clean-install schema**. Back up any existing `farm` database before importing it because it removes obsolete legacy tables so the system starts from one consistent schema.

## Verification performed
- All PHP files pass `php -l`.
- The seeded account hashes are configured for the current default credentials and should be changed after first deployment.
- No `eval`, shell execution, `base64_decode`, or similar dangerous PHP execution functions found.
- No remaining PHP queries reference the removed `students` or `donations` tables.
