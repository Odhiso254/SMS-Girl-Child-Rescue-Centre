<?php
require __DIR__.'/config/config.php'; require_login(); verify_csrf();
$title='Traditions'; $page='traditions'; $action=$_GET['action']??'list';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!can_manage_records()){flash('error','Only Admin or Director can modify tradition/community records.');redirect('traditions.php');}
 $data["name"]=trim((string)($_POST["name"]??""));$data["location"]=trim((string)($_POST["location"]??""));$data["contact_person"]=trim((string)($_POST["contact_person"]??""));$data["notes"]=trim((string)($_POST["notes"]??""));
 $s=$pdo->prepare("INSERT INTO traditions (name,location,contact_person,notes) VALUES (?,?,?,?)");
 $s->execute([$data["name"],$data["location"],$data["contact_person"],$data["notes"]]);
 audit($pdo,'Created Traditions','traditions',(int)$pdo->lastInsertId());
 flash('success','Record created successfully.'); redirect('traditions.php');
}
$rows=$pdo->query("SELECT * FROM traditions ORDER BY id DESC")->fetchAll();
require __DIR__.'/partials/header.php';
?>
<div class="hero"><div><h1>Traditions</h1><p>Maintain community and cultural records securely.</p></div><?php if(can_manage_records()): ?><a class="btn" href="?action=add">+ Add record</a><?php endif; ?></div>
<?php if($action==='add'):?>
<div class="card"><h3>Add record</h3><form method="post"><?=csrf_field()?><div class="formgrid"><div class="field"><label>Tradition / community</label><input type="text" name="name" required></div><div class="field"><label>Location</label><input type="text" name="location" ></div><div class="field"><label>Contact person</label><input type="text" name="contact_person" ></div><div class="field full"><label>Notes</label><textarea name="notes"></textarea></div></div><div class="form-actions"><button class="btn">Save record</button><a class="btn secondary" href="traditions.php">Cancel</a></div></form></div>
<?php else:?>
<div class="card"><div class="searchbar"><input id="search" placeholder="Search this table..."></div><div class="tablewrap"><table class="table" id="data"><thead><tr><th>Name</th><th>Location</th><th>Contact</th><th>Actions</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e((string)$r["name"])?></td><td><?=e((string)$r["location"])?></td><td><?=e((string)$r["contact_person"])?></td><td><?php if(can_manage_records()):?><a class="btn small" href="record_manager.php?entity=traditions&id=<?=$r['id']?>">Edit / Update</a><form class="inline-form" method="post" action="record_manager.php?entity=traditions&amp;id=<?=$r['id']?>"><?=csrf_field()?><input type="hidden" name="op" value="delete"><button class="btn small danger" type="submit" data-confirm="Delete this record?">Delete</button></form><?php endif;?> <button class="btn small secondary" onclick="window.print()">Print</button></td></tr><?php endforeach;?></tbody></table></div></div>
<script>document.getElementById('search').addEventListener('input',e=>{let q=e.target.value.toLowerCase();document.querySelectorAll('#data tbody tr').forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?'':'none')})</script>
<?php endif; require __DIR__.'/partials/footer.php'; ?>