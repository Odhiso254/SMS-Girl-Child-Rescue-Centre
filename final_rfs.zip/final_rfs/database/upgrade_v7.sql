USE farm;

-- SUGUTA v7: petty-cash monthly debt carry-forward and permanent installation unlock.
CREATE TABLE IF NOT EXISTS petty_cash_months (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 month_start DATE NOT NULL,
 debt_settled DECIMAL(12,2) NOT NULL DEFAULT 0,
 carried_forward_debt DECIMAL(12,2) NOT NULL DEFAULT 0,
 notes VARCHAR(255) NULL,
 updated_by INT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_petty_month(month_start),
 KEY idx_petty_month(month_start),
 CONSTRAINT fk_petty_month_user FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS system_settings (
 setting_key VARCHAR(80) PRIMARY KEY,
 setting_value TEXT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- Farm financial classification so farm sales/expenses can feed the central financial dashboard.
SET @farm_col_exists := (
 SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
 WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='farm_records' AND COLUMN_NAME='financial_type'
);
SET @farm_sql := IF(@farm_col_exists=0,
 'ALTER TABLE farm_records ADD COLUMN financial_type ENUM(''None'',''Sale'',''Expense'') NOT NULL DEFAULT ''None'' AFTER amount',
 'SELECT 1');
PREPARE farm_stmt FROM @farm_sql; EXECUTE farm_stmt; DEALLOCATE PREPARE farm_stmt;
