USE farm;

ALTER TABLE users ADD COLUMN id_number VARCHAR(50) NULL AFTER full_name;
UPDATE users SET id_number=CONCAT('LEGACY-',id) WHERE id_number IS NULL OR id_number='';
ALTER TABLE users MODIFY id_number VARCHAR(50) NOT NULL;
ALTER TABLE users ADD UNIQUE KEY uq_id_number(id_number);

CREATE TABLE IF NOT EXISTS password_recovery_requests (
 id BIGINT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, username VARCHAR(100) NOT NULL, id_number VARCHAR(50) NOT NULL,
 status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending', temporary_password_hash VARCHAR(255) NULL,
 processed_by INT NULL, processed_at DATETIME NULL, admin_note VARCHAR(255) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 KEY idx_recovery_status(status,created_at),
 CONSTRAINT fk_recovery_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_recovery_admin FOREIGN KEY(processed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
