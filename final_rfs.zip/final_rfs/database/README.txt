XAMPP DATABASE SETUP
=====================
Database name: farm

Import database/farm.sql in phpMyAdmin.

The application connects to:
  Host: 127.0.0.1
  Database: farm
  User: root
  Password: (blank by default on a fresh XAMPP installation)

For a production/local-network deployment, set a strong MySQL password and
update config/config.php accordingly.

SMI GIRL CHILD RESCUE CENTRE NOTES
===================================
The SQL includes Super Admin, Manager, Director and Coordinator roles,
pending-account approval support, Petty Cash, and the Farm Records schema
without the old Record type field.


V8 INSTALLATION / IMPORT FIX
1. In phpMyAdmin select the farm database.
2. For a clean installation, drop/delete the existing farm database and create it again, or import farm.sql into an empty database.
3. Import database/farm.sql. The duplicate system_settings DROP error from earlier builds has been removed.
4. Do not import farm.sql repeatedly into a live database because it is a clean-install schema and intentionally recreates tables.
5. For an existing installation that must keep its data, use the appropriate upgrade SQL files instead of farm.sql.
