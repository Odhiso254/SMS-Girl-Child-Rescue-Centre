USE farm;

-- SUGUTA v6 role/security upgrade
UPDATE users
SET username='direct',
    full_name='Sister Suguta',
    email='director@smirescuecentre.local',
    password_hash='$2y$12$CbdOy4wxrQSJoNZgmRh/teQjjyw22ooR9cUROJDtrnksaYhcjxLDS',
    role='director',
    approval_status='approved',
    is_verified=1,
    is_active=1
WHERE role='director' LIMIT 1;

-- If no director existed, create the dedicated Director account.
INSERT INTO users(username,full_name,id_number,email,password_hash,role,approval_status,is_verified,is_active)
SELECT 'direct','Sister Suguta','DIR-001','director@smirescuecentre.local',
'$2y$12$CbdOy4wxrQSJoNZgmRh/teQjjyw22ooR9cUROJDtrnksaYhcjxLDS','director','approved',1,1
WHERE NOT EXISTS (SELECT 1 FROM users WHERE role='director');

-- Messaging configuration/log table. Credentials are configured in config/config.php.
CREATE TABLE IF NOT EXISTS director_message_logs (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 message_date DATE NOT NULL,
 period ENUM('morning','evening') NOT NULL,
 channel ENUM('sms','whatsapp') NOT NULL,
 recipient VARCHAR(40) NOT NULL,
 status ENUM('sent','failed','skipped') NOT NULL,
 provider_message_id VARCHAR(190) NULL,
 response_text TEXT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_director_message(message_date,period,channel),
 KEY idx_director_message_date(message_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

