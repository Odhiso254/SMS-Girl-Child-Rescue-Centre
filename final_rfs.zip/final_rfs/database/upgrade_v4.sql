USE farm;

-- Run once when upgrading an existing installation to v4.0.0.
ALTER TABLE users ADD COLUMN profile_photo VARCHAR(255) NULL AFTER totp_enabled;
ALTER TABLE users ADD INDEX idx_users_approval (approval_status, is_active);

INSERT INTO users(username,full_name,email,password_hash,role,approval_status,is_verified,is_active)
VALUES ('user','Standard User','user@example.com','$2y$12$/ILYvGKnSOgyrLlB8zBQiO4qYtMoBQero0kEdeP/wSZgZjh0RNwNm','staff','approved',1,1)
ON DUPLICATE KEY UPDATE username=username;
