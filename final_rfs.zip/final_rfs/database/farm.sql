CREATE DATABASE IF NOT EXISTS farm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE farm;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS director_message_logs;
DROP TABLE IF EXISTS petty_cash_monthly_records,petty_cash_months,petty_cash,password_recovery_requests,financial_transactions,user_backup_codes,health_treatments,school_fee_payments,donor_supports,hospital_visits,hospitals,school_admissions,rescue_incidents,emergency_types,traditions,farm_records,farmers,donors,rescued_students,audit_logs,login_activity,password_resets,otp_verifications,notifications,reports,system_settings,users,roles;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE roles (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(30) NOT NULL UNIQUE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO roles(name) VALUES ('admin'),('staff'),('manager'),('director'),('coordinator'),('farmer'),('doctor'),('student'),('donor');

CREATE TABLE users (

 id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(100) NOT NULL, full_name VARCHAR(150) NOT NULL, id_number VARCHAR(50) NOT NULL, email VARCHAR(190) NULL, phone VARCHAR(40) NULL, password_hash VARCHAR(255) NOT NULL, role VARCHAR(30) NOT NULL, approval_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved', is_verified TINYINT(1) NOT NULL DEFAULT 1, is_active TINYINT(1) NOT NULL DEFAULT 1, totp_secret VARCHAR(64) NULL, totp_enabled TINYINT(1) NOT NULL DEFAULT 0, profile_photo VARCHAR(255) NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_username_role(username,role), UNIQUE KEY uq_id_number(id_number), UNIQUE KEY uq_email(email), KEY idx_users_role(role), KEY idx_users_approval(approval_status,is_active), CONSTRAINT fk_users_role FOREIGN KEY(role) REFERENCES roles(name) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE notifications (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NULL,
 recipient_role VARCHAR(30) NULL,
 title VARCHAR(180) NOT NULL,
 message TEXT NOT NULL,
 link VARCHAR(255) NULL,
 is_read TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 KEY idx_notifications_user_read(user_id,is_read,created_at),
 KEY idx_notifications_role_read(recipient_role,is_read,created_at),
 CONSTRAINT fk_notifications_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE director_message_logs (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 message_date DATE NOT NULL,
 period ENUM('morning','evening') NOT NULL,
 channel ENUM('sms','whatsapp') NOT NULL,
 recipient VARCHAR(40) NOT NULL,
 status ENUM('sent','failed','skipped') NOT NULL,
 provider_message_id VARCHAR(190) NULL,
 response_text TEXT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_director_message(message_date,period,channel),
 KEY idx_director_message_date(message_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE otp_verifications (id BIGINT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL,identifier VARCHAR(190) NOT NULL,channel ENUM('email','phone') NOT NULL,otp_hash VARCHAR(255) NOT NULL,expires_at DATETIME NOT NULL,used_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_otp_identifier(identifier),KEY idx_otp_expiry(expires_at),CONSTRAINT fk_otp_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE password_resets (id BIGINT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,otp_hash VARCHAR(255) NOT NULL,expires_at DATETIME NOT NULL,used_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_reset_expiry(expires_at),CONSTRAINT fk_reset_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE password_recovery_requests (id BIGINT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,username VARCHAR(100) NOT NULL,id_number VARCHAR(50) NOT NULL,status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',temporary_password_hash VARCHAR(255) NULL,processed_by INT NULL,processed_at DATETIME NULL,admin_note VARCHAR(255) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_recovery_status(status,created_at),CONSTRAINT fk_recovery_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,CONSTRAINT fk_recovery_admin FOREIGN KEY(processed_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE login_activity (id BIGINT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL,username VARCHAR(100) NOT NULL,role VARCHAR(30) NULL,success TINYINT(1) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,ip_address VARCHAR(64) NULL,KEY idx_login_ip_time(ip_address,created_at),KEY idx_login_user_time(user_id,created_at),CONSTRAINT fk_login_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE audit_logs (id BIGINT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL,action VARCHAR(180) NOT NULL,details TEXT NULL,entity VARCHAR(80) NULL,entity_id BIGINT NULL,ip_address VARCHAR(64) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_audit_user(user_id),KEY idx_audit_date(created_at),CONSTRAINT fk_audit_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE user_backup_codes (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,code_hash VARCHAR(255) NOT NULL,used_at DATETIME NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_backup_user_status(user_id,used_at),CONSTRAINT fk_backup_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE system_settings (
 setting_key VARCHAR(80) PRIMARY KEY,
 setting_value TEXT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE traditions (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150) NOT NULL,location VARCHAR(150),contact_person VARCHAR(150),notes TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_tradition_name(name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE emergency_types (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL UNIQUE,description TEXT,active TINYINT(1) NOT NULL DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE rescued_students (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL UNIQUE,full_name VARCHAR(160) NOT NULL,gender ENUM('Female','Male','Other') NOT NULL DEFAULT 'Female',dob DATE NULL,tradition_id INT NULL,rescue_date DATE NULL,guardian_name VARCHAR(150),guardian_phone VARCHAR(40),education_status ENUM('Primary','Secondary','College','University','Not in School') NOT NULL DEFAULT 'Not in School',current_school_name VARCHAR(180) NULL,status ENUM('Active','Graduated','Transferred','Inactive') DEFAULT 'Active',notes TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_student_tradition(tradition_id),KEY idx_student_education(education_status),KEY idx_student_status(status),CONSTRAINT fk_rescued_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL,CONSTRAINT fk_student_tradition FOREIGN KEY(tradition_id) REFERENCES traditions(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE rescue_incidents (id BIGINT AUTO_INCREMENT PRIMARY KEY,student_id INT NOT NULL,emergency_type_id INT NOT NULL,incident_date DATE NOT NULL,location VARCHAR(180),severity ENUM('Low','Moderate','High','Critical') NOT NULL DEFAULT 'Moderate',description TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_rescue_student(student_id),KEY idx_rescue_type(emergency_type_id),KEY idx_rescue_date(incident_date),CONSTRAINT fk_rescue_student FOREIGN KEY(student_id) REFERENCES rescued_students(id) ON DELETE CASCADE,CONSTRAINT fk_rescue_type FOREIGN KEY(emergency_type_id) REFERENCES emergency_types(id) ON DELETE RESTRICT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE school_admissions (id INT AUTO_INCREMENT PRIMARY KEY,student_id INT NOT NULL,level ENUM('Primary','Secondary','College','University') NOT NULL,institution VARCHAR(180) NOT NULL,course_or_class VARCHAR(150),admission_date DATE NULL,status ENUM('Applied','Admitted','Enrolled','Completed','Declined') DEFAULT 'Applied',fees DECIMAL(12,2) DEFAULT 0,notes TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_student_institution_level(student_id,institution,level),KEY idx_admission_student(student_id),KEY idx_admission_status(status),CONSTRAINT fk_admission_student FOREIGN KEY(student_id) REFERENCES rescued_students(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE hospitals (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(180) NOT NULL,location VARCHAR(180),phone VARCHAR(40),contact_person VARCHAR(150),emergency_services TINYINT(1) NOT NULL DEFAULT 1,notes TEXT,active TINYINT(1) NOT NULL DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_hospital_name(name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE doctors (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL UNIQUE,specialization VARCHAR(150),facility VARCHAR(200),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE hospital_visits (id BIGINT AUTO_INCREMENT PRIMARY KEY,student_id INT NOT NULL,hospital_id INT NOT NULL,doctor_id INT NULL,rescue_incident_id BIGINT NULL,visit_date DATE NOT NULL,visit_type ENUM('Outpatient','Inpatient','Emergency','Referral','Follow-up') NOT NULL DEFAULT 'Outpatient',diagnosis VARCHAR(255),doctor VARCHAR(150),admission_date DATE NULL,discharge_date DATE NULL,status ENUM('Open','Treated','Referred','Discharged') NOT NULL DEFAULT 'Open',notes TEXT,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_visit_student(student_id),KEY idx_visit_hospital(hospital_id),KEY idx_visit_doctor(doctor_id),KEY idx_visit_date(visit_date),CONSTRAINT fk_visit_student FOREIGN KEY(student_id) REFERENCES rescued_students(id) ON DELETE CASCADE,CONSTRAINT fk_visit_hospital FOREIGN KEY(hospital_id) REFERENCES hospitals(id) ON DELETE RESTRICT,CONSTRAINT fk_visit_doctor FOREIGN KEY(doctor_id) REFERENCES doctors(id) ON DELETE SET NULL,CONSTRAINT fk_visit_incident FOREIGN KEY(rescue_incident_id) REFERENCES rescue_incidents(id) ON DELETE SET NULL,CONSTRAINT fk_visit_creator FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE health_treatments (id BIGINT AUTO_INCREMENT PRIMARY KEY,visit_id BIGINT NOT NULL,treatment_date DATE NOT NULL,treatment VARCHAR(255) NOT NULL,provider VARCHAR(150),amount DECIMAL(12,2) NOT NULL DEFAULT 0,payment_status ENUM('Unpaid','Paid','Sponsored','Waived') NOT NULL DEFAULT 'Unpaid',notes TEXT,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_treatment_visit(visit_id),CONSTRAINT fk_treatment_visit FOREIGN KEY(visit_id) REFERENCES hospital_visits(id) ON DELETE CASCADE,CONSTRAINT fk_treatment_creator FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE farmers (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL UNIQUE,farm_name VARCHAR(150),location VARCHAR(255),farm_size DECIMAL(12,2),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_farmer_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE farm_records (id INT AUTO_INCREMENT PRIMARY KEY,farmer_user_id INT NOT NULL,category ENUM('Poultry','Dairy','Crop') NOT NULL,item VARCHAR(120) NOT NULL,quantity DECIMAL(12,2) DEFAULT 0,unit VARCHAR(50),amount DECIMAL(12,2) DEFAULT 0,financial_type ENUM('None','Sale','Expense') NOT NULL DEFAULT 'None',record_date DATE NOT NULL,buyer_or_supplier VARCHAR(160),notes TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_farm_farmer_date(farmer_user_id,record_date),KEY idx_farm_item(item),CONSTRAINT fk_farm_record_farmer FOREIGN KEY(farmer_user_id) REFERENCES users(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE donors (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NULL UNIQUE,name VARCHAR(150) NOT NULL,interests TEXT,organization VARCHAR(200),phone VARCHAR(40),email VARCHAR(190),visit_frequency VARCHAR(50) DEFAULT 'Annual',last_visit DATE NULL,notes TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,CONSTRAINT fk_donor_user FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE donor_supports (id BIGINT AUTO_INCREMENT PRIMARY KEY,donor_id INT NOT NULL,student_id INT NULL,support_category ENUM('Centre Support','Food Support','Other Income') NOT NULL,amount DECIMAL(12,2) NOT NULL,support_date DATE NOT NULL,description VARCHAR(255) NOT NULL,reference_no VARCHAR(80) NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_support_donor_date(donor_id,support_date),KEY idx_support_student(student_id),CONSTRAINT fk_support_donor FOREIGN KEY(donor_id) REFERENCES donors(id) ON DELETE RESTRICT,CONSTRAINT fk_support_student FOREIGN KEY(student_id) REFERENCES rescued_students(id) ON DELETE SET NULL,CONSTRAINT fk_support_creator FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE school_fee_payments (id BIGINT AUTO_INCREMENT PRIMARY KEY,admission_id INT NOT NULL,student_id INT NOT NULL,amount DECIMAL(12,2) NOT NULL,payment_date DATE NOT NULL,reference_no VARCHAR(80) NULL,description VARCHAR(255) NOT NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,KEY idx_fee_student_date(student_id,payment_date),CONSTRAINT fk_fee_admission FOREIGN KEY(admission_id) REFERENCES school_admissions(id) ON DELETE RESTRICT,CONSTRAINT fk_fee_student FOREIGN KEY(student_id) REFERENCES rescued_students(id) ON DELETE RESTRICT,CONSTRAINT fk_fee_creator FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE petty_cash_months (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 month_start DATE NOT NULL,
 debt_settled DECIMAL(12,2) NOT NULL DEFAULT 0,
 carried_forward_debt DECIMAL(12,2) NOT NULL DEFAULT 0,
 notes VARCHAR(255) NULL,
 updated_by INT NULL,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_petty_month(month_start),
 KEY idx_petty_month(month_start),
 CONSTRAINT fk_petty_month_user FOREIGN KEY(updated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE petty_cash_monthly_records (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 month_start DATE NOT NULL,
 amount DECIMAL(12,2) NOT NULL DEFAULT 0,
 notes VARCHAR(255) NULL,
 recorded_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_petty_monthly_record(month_start),
 KEY idx_petty_monthly_date(month_start),
 CONSTRAINT fk_petty_monthly_user FOREIGN KEY(recorded_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE petty_cash (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 transaction_type ENUM('Income','Expense') NOT NULL DEFAULT 'Expense',
 category VARCHAR(120) NOT NULL,
 amount DECIMAL(12,2) NOT NULL,
 transaction_date DATE NOT NULL,
 paid_to_from VARCHAR(180) NULL,
 reference_no VARCHAR(80) NULL,
 description VARCHAR(255) NOT NULL,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 KEY idx_petty_date(transaction_date),
 CONSTRAINT fk_petty_creator FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE financial_transactions (id BIGINT AUTO_INCREMENT PRIMARY KEY,transaction_type ENUM('Income','Expense') NOT NULL,category ENUM('School Fees','Donor Support','Centre Support','Food Support','Other Income','Farm Sales','Farm Expense','Hospital Treatment','Other Expense') NOT NULL,amount DECIMAL(12,2) NOT NULL,transaction_date DATE NOT NULL,donor_id INT NULL,student_id INT NULL,farm_record_id INT NULL,treatment_id BIGINT NULL,support_id BIGINT NULL,fee_payment_id BIGINT NULL,description VARCHAR(255) NOT NULL,reference_no VARCHAR(80) NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uq_farm_transaction(farm_record_id),UNIQUE KEY uq_treatment_transaction(treatment_id),UNIQUE KEY uq_support_transaction(support_id),UNIQUE KEY uq_fee_transaction(fee_payment_id),KEY idx_fin_date_type(transaction_date,transaction_type),KEY idx_fin_student(student_id),KEY idx_fin_donor(donor_id),CONSTRAINT fk_fin_donor FOREIGN KEY(donor_id) REFERENCES donors(id) ON DELETE SET NULL,CONSTRAINT fk_fin_student FOREIGN KEY(student_id) REFERENCES rescued_students(id) ON DELETE SET NULL,CONSTRAINT fk_fin_farm FOREIGN KEY(farm_record_id) REFERENCES farm_records(id) ON DELETE SET NULL,CONSTRAINT fk_fin_treatment FOREIGN KEY(treatment_id) REFERENCES health_treatments(id) ON DELETE SET NULL,CONSTRAINT fk_fin_support FOREIGN KEY(support_id) REFERENCES donor_supports(id) ON DELETE SET NULL,CONSTRAINT fk_fin_fee FOREIGN KEY(fee_payment_id) REFERENCES school_fee_payments(id) ON DELETE SET NULL,CONSTRAINT fk_fin_creator FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO users(username,full_name,id_number,email,password_hash,role,approval_status,is_verified,is_active) VALUES
('admin','Super Admin','ADMIN-001','admin@example.com','$2y$12$144dcoeVtY1NfX5YoArpjejrdk4/psHpNVhFLFGiBpfftwPkp84GK','admin','approved',1,1),
('user','Standard User','STAFF-001','user@example.com','$2y$12$/ILYvGKnSOgyrLlB8zBQiO4qYtMoBQero0kEdeP/wSZgZjh0RNwNm','staff','approved',1,1),
('sr_Teresa','Manager / Sr Teresa','MGR-001','manager@example.com','$2y$12$Y5KAFaQFZIsfyQoysuJkxuB31Lk/mKuXxTP/yZ8IJYY5vOiKun9Fi','manager','approved',1,1),
('direct','Sister Suguta','DIR-001','director@smirescuecentre.local','$2y$12$CbdOy4wxrQSJoNZgmRh/teQjjyw22ooR9cUROJDtrnksaYhcjxLDS','director','approved',1,1),
('mastermind','Coordinator','COORD-001','coordinator@example.com','$2y$12$tL4gjoW0ujeuTZjwgOdYxuSnMWjNdmsZloRYtUOePRvDPluglrNMG','coordinator','approved',1,1);

INSERT INTO emergency_types(name,description) VALUES ('Flood','Flooding and water-related emergency'),('Landslide','Landslide or mudslide'),('Tsunami','Tsunami or coastal wave emergency'),('Traditional Threat','Traditional or community-related threat'),('Fire','Fire emergency'),('Drought','Severe drought'),('Conflict','Conflict or insecurity'),('Other','Other emergency type');
