<?php
require __DIR__.'/config/config.php';
if (!logged_in()) redirect('login.php');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); header('Allow: POST'); exit('Logout must use POST.'); }
verify_csrf();
audit($pdo,'LOGOUT','users',(int)user()['id']);
$_SESSION=[];
if(ini_get('session.use_cookies')){ $p=session_get_cookie_params(); setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>$p['samesite']??'Strict']);}
session_destroy(); redirect('login.php');
