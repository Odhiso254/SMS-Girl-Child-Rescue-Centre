<?php
declare(strict_types=1);
require_once __DIR__ . '/config/config.php';
if (logged_in()) { redirect('index.php'); }
?>
<!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="3;url=login.php">
<title>SUGUTA · SMI Girl Child Rescue Centre - Loading</title>
<link rel="stylesheet" href="assets/style.css">
</head><body class="splash-body">
<main class="splash-screen" aria-label="SUGUTA · SMI Girl Child Rescue Centre loading">
<section class="splash-card">
<div class="splash-logo">SMI</div><div class="splash-brand">SUGUTA · SMI Girl Child Rescue Centre</div><div class="splash-welcome">Welcome</div>
<p class="splash-subtitle">Rescue Centre Management System</p>
<div class="loader-track"><div id="loaderProgress" class="loader-progress"></div></div>
<div class="loader-meta"><span id="loadPercent">1%</span><span>Loading...</span></div>
</section></main>
<script>(function(){const start=performance.now(),duration=3000,p=document.getElementById('loaderProgress'),t=document.getElementById('loadPercent');function tick(now){const e=now-start,v=Math.min(100,Math.max(1,Math.floor(e/duration*99)+1));p.style.width=v+'%';t.textContent=v+'%';if(e<duration){requestAnimationFrame(tick)}else{window.location.replace('login.php')}}requestAnimationFrame(tick)})();</script>
</body></html>
