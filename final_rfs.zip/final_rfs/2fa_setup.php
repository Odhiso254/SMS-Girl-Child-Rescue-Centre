<?php
require __DIR__.'/config/config.php'; require_login(); require __DIR__.'/config/totp.php';
$title='Two-Factor Authentication'; $page='2fa_setup';
$error=''; $backupCodes=[];

$stmt=$pdo->prepare("SELECT username,totp_secret,totp_enabled FROM users WHERE id=?");
$stmt->execute([user()['id']]); $account=$stmt->fetch();

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $code=trim((string)($_POST['code']??''));
    if (!$account['totp_enabled']) {
        $secret=$_SESSION['pending_totp_secret']??totp_secret();
        $_SESSION['pending_totp_secret']=$secret;
        if (totp_verify($secret,$code)) {
            $u=$pdo->prepare("UPDATE users SET totp_secret=?,totp_enabled=1 WHERE id=?");
            $u->execute([$secret,user()['id']]);
            $backupCodes=generate_backup_codes($pdo,(int)user()['id']);
            unset($_SESSION['pending_totp_secret']);
            audit($pdo,'2FA_ENABLED','users',(int)user()['id'],'TOTP enabled and backup codes generated');
            $account['totp_enabled']=1;
            $account['totp_secret']=$secret;
        } else $error='Invalid 6-digit authenticator code.';
    }
}
$secret=$account['totp_secret'] ?: ($_SESSION['pending_totp_secret']??totp_secret());
$_SESSION['pending_totp_secret']=$secret;
$otpauth='otpauth://totp/'.rawurlencode(APP_NAME.':'.$account['username']).'?secret='.rawurlencode($secret).'&issuer='.rawurlencode(APP_NAME).'&algorithm=SHA1&digits=6&period=30';
require __DIR__.'/partials/header.php';
?>
<div class="hero"><div><h1>Two-Factor Authentication</h1><p>Add an authenticator-app challenge to your account.</p></div></div>
<div class="card">
<?php if($backupCodes): ?>
<div class="flash success"><b>2FA enabled.</b> Save these one-time recovery codes in a secure place. They are shown only now.</div>
<div class="backup-codes"><?php foreach($backupCodes as $c):?><code><?=e($c)?></code><?php endforeach;?></div>
<?php elseif($account['totp_enabled']): ?>
<div class="flash success">2FA is already active on this account.</div>
<?php else: ?>
<p><b>Secret:</b> <code><?=e($secret)?></code></p>
<p>Add the secret to Google Authenticator, Microsoft Authenticator, Authy or another TOTP app. Then enter the current 6-digit code below.</p>
<div class="note"><b>otpauth URI:</b><br><code class="break"><?=e($otpauth)?></code></div>
<form method="post" style="max-width:420px;margin-top:18px"><?=csrf_field()?>
<div class="field"><label>6-digit authenticator code</label><input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required></div>
<button class="btn">Verify & Enable 2FA</button>
</form>
<?php endif; ?>
</div>
<?php require __DIR__.'/partials/footer.php'; ?>
