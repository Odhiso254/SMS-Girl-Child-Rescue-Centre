<?php
// Run twice daily: director_notifications.php morning|evening
require __DIR__.'/../config/config.php';
if(system_is_locked($pdo)){fwrite(STDERR,"System locked; scheduled notifications stopped.\n");exit(0);}
$period=$argv[1]??'';
if(!in_array($period,['morning','evening'],true)){fwrite(STDERR,"Usage: php director_notifications.php morning|evening\n");exit(2);}
$result=send_director_periodic_messages($pdo,$period);
echo json_encode(['period'=>$period,'date'=>date('Y-m-d'),'results'=>$result],JSON_PRETTY_PRINT).PHP_EOL;
