DIRECTOR MESSAGE SCHEDULING — SUGUTA
=====================================
Recipient: Sister Suguta (+254 724 870 350)
Channels: SMS and WhatsApp through Twilio.

1. Configure these values in config/config.php or as server environment variables:
   TWILIO_ACCOUNT_SID
   TWILIO_AUTH_TOKEN
   TWILIO_SMS_FROM
   TWILIO_WHATSAPP_FROM
2. Ensure PHP cURL is enabled.
3. Test:
   php director_notifications.php morning
   php director_notifications.php evening

WINDOWS / XAMPP TASK SCHEDULER
Create two scheduled tasks:
Morning:  php C:\xampp\htdocs\final_rfs\cron\director_notifications.php morning
Evening:  php C:\xampp\htdocs\final_rfs\cron\director_notifications.php evening
Choose the required morning and evening times for the centre.

LINUX CRON EXAMPLE
0 8 * * * /usr/bin/php /var/www/final_rfs/cron/director_notifications.php morning
0 18 * * * /usr/bin/php /var/www/final_rfs/cron/director_notifications.php evening

The database log prevents duplicate sends for the same date/period/channel.
Without Twilio credentials the script records the channel as skipped; it does not falsely claim a message was sent.


AUTOMATIC DATABASE BACKUP
==========================
The application automatically creates a rolling SQL backup at most once every 24 hours in storage\backups.
For a true scheduled task even when no browser user opens the system, use Windows Task Scheduler with:
  C:\xampp\htdocs\final_rfs\server_config\auto_backup_farm.bat
Recommended trigger: Daily. The script is safe to run more frequently because the application keeps the 24-hour interval and retains the latest 14 automatic backups.
Linux cron example:
  15 2 * * * /usr/bin/php /var/www/final_rfs/cron/auto_backup.php
