<?php
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only.'); }
require __DIR__ . '/../config/config.php';
$path=run_database_backup($pdo);
if ($path) { echo "Automatic backup created: {$path}" . PHP_EOL; } else { echo "No new backup was required or backup could not be created." . PHP_EOL; }
