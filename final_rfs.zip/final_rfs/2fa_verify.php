<?php
require __DIR__.'/config/config.php'; require __DIR__.'/config/totp.php';
if (empty($_SESSION['2fa_pending_user_id'])) redirect('login.php');
$error=''; $uid=(int)$_SESSION['2fa_pending_user_id'];

if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    if (!empty($_SESSION['2fa_lock_until']) && time() < (int)$_SESSION['2fa_lock_until']) {
        $error='Too many verification attempts. Please wait 5 minutes.';
    } else {
        $input=strtoupper(trim((string)($_POST['code']??'')));
        $stmt=$pdo->prepare("SELECT * FROM users WHERE id=? AND is_active=1 LIMIT 1");
        $stmt->execute([$uid]); $u=$stmt->fetch();
        $authenticated=false; $backup=false;
        if ($u && preg_match('/^\d{6}$/',$input) && !empty($u['totp_secret'])) {
            $authenticated=totp_verify($u['totp_secret'],$input);
        }
        if (!$authenticated && $u) {
            $s=$pdo->prepare("SELECT id,code_hash FROM user_backup_codes WHERE user_id=? AND used_at IS NULL");
            $s->execute([$uid]);
            foreach($s->fetchAll() as $row){
                if(password_verify($input,$row['code_hash'])){
                    $authenticated=true; $backup=true;
                    $pdo->prepare("UPDATE user_backup_codes SET used_at=NOW() WHERE id=? AND used_at IS NULL")->execute([$row['id']]);
                    break;
                }
            }
        }
        if ($authenticated) {
            session_regenerate_id(true);
            unset($_SESSION['2fa_attempts'],$_SESSION['2fa_lock_until']);
            $_SESSION['user']=['id'=>(int)$u['id'],'username'=>$u['username'],'full_name'=>$u['full_name'],'role'=>$u['role'],'email'=>$u['email'],'phone'=>$u['phone'],'profile_photo'=>$u['profile_photo'] ?? null];
            unset($_SESSION['2fa_pending_user_id'],$_SESSION['2fa_pending_username'],$_SESSION['2fa_pending_role'],$_SESSION['2fa_pending_full_name']);
            audit($pdo,$backup?'2FA_BACKUP_USED':'LOGIN_SUCCESS_2FA','users',(int)$u['id']);
            redirect('index.php');
        }
        $attempts=(int)($_SESSION['2fa_attempts']??0)+1;
        $_SESSION['2fa_attempts']=$attempts;
        if($attempts>=7){ $_SESSION['2fa_lock_until']=time()+300; $_SESSION['2fa_attempts']=0; }
        audit($pdo,'2FA_FAILED','users',$uid,'Failed 2FA verification');
        $error='Invalid authenticator or recovery code.';
    }
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>2FA Verification • <?=e(APP_NAME)?></title><link rel="stylesheet" href="assets/style.css"></head>
<body class="loginpage"><div class="loginbox">
<div class="brand"><div class="brandmark">2F</div><div><b>SECURITY CHECK</b><small><?=e(APP_NAME)?></small></div></div>
<h1>Verify your identity</h1><p>Enter your 6-digit authenticator code or one unused recovery code.</p>
<?php if($error):?><div class="flash error"><?=e($error)?></div><?php endif;?>
<form method="post"><?=csrf_field()?><div class="field"><label>Security code</label><input name="code" inputmode="numeric" autocomplete="one-time-code" autofocus required></div>
<button class="btn">Verify</button></form></div></body></html>
