-- SUGUTA automatic database backup
-- Generated 2026-09-21T09:58:50+02:00
CREATE DATABASE IF NOT EXISTS `farm` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `farm`;
SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(180) NOT NULL,
  `details` text DEFAULT NULL,
  `entity` varchar(80) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  `ip_address` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_date` (`created_at`),
  CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `director_message_logs`;
CREATE TABLE `director_message_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `message_date` date NOT NULL,
  `period` enum('morning','evening') NOT NULL,
  `channel` enum('sms','whatsapp') NOT NULL,
  `recipient` varchar(40) NOT NULL,
  `status` enum('sent','failed','skipped') NOT NULL,
  `provider_message_id` varchar(190) DEFAULT NULL,
  `response_text` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_director_message` (`message_date`,`period`,`channel`),
  KEY `idx_director_message_date` (`message_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `doctors`;
CREATE TABLE `doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `specialization` varchar(150) DEFAULT NULL,
  `facility` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `doctors_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `donor_supports`;
CREATE TABLE `donor_supports` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `donor_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `support_category` enum('Centre Support','Food Support','Other Income') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `support_date` date NOT NULL,
  `description` varchar(255) NOT NULL,
  `reference_no` varchar(80) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_support_donor_date` (`donor_id`,`support_date`),
  KEY `idx_support_student` (`student_id`),
  KEY `fk_support_creator` (`created_by`),
  CONSTRAINT `fk_support_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_support_donor` FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`),
  CONSTRAINT `fk_support_student` FOREIGN KEY (`student_id`) REFERENCES `rescued_students` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `donors`;
CREATE TABLE `donors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `interests` text DEFAULT NULL,
  `organization` varchar(200) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `visit_frequency` varchar(50) DEFAULT 'Annual',
  `last_visit` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_donor_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `emergency_types`;
CREATE TABLE `emergency_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `description` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `emergency_types` (`id`,`name`,`description`,`active`,`created_at`) VALUES ('1','Flood','Flooding and water-related emergency','1','2026-09-21 00:58:38');
INSERT INTO `emergency_types` (`id`,`name`,`description`,`active`,`created_at`) VALUES ('2','Landslide','Landslide or mudslide','1','2026-09-21 00:58:38');
INSERT INTO `emergency_types` (`id`,`name`,`description`,`active`,`created_at`) VALUES ('3','Tsunami','Tsunami or coastal wave emergency','1','2026-09-21 00:58:38');
INSERT INTO `emergency_types` (`id`,`name`,`description`,`active`,`created_at`) VALUES ('4','Traditional Threat','Traditional or community-related threat','1','2026-09-21 00:58:38');
INSERT INTO `emergency_types` (`id`,`name`,`description`,`active`,`created_at`) VALUES ('5','Fire','Fire emergency','1','2026-09-21 00:58:38');
INSERT INTO `emergency_types` (`id`,`name`,`description`,`active`,`created_at`) VALUES ('6','Drought','Severe drought','1','2026-09-21 00:58:38');
INSERT INTO `emergency_types` (`id`,`name`,`description`,`active`,`created_at`) VALUES ('7','Conflict','Conflict or insecurity','1','2026-09-21 00:58:38');
INSERT INTO `emergency_types` (`id`,`name`,`description`,`active`,`created_at`) VALUES ('8','Other','Other emergency type','1','2026-09-21 00:58:38');

DROP TABLE IF EXISTS `farm_records`;
CREATE TABLE `farm_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `farmer_user_id` int(11) NOT NULL,
  `category` enum('Poultry','Dairy','Crop') NOT NULL,
  `item` varchar(120) NOT NULL,
  `quantity` decimal(12,2) DEFAULT 0.00,
  `unit` varchar(50) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT 0.00,
  `financial_type` enum('None','Sale','Expense') NOT NULL DEFAULT 'None',
  `record_date` date NOT NULL,
  `buyer_or_supplier` varchar(160) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_farm_farmer_date` (`farmer_user_id`,`record_date`),
  KEY `idx_farm_item` (`item`),
  CONSTRAINT `fk_farm_record_farmer` FOREIGN KEY (`farmer_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `farmers`;
CREATE TABLE `farmers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `farm_name` varchar(150) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `farm_size` decimal(12,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_farmer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `financial_transactions`;
CREATE TABLE `financial_transactions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `transaction_type` enum('Income','Expense') NOT NULL,
  `category` enum('School Fees','Donor Support','Centre Support','Food Support','Other Income','Farm Sales','Farm Expense','Hospital Treatment','Other Expense') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `transaction_date` date NOT NULL,
  `donor_id` int(11) DEFAULT NULL,
  `student_id` int(11) DEFAULT NULL,
  `farm_record_id` int(11) DEFAULT NULL,
  `treatment_id` bigint(20) DEFAULT NULL,
  `support_id` bigint(20) DEFAULT NULL,
  `fee_payment_id` bigint(20) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `reference_no` varchar(80) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_farm_transaction` (`farm_record_id`),
  UNIQUE KEY `uq_treatment_transaction` (`treatment_id`),
  UNIQUE KEY `uq_support_transaction` (`support_id`),
  UNIQUE KEY `uq_fee_transaction` (`fee_payment_id`),
  KEY `idx_fin_date_type` (`transaction_date`,`transaction_type`),
  KEY `idx_fin_student` (`student_id`),
  KEY `idx_fin_donor` (`donor_id`),
  KEY `fk_fin_creator` (`created_by`),
  CONSTRAINT `fk_fin_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fin_donor` FOREIGN KEY (`donor_id`) REFERENCES `donors` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fin_farm` FOREIGN KEY (`farm_record_id`) REFERENCES `farm_records` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fin_fee` FOREIGN KEY (`fee_payment_id`) REFERENCES `school_fee_payments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fin_student` FOREIGN KEY (`student_id`) REFERENCES `rescued_students` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fin_support` FOREIGN KEY (`support_id`) REFERENCES `donor_supports` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fin_treatment` FOREIGN KEY (`treatment_id`) REFERENCES `health_treatments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `health_treatments`;
CREATE TABLE `health_treatments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `visit_id` bigint(20) NOT NULL,
  `treatment_date` date NOT NULL,
  `treatment` varchar(255) NOT NULL,
  `provider` varchar(150) DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('Unpaid','Paid','Sponsored','Waived') NOT NULL DEFAULT 'Unpaid',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_treatment_visit` (`visit_id`),
  KEY `fk_treatment_creator` (`created_by`),
  CONSTRAINT `fk_treatment_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_treatment_visit` FOREIGN KEY (`visit_id`) REFERENCES `hospital_visits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `hospital_visits`;
CREATE TABLE `hospital_visits` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `rescue_incident_id` bigint(20) DEFAULT NULL,
  `visit_date` date NOT NULL,
  `visit_type` enum('Outpatient','Inpatient','Emergency','Referral','Follow-up') NOT NULL DEFAULT 'Outpatient',
  `diagnosis` varchar(255) DEFAULT NULL,
  `doctor` varchar(150) DEFAULT NULL,
  `admission_date` date DEFAULT NULL,
  `discharge_date` date DEFAULT NULL,
  `status` enum('Open','Treated','Referred','Discharged') NOT NULL DEFAULT 'Open',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_visit_student` (`student_id`),
  KEY `idx_visit_hospital` (`hospital_id`),
  KEY `idx_visit_doctor` (`doctor_id`),
  KEY `idx_visit_date` (`visit_date`),
  KEY `fk_visit_incident` (`rescue_incident_id`),
  KEY `fk_visit_creator` (`created_by`),
  CONSTRAINT `fk_visit_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_visit_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_visit_hospital` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`),
  CONSTRAINT `fk_visit_incident` FOREIGN KEY (`rescue_incident_id`) REFERENCES `rescue_incidents` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_visit_student` FOREIGN KEY (`student_id`) REFERENCES `rescued_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `hospitals`;
CREATE TABLE `hospitals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(180) NOT NULL,
  `location` varchar(180) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `contact_person` varchar(150) DEFAULT NULL,
  `emergency_services` tinyint(1) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_hospital_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `login_activity`;
CREATE TABLE `login_activity` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(100) NOT NULL,
  `role` varchar(30) DEFAULT NULL,
  `success` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_login_ip_time` (`ip_address`,`created_at`),
  KEY `idx_login_user_time` (`user_id`,`created_at`),
  CONSTRAINT `fk_login_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `recipient_role` varchar(30) DEFAULT NULL,
  `title` varchar(180) NOT NULL,
  `message` text NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user_read` (`user_id`,`is_read`,`created_at`),
  KEY `idx_notifications_role_read` (`recipient_role`,`is_read`,`created_at`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `otp_verifications`;
CREATE TABLE `otp_verifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `identifier` varchar(190) NOT NULL,
  `channel` enum('email','phone') NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_otp_identifier` (`identifier`),
  KEY `idx_otp_expiry` (`expires_at`),
  KEY `fk_otp_user` (`user_id`),
  CONSTRAINT `fk_otp_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `password_recovery_requests`;
CREATE TABLE `password_recovery_requests` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `temporary_password_hash` varchar(255) DEFAULT NULL,
  `processed_by` int(11) DEFAULT NULL,
  `processed_at` datetime DEFAULT NULL,
  `admin_note` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recovery_status` (`status`,`created_at`),
  KEY `fk_recovery_user` (`user_id`),
  KEY `fk_recovery_admin` (`processed_by`),
  CONSTRAINT `fk_recovery_admin` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_recovery_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_reset_expiry` (`expires_at`),
  KEY `fk_reset_user` (`user_id`),
  CONSTRAINT `fk_reset_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `petty_cash`;
CREATE TABLE `petty_cash` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `transaction_type` enum('Income','Expense') NOT NULL DEFAULT 'Expense',
  `category` varchar(120) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `transaction_date` date NOT NULL,
  `paid_to_from` varchar(180) DEFAULT NULL,
  `reference_no` varchar(80) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_petty_date` (`transaction_date`),
  KEY `fk_petty_creator` (`created_by`),
  CONSTRAINT `fk_petty_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `petty_cash_monthly_records`;
CREATE TABLE `petty_cash_monthly_records` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `month_start` date NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(255) DEFAULT NULL,
  `recorded_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_petty_monthly_record` (`month_start`),
  KEY `idx_petty_monthly_date` (`month_start`),
  KEY `fk_petty_monthly_user` (`recorded_by`),
  CONSTRAINT `fk_petty_monthly_user` FOREIGN KEY (`recorded_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `petty_cash_months`;
CREATE TABLE `petty_cash_months` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `month_start` date NOT NULL,
  `debt_settled` decimal(12,2) NOT NULL DEFAULT 0.00,
  `carried_forward_debt` decimal(12,2) NOT NULL DEFAULT 0.00,
  `notes` varchar(255) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_petty_month` (`month_start`),
  KEY `idx_petty_month` (`month_start`),
  KEY `fk_petty_month_user` (`updated_by`),
  CONSTRAINT `fk_petty_month_user` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `rescue_incidents`;
CREATE TABLE `rescue_incidents` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `emergency_type_id` int(11) NOT NULL,
  `incident_date` date NOT NULL,
  `location` varchar(180) DEFAULT NULL,
  `severity` enum('Low','Moderate','High','Critical') NOT NULL DEFAULT 'Moderate',
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_rescue_student` (`student_id`),
  KEY `idx_rescue_type` (`emergency_type_id`),
  KEY `idx_rescue_date` (`incident_date`),
  CONSTRAINT `fk_rescue_student` FOREIGN KEY (`student_id`) REFERENCES `rescued_students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rescue_type` FOREIGN KEY (`emergency_type_id`) REFERENCES `emergency_types` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `rescued_students`;
CREATE TABLE `rescued_students` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `full_name` varchar(160) NOT NULL,
  `gender` enum('Female','Male','Other') NOT NULL DEFAULT 'Female',
  `dob` date DEFAULT NULL,
  `tradition_id` int(11) DEFAULT NULL,
  `rescue_date` date DEFAULT NULL,
  `guardian_name` varchar(150) DEFAULT NULL,
  `guardian_phone` varchar(40) DEFAULT NULL,
  `education_status` enum('Primary','Secondary','College','University','Not in School') NOT NULL DEFAULT 'Not in School',
  `current_school_name` varchar(180) DEFAULT NULL,
  `status` enum('Active','Graduated','Transferred','Inactive') DEFAULT 'Active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_student_tradition` (`tradition_id`),
  KEY `idx_student_education` (`education_status`),
  KEY `idx_student_status` (`status`),
  CONSTRAINT `fk_rescued_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_student_tradition` FOREIGN KEY (`tradition_id`) REFERENCES `traditions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `roles` (`id`,`name`) VALUES ('1','admin');
INSERT INTO `roles` (`id`,`name`) VALUES ('5','coordinator');
INSERT INTO `roles` (`id`,`name`) VALUES ('4','director');
INSERT INTO `roles` (`id`,`name`) VALUES ('7','doctor');
INSERT INTO `roles` (`id`,`name`) VALUES ('9','donor');
INSERT INTO `roles` (`id`,`name`) VALUES ('6','farmer');
INSERT INTO `roles` (`id`,`name`) VALUES ('3','manager');
INSERT INTO `roles` (`id`,`name`) VALUES ('2','staff');
INSERT INTO `roles` (`id`,`name`) VALUES ('8','student');

DROP TABLE IF EXISTS `school_admissions`;
CREATE TABLE `school_admissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `level` enum('Primary','Secondary','College','University') NOT NULL,
  `institution` varchar(180) NOT NULL,
  `course_or_class` varchar(150) DEFAULT NULL,
  `admission_date` date DEFAULT NULL,
  `status` enum('Applied','Admitted','Enrolled','Completed','Declined') DEFAULT 'Applied',
  `fees` decimal(12,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_student_institution_level` (`student_id`,`institution`,`level`),
  KEY `idx_admission_student` (`student_id`),
  KEY `idx_admission_status` (`status`),
  CONSTRAINT `fk_admission_student` FOREIGN KEY (`student_id`) REFERENCES `rescued_students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `school_fee_payments`;
CREATE TABLE `school_fee_payments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `admission_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_date` date NOT NULL,
  `reference_no` varchar(80) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fee_student_date` (`student_id`,`payment_date`),
  KEY `fk_fee_admission` (`admission_id`),
  KEY `fk_fee_creator` (`created_by`),
  CONSTRAINT `fk_fee_admission` FOREIGN KEY (`admission_id`) REFERENCES `school_admissions` (`id`),
  CONSTRAINT `fk_fee_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_fee_student` FOREIGN KEY (`student_id`) REFERENCES `rescued_students` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE `system_settings` (
  `setting_key` varchar(80) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `system_settings` (`setting_key`,`setting_value`,`updated_at`) VALUES ('install_started_at','2026-09-21 09:58:50','2026-09-21 00:58:50');
INSERT INTO `system_settings` (`setting_key`,`setting_value`,`updated_at`) VALUES ('last_seen_at','2026-09-21 09:58:50','2026-09-21 00:58:50');

DROP TABLE IF EXISTS `traditions`;
CREATE TABLE `traditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `location` varchar(150) DEFAULT NULL,
  `contact_person` varchar(150) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tradition_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `user_backup_codes`;
CREATE TABLE `user_backup_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_backup_user_status` (`user_id`,`used_at`),
  CONSTRAINT `fk_backup_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(30) NOT NULL,
  `approval_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'approved',
  `is_verified` tinyint(1) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `totp_secret` varchar(64) DEFAULT NULL,
  `totp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `profile_photo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username_role` (`username`,`role`),
  UNIQUE KEY `uq_id_number` (`id_number`),
  UNIQUE KEY `uq_email` (`email`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_approval` (`approval_status`,`is_active`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role`) REFERENCES `roles` (`name`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
INSERT INTO `users` (`id`,`username`,`full_name`,`id_number`,`email`,`phone`,`password_hash`,`role`,`approval_status`,`is_verified`,`is_active`,`totp_secret`,`totp_enabled`,`profile_photo`,`created_at`) VALUES ('1','admin','Super Admin','ADMIN-001','admin@example.com',NULL,'$2y$12$144dcoeVtY1NfX5YoArpjejrdk4/psHpNVhFLFGiBpfftwPkp84GK','admin','approved','1','1',NULL,'0',NULL,'2026-09-21 00:58:37');
INSERT INTO `users` (`id`,`username`,`full_name`,`id_number`,`email`,`phone`,`password_hash`,`role`,`approval_status`,`is_verified`,`is_active`,`totp_secret`,`totp_enabled`,`profile_photo`,`created_at`) VALUES ('2','user','Standard User','STAFF-001','user@example.com',NULL,'$2y$12$/ILYvGKnSOgyrLlB8zBQiO4qYtMoBQero0kEdeP/wSZgZjh0RNwNm','staff','approved','1','1',NULL,'0',NULL,'2026-09-21 00:58:37');
INSERT INTO `users` (`id`,`username`,`full_name`,`id_number`,`email`,`phone`,`password_hash`,`role`,`approval_status`,`is_verified`,`is_active`,`totp_secret`,`totp_enabled`,`profile_photo`,`created_at`) VALUES ('3','sr_Teresa','Manager / Sr Teresa','MGR-001','manager@example.com',NULL,'$2y$12$Y5KAFaQFZIsfyQoysuJkxuB31Lk/mKuXxTP/yZ8IJYY5vOiKun9Fi','manager','approved','1','1',NULL,'0',NULL,'2026-09-21 00:58:37');
INSERT INTO `users` (`id`,`username`,`full_name`,`id_number`,`email`,`phone`,`password_hash`,`role`,`approval_status`,`is_verified`,`is_active`,`totp_secret`,`totp_enabled`,`profile_photo`,`created_at`) VALUES ('4','direct','Sister Suguta','DIR-001','director@smirescuecentre.local',NULL,'$2y$12$CbdOy4wxrQSJoNZgmRh/teQjjyw22ooR9cUROJDtrnksaYhcjxLDS','director','approved','1','1',NULL,'0',NULL,'2026-09-21 00:58:37');
INSERT INTO `users` (`id`,`username`,`full_name`,`id_number`,`email`,`phone`,`password_hash`,`role`,`approval_status`,`is_verified`,`is_active`,`totp_secret`,`totp_enabled`,`profile_photo`,`created_at`) VALUES ('5','mastermind','Coordinator','COORD-001','coordinator@example.com',NULL,'$2y$12$tL4gjoW0ujeuTZjwgOdYxuSnMWjNdmsZloRYtUOePRvDPluglrNMG','coordinator','approved','1','1',NULL,'0',NULL,'2026-09-21 00:58:37');

SET FOREIGN_KEY_CHECKS=1;
