<?php
require __DIR__.'/config/config.php';
if (!logged_in()) { redirect('splash.php'); }
require_login();
$title='Dashboard'; $page='dashboard'; $r=role();
$license=license_status($pdo);
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['op']??'')==='unlock_system'){
    verify_csrf();
    if($r!=='admin'){http_response_code(403);exit('403 Forbidden');}
    if(unlock_system($pdo,(string)($_POST['unlock_code']??''))){
        audit($pdo,'System unlocked permanently','system_settings');
        redirect('index.php?unlocked=1');
    }
    $unlockError='Invalid unlock credential.';
}
if($license['locked'] && $r!=='admin'){
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>System Locked</title><style>body{font-family:Arial,sans-serif;background:#f4f7f6;margin:0;display:grid;place-items:center;min-height:100vh}.box{background:#fff;max-width:560px;padding:32px;border-radius:16px;box-shadow:0 12px 40px #0001;text-align:center}a{display:inline-block;padding:12px 18px;border-radius:8px;text-decoration:none;background:#0d6b4a;color:#fff;font-weight:700}</style></head><body><div class="box"><h1>System Locked</h1><p>Access has stopped because the installation period has ended.</p><p>Please contact the administrator to unlock the system permanently.</p><a href="unlock.php">Open System Unlock</a> <a href="logout.php">Logout</a></div></body></html>';
    exit;
}
if($license['locked'] && $r==='admin'){
    $csrf=csrf_field();
    $reason=$license['clock_tampered']?'The system detected a server clock change.':'The 30-day installation period has ended.';
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Administrator Unlock</title><style>body{font-family:Arial,sans-serif;background:#f4f7f6;margin:0;display:grid;place-items:center;min-height:100vh}.box{background:#fff;max-width:560px;padding:32px;border-radius:16px;box-shadow:0 12px 40px #0001}.box h1{margin-top:0}.box input{width:100%;box-sizing:border-box;padding:12px;border:1px solid #ccc;border-radius:8px;margin:8px 0 16px}.box button{padding:12px 18px;border:0;border-radius:8px;background:#0d6b4a;color:#fff;font-weight:700}.err{color:#b00020;margin-bottom:12px}a{display:inline-block;margin-left:8px}</style></head><body><div class="box"><h1>Administrator Unlock</h1><p>'.e($reason).'</p>'.(!empty($unlockError)?'<div class="err">'.e($unlockError).'</div>':'').'<form method="post">'.$csrf.'<input type="hidden" name="op" value="unlock_system"><label>Unlock code</label><input type="password" name="unlock_code" autocomplete="off" required><button type="submit">Unlock permanently</button> <a href="logout.php">Logout</a></form></div></body></html>';
    exit;
}

if($r==='farmer'){
    $q=$pdo->prepare("SELECT COUNT(*) n FROM farm_records WHERE farmer_user_id=?");$q->execute([user()['id']]);$records=(int)$q->fetch()['n'];
    $q=$pdo->prepare("SELECT COALESCE(SUM(ft.amount),0) n FROM financial_transactions ft JOIN farm_records fr ON fr.id=ft.farm_record_id WHERE fr.farmer_user_id=? AND ft.transaction_type='Income'");$q->execute([user()['id']]);$sales=(float)$q->fetch()['n'];
    $q=$pdo->prepare("SELECT COALESCE(SUM(ft.amount),0) n FROM financial_transactions ft JOIN farm_records fr ON fr.id=ft.farm_record_id WHERE fr.farmer_user_id=? AND ft.transaction_type='Expense'");$q->execute([user()['id']]);$expenses=(float)$q->fetch()['n'];
    $q=$pdo->prepare("SELECT COALESCE(SUM(quantity),0) n FROM farm_records WHERE farmer_user_id=?");$q->execute([user()['id']]);$production=(float)$q->fetch()['n'];
    $q=$pdo->prepare("SELECT * FROM farm_records WHERE farmer_user_id=? ORDER BY id DESC LIMIT 8");$q->execute([user()['id']]);$recent=$q->fetchAll();
    require __DIR__.'/partials/header.php'; ?>
    <div class="hero"><div><h1>Farming Dashboard</h1><p>Manage farming production, sales, expenses and stock from your dedicated workspace.</p></div><a class="btn" href="farm.php?action=add">+ Add farm record</a></div>
    <div class="cards">
      <div class="card metric"><div class="label">FARM RECORDS</div><div class="value"><?=number_format($records)?></div><div class="hint">All farming records</div></div>
      <div class="card metric"><div class="label">FARM SALES</div><div class="value"><?=money($sales)?></div><div class="hint">Recorded sales</div></div>
      <div class="card metric"><div class="label">FARM EXPENSES</div><div class="value"><?=money($expenses)?></div><div class="hint">Recorded expenses</div></div>
      <div class="card metric"><div class="label">PRODUCTION QTY</div><div class="value"><?=number_format($production,2)?></div><div class="hint">Production records</div></div>
    </div>
    <div class="card" style="margin-top:16px"><h3>Recent farm activity</h3><div class="tablewrap"><table class="table"><tr><th>Date</th><th>Category</th><th>Item</th><th>Quantity</th><th>Amount</th></tr>
    <?php foreach($recent as $x):?><tr><td><?=e($x['record_date'])?></td><td><?=e($x['category'])?></td><td><?=e($x['item'])?></td><td><?=e((string)$x['quantity'])?> <?=e((string)$x['unit'])?></td><td><?=money((float)$x['amount'])?></td></tr><?php endforeach;?>
    </table></div></div>
<?php require __DIR__.'/partials/footer.php'; exit; }

if($r==='doctor'){
    $h=(int)$pdo->query("SELECT COUNT(*) n FROM hospitals WHERE active=1")->fetch()['n'];
    $v=(int)$pdo->query("SELECT COUNT(*) n FROM hospital_visits")->fetch()['n'];
    $t=(int)$pdo->query("SELECT COUNT(*) n FROM health_treatments")->fetch()['n'];
    $recent=$pdo->query("SELECT v.visit_date,v.visit_type,v.status,h.name hospital_name,s.full_name FROM hospital_visits v JOIN hospitals h ON h.id=v.hospital_id JOIN rescued_students s ON s.id=v.student_id ORDER BY v.id DESC LIMIT 8")->fetchAll();
    require __DIR__.'/partials/header.php'; ?>
    <div class="hero"><div><h1>Health Dashboard</h1><p>Dedicated clinical workspace for hospitals, visits and treatments.</p></div><a class="btn" href="hospital_visits.php?action=add">+ Record visit</a></div>
    <div class="cards"><div class="card metric"><div class="label">ACTIVE HOSPITALS</div><div class="value"><?=$h?></div><div class="hint">Health facilities</div></div><div class="card metric"><div class="label">HOSPITAL VISITS</div><div class="value"><?=$v?></div><div class="hint">Recorded visits</div></div><div class="card metric"><div class="label">TREATMENTS</div><div class="value"><?=$t?></div><div class="hint">Treatment records</div></div></div>
    <div class="card" style="margin-top:16px"><h3>Recent clinical activity</h3><div class="tablewrap"><table class="table"><tr><th>Date</th><th>Patient</th><th>Hospital</th><th>Visit</th><th>Status</th></tr><?php foreach($recent as $x):?><tr><td><?=e($x['visit_date'])?></td><td><?=e($x['full_name'])?></td><td><?=e($x['hospital_name'])?></td><td><?=e($x['visit_type'])?></td><td><?=e($x['status'])?></td></tr><?php endforeach;?></table></div></div>
<?php require __DIR__.'/partials/footer.php'; exit; }

if($r==='student'){
    $sid=null; $q=$pdo->prepare("SELECT id FROM rescued_students WHERE user_id=? LIMIT 1"); $q->execute([user()['id']]); $st=$q->fetch(); $sid=$st['id']??null;
    $ad=0;$fees=0;
    if($sid){$q=$pdo->prepare("SELECT COUNT(*) n FROM school_admissions WHERE student_id=?");$q->execute([$sid]);$ad=(int)$q->fetch()['n'];$q=$pdo->prepare("SELECT COALESCE(SUM(amount),0) n FROM school_fee_payments WHERE student_id=?");$q->execute([$sid]);$fees=(float)$q->fetch()['n'];}
    require __DIR__.'/partials/header.php'; ?>
    <div class="hero"><div><h1>Student Dashboard</h1><p>Your school workspace. View your admissions and fee records.</p></div><a class="btn" href="admissions.php">View admissions</a></div>
    <div class="cards"><div class="card metric"><div class="label">MY ADMISSIONS</div><div class="value"><?=$ad?></div><div class="hint">Linked to your account</div></div><div class="card metric"><div class="label">MY FEES PAID</div><div class="value"><?=money($fees)?></div><div class="hint">Your recorded payments</div></div></div>
<?php require __DIR__.'/partials/footer.php'; exit; }

if($r==='admin' || $r==='director'){
    $counts=[];$queries=[
        'students'=>['Rescued People',"SELECT COUNT(*) n FROM rescued_students WHERE status<>'Inactive'"],
        'incidents'=>['Rescue Incidents','SELECT COUNT(*) n FROM rescue_incidents'],
        'hospitals'=>['Hospitals','SELECT COUNT(*) n FROM hospitals WHERE active=1'],
        'visits'=>['Hospital Visits','SELECT COUNT(*) n FROM hospital_visits'],
        'admissions'=>['School Admissions','SELECT COUNT(*) n FROM school_admissions'],
        'farm'=>['Farm Records','SELECT COUNT(*) n FROM farm_records']
    ];
    foreach($queries as $k=>$v){$counts[$k]=[$v[0],(int)$pdo->query($v[1])->fetch()['n']];}
    $centralIncome=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM financial_transactions WHERE transaction_type='Income'")->fetchColumn();
    $centralExpense=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM financial_transactions WHERE transaction_type='Expense'")->fetchColumn();
    $pettyIncome=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM petty_cash WHERE transaction_type='Income'")->fetchColumn();
    $pettyExpense=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM petty_cash WHERE transaction_type='Expense'")->fetchColumn();
    $financialByCategory=$pdo->query("SELECT category,transaction_type,COALESCE(SUM(amount),0) total FROM financial_transactions GROUP BY category,transaction_type ORDER BY category,transaction_type")->fetchAll();
    $financialMap=[];
    foreach($financialByCategory as $f){$financialMap[$f['category'].'|'.$f['transaction_type']]=(float)$f['total'];}
    $subsystems=[
      'School Fees'=>['income'=>$financialMap['School Fees|Income']??0,'expense'=>0],
      'Donor Support'=>['income'=>$financialMap['Donor Support|Income']??0,'expense'=>0],
      'Centre Support'=>['income'=>$financialMap['Centre Support|Income']??0,'expense'=>0],
      'Food Support'=>['income'=>$financialMap['Food Support|Income']??0,'expense'=>0],
      'Farm Sales'=>['income'=>$financialMap['Farm Sales|Income']??0,'expense'=>0],
      'Farm Expense'=>['income'=>0,'expense'=>$financialMap['Farm Expense|Expense']??0],
      'Hospital Treatment'=>['income'=>0,'expense'=>$financialMap['Hospital Treatment|Expense']??0],
      'Other Income'=>['income'=>$financialMap['Other Income|Income']??0,'expense'=>0],
      'Other Expense'=>['income'=>0,'expense'=>$financialMap['Other Expense|Expense']??0],
      'Petty Cash'=>['income'=>$pettyIncome,'expense'=>$pettyExpense]
    ];
    $overallIncome=$centralIncome+$pettyIncome;$overallExpense=$centralExpense+$pettyExpense;
    require __DIR__.'/partials/header.php'; ?>
    <div class="hero"><div><h1><?=e(ucfirst($r))?> Dashboard</h1><p>Central oversight of operational records and financial activity from every connected subsystem.</p></div><?php if($r==='admin'):?><a class="btn" href="petty_cash.php">Open Petty Cash</a><?php endif;?></div>
    <div class="cards"><?php foreach($counts as $c):?><div class="card metric"><div class="label"><?=e($c[0])?></div><div class="value"><?=number_format($c[1])?></div><div class="hint">Connected records</div></div><?php endforeach;?></div>
    <div class="cards" style="margin-top:16px">
      <div class="card metric"><div class="label">GENERAL INCOME</div><div class="value"><?=money($overallIncome)?></div><div class="hint">Central ledger + petty cash</div></div>
      <div class="card metric"><div class="label">GENERAL EXPENSES</div><div class="value"><?=money($overallExpense)?></div><div class="hint">Central ledger + petty cash</div></div>
      <div class="card metric"><div class="label">GENERAL NET</div><div class="value"><?=money($overallIncome-$overallExpense)?></div><div class="hint">All financial subsystems</div></div>
      <div class="card metric"><div class="label">PETTY CASH BALANCE</div><div class="value"><?=money($pettyIncome-$pettyExpense)?></div><div class="hint">Admin / Director controlled</div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="section-head"><div><h3>Financial reports by subsystem</h3><p class="hint">Income and expenses are consolidated from the school, donor, support, farm, health and petty-cash modules.</p></div></div>
      <div class="tablewrap"><table class="table"><thead><tr><th>Subsystem</th><th>Income</th><th>Expense</th><th>Net</th></tr></thead><tbody>
      <?php foreach($subsystems as $name=>$f):?><tr><td><?=e($name)?></td><td><?=money($f['income'])?></td><td><?=money($f['expense'])?></td><td><?=money($f['income']-$f['expense'])?></td></tr><?php endforeach;?>
      </tbody></table></div>
    </div>
    <?php if($r==='admin'):?>
    <div class="card" style="margin-top:16px"><h3>System license</h3><p class="hint"><?php if($license['permanent']):?>Permanently unlocked.<?php else:?>Installation started <?=e($license['install_at']??'')?> and is available until <?=e($license['expires_at']??'')?>. The administrator may permanently unlock it at any time.<?php endif;?></p>
      <?php if(!$license['permanent']):?><form method="post" class="searchbar"><?=csrf_field()?><input type="hidden" name="op" value="unlock_system"><input type="password" name="unlock_code" placeholder="Enter unlock code" autocomplete="off" required><button class="btn" type="submit">Unlock permanently</button></form><?php endif;?>
    </div>
    <?php endif;?>
<?php require __DIR__.'/partials/footer.php'; exit; }

if(in_array($r,['manager','coordinator'],true)){
    require __DIR__.'/partials/header.php'; ?>
    <div class="hero"><div><h1><?=e(ucfirst($r))?> Dashboard</h1><p>Operational overview for SMI Girl Child Rescue Centre.</p></div></div>
    <div class="cards"><div class="card metric"><div class="label">RESCUED PEOPLE</div><div class="value"><?=number_format((int)$pdo->query("SELECT COUNT(*) n FROM rescued_students WHERE status<>'Inactive'")->fetch()['n'])?></div></div><div class="card metric"><div class="label">FARM RECORDS</div><div class="value"><?=number_format((int)$pdo->query('SELECT COUNT(*) n FROM farm_records')->fetch()['n'])?></div></div><div class="card metric"><div class="label">DONOR SUPPORT</div><div class="value"><?=money((float)$pdo->query('SELECT COALESCE(SUM(amount),0) n FROM donor_supports')->fetch()['n'])?></div></div></div>
<?php require __DIR__.'/partials/footer.php'; exit; }

if($r==='donor'){
    $q=$pdo->prepare("SELECT id,name,organization FROM donors WHERE user_id=? LIMIT 1");$q->execute([user()['id']]);$d=$q->fetch();
    $donations=0;$support=0;
    if($d){$donations=0;$q=$pdo->prepare("SELECT COALESCE(SUM(amount),0) n FROM donor_supports WHERE donor_id=?");$q->execute([$d['id']]);$support=(float)$q->fetch()['n'];}
    require __DIR__.'/partials/header.php'; ?>
    <div class="hero"><div><h1>Donor Dashboard</h1><p>Your private donor workspace. Only your donor information and support activity is shown.</p></div><a class="btn" href="support.php">View my support</a></div>
    <div class="cards"><div class="card metric"><div class="label">MY DONATIONS</div><div class="value"><?=money($donations)?></div><div class="hint">Your donation records</div></div><div class="card metric"><div class="label">MY SUPPORT</div><div class="value"><?=money($support)?></div><div class="hint">Your support contributions</div></div></div>
<?php require __DIR__.'/partials/footer.php'; exit; }

# Admin/staff dashboard: broad operational summary.
$counts=[];$queries=['students'=>['Rescued People','SELECT COUNT(*) n FROM rescued_students WHERE status<>\'Inactive\''],'incidents'=>['Rescue Incidents','SELECT COUNT(*) n FROM rescue_incidents'],'hospitals'=>['Hospitals','SELECT COUNT(*) n FROM hospitals WHERE active=1'],'visits'=>['Hospital Visits','SELECT COUNT(*) n FROM hospital_visits'],'admissions'=>['School Admissions','SELECT COUNT(*) n FROM school_admissions'],'farm'=>['Farm Records','SELECT COUNT(*) n FROM farm_records']];
foreach($queries as $k=>$v){$counts[$k]=[$v[0],(int)$pdo->query($v[1])->fetch()['n']];}
$income=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) n FROM financial_transactions WHERE transaction_type='Income'")->fetch()['n'];
$expenses=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) n FROM financial_transactions WHERE transaction_type='Expense'")->fetch()['n'];
require __DIR__.'/partials/header.php'; ?>
<div class="hero"><div><h1><?=e(ucfirst($r))?> Dashboard</h1><p>Operational overview across the modules assigned to your workspace.</p></div></div>
<div class="cards"><?php foreach($counts as $c):?><div class="card metric"><div class="label"><?=e($c[0])?></div><div class="value"><?=number_format($c[1])?></div><div class="hint">Connected records</div></div><?php endforeach;?></div>
<div class="cards" style="margin-top:16px"><div class="card metric"><div class="label">TOTAL INCOME</div><div class="value"><?=money($income)?></div></div><div class="card metric"><div class="label">TOTAL EXPENSES</div><div class="value"><?=money($expenses)?></div></div></div>
<?php require __DIR__.'/partials/footer.php'; ?>
